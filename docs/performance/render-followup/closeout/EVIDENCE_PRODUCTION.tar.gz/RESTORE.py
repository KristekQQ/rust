"""Restore verified independent files from the B9 object archive into a NEW directory.

Usage: python3 restore-evidence.py EVIDENCE.tar.gz NEW_DIRECTORY
No links are extracted, paths must be relative, and existing output is refused.
"""
import hashlib, json, sys, tarfile
from pathlib import Path, PurePosixPath

def restore(archive,dest):
 if dest.exists():raise SystemExit('Refusing existing destination '+str(dest))
 with tarfile.open(archive,'r:gz') as tar:
  members={}
  for member in tar:
   if not member.isfile() or member.name in members:raise ValueError('Unsafe/duplicate archive member')
   members[member.name]=member
  index=json.load(tar.extractfile(members['INDEX.json']))
  paths=set(); sizes={}
  for item in index['aliases']:
   path=PurePosixPath(item['path'])
   if path.is_absolute() or '..' in path.parts or item['path'] in paths:raise ValueError('Unsafe/duplicate alias')
   digest=item['sha256']
   if len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('Invalid digest')
   paths.add(item['path']); sizes[digest]=item['bytes']
  expected={'INDEX.json','RESTORE.py'}|{'objects/'+d for d in sizes}
  if set(members)!=expected:raise ValueError('Unexpected member inventory')
  # Verify everything before publishing output.
  objects={}
  for digest,size in sizes.items():
   data=tar.extractfile(members['objects/'+digest]).read()
   if len(data)!=size or hashlib.sha256(data).hexdigest()!=digest:raise ValueError('Corrupt object '+digest)
   objects[digest]=data
  dest.mkdir(parents=True)
  for item in index['aliases']:
   p=dest/item['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(objects[item['sha256']])
 return {'files':len(paths),'objects':len(objects),'independentFiles':True}
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit(__doc__)
 print(json.dumps(restore(Path(sys.argv[1]),Path(sys.argv[2]))))
