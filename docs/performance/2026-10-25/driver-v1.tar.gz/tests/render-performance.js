import {insertionOrder} from '/scripts/render-performance-order.mjs';
import {initEngine} from '/js/engine.js';
const q=new URLSearchParams(location.search),family=q.get('family')||'primitives',load=Number(q.get('load')||1);
if(!Number.isInteger(load)||load<1||load>65536)throw Error('Invalid load');
const order=q.get('order')||'spatial',seed=Number(q.get('seed')??1337),overlap=Number(q.get('overlap')??0),insertion=insertionOrder(load,order,seed);if(!Number.isFinite(overlap)||overlap<0||overlap>1)throw Error('Invalid overlap');
const startupAt=performance.now();window.benchProgress={phase:'engine initialization',requestedObjects:load,createdObjects:0,createdModels:0,lastLogicalId:null,elapsedMs:0,yieldEveryObjects:128};
const engine=await initEngine(document.querySelector('canvas'),{backend:q.get('backend')==='webgl'?'webgl':'auto',profiling:q.get('profile')!=='0'});
window.benchStartupEngine=engine;engine.resize(960,640);engine.setDebugOverlay(false);engine.set_camera_mode('free');engine.set_grid_visible(false);engine.set_light_helpers_visible(false);engine.set_simulation_paused(true);engine.set_render_effects(false,false);engine.setCameraView([0,2,9],[0,0,0]);
window.benchProgress.phase='scene setup';
const cutMesh={color:[.9,.15,.08],positions:[-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,1],indices:[0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,3,7,6,3,6,2,0,4,7,0,7,3,1,2,6,1,6,5]};
let operationStage='setup';
const objects=[],operations={transforms:0,spawns:0,removes:0,cuts:0},scene=engine.scene;
let epoch=performance.now(),active=false,lastEvent=-1,arena=null,rome=null;let quality={renderEffects:[false,false],camera:{position:[0,2,9],target:[0,0,0]},profile:'diagnostic'};
const grid=i=>{const side=Math.ceil(Math.sqrt(load));return [((i%side)-(side-1)/2)*6/side*(1-overlap),(Math.floor(i/side)-(side-1)/2)*4/side*(1-overlap),0];};
if(family.startsWith('rim-')){
 const {createScene,createGameplay}=await import('/examples/rim/scene.js');const {configureAppearance}=await import('/examples/rim/appearance.js');configureAppearance(engine);quality={profile:'examples/rim/appearance.js unchanged',renderEffects:[true,false],fxaa:{enabled:true,strength:.6},sceneAppearance:'shared configureAppearance commands',camera:{authoredLayoutIndex:0}};
 rome=await createScene(scene);await createGameplay(engine,rome);const camera=rome.layout.cameras[0];if(camera)rome.environment.useCamera(camera.nodeIndex);
 engine.set_simulation_paused(family==='rim-static');scene.rimInput(family==='rim-active'?{start:true,pause:false}:{pause:true,reset:true});
}else if(family.startsWith('arena-')){
 const module=await import('/examples/neon-arena/scene.js');arena={module,world:await module.createScene(scene)};
 engine.set_render_effects(false,false);engine.setBackgroundColor([0,0,0]);engine.setNeonGlow(module.NEON_GLOW);engine.postprocessing.configureSSR({resolutionScale:.5,receiverBounds:module.FLOOR_SSR_BOUNDS});engine.postprocessing.enable('ssr',module.FLOOR_SSR);engine.setOrbitView([0,1.75,1.2],[0,1.45,-1.6]);
 const world=arena.world;if(world.arenaFont.selected!=='cynatar')world.arenaFont.set('cynatar');world.galleryIcons.forEach((icon,index)=>icon.setColorCutout(0).setOpacity(module.FRUIT_OPACITY,{opaqueAbove:.25,variation:module.FRUIT_OPACITY_VARIATION,coverage:world.galleryPatterns[index].coverage??.5}));
 for(const panel of [...world.phasePanels.map(item=>item.object),...world.stockScorePanels,world.timerPanel,world.scoreLabel,world.scorePanel,world.currentLabel,...world.awardPanels,world.comboRules,...world.galleryLabels,world.restartButton,world.logo])panel.setScale([-1,1,1]);
 engine.xr.configureComboDisplay(world.comboDisplay);engine.xr.player.equip('right',world.sword,{cutting:true,requireTrigger:false,haptics:true});engine.xr.player.equip('left',world.leftSword,{cutting:true,requireTrigger:false,haptics:true});engine.set_simulation_paused(family==='arena-static');
 quality={profile:'examples/neon-arena/main.js default visual settings',renderEffects:[false,false],background:[0,0,0],glow:module.NEON_GLOW,ssr:{enabled:true,...module.FLOOR_SSR,resolutionScale:.5,receiverBounds:module.FLOOR_SSR_BOUNDS},fruit:{solid:true,opacity:module.FRUIT_OPACITY,opaqueAbove:.25,variation:module.FRUIT_OPACITY_VARIATION},font:'cynatar',panelFacing:'desktop',camera:{mode:'orbit',position:[0,1.75,1.2],target:[0,1.45,-1.6]}};
}else{
 scene.createLight({position:[-3,6,5],color:[12,12,12]});
 const paths={rigid:'/assets/models/damaged-helmet/DamagedHelmet.glb',skin:'/assets/models/fox/Fox.glb',morph:'/tests/fixtures/gltf/full/full.gltf'};let source=null,alternate=null;let fixtureUrl=null,alternateUrl=null;
 if(family==='batching'||family==='batching-heterogeneous'||family==='dynamic'){const data=new Uint8Array(108);new Float32Array(data.buffer,0,12).set([-.3,-.3,0,.3,-.3,0,.3,.3,0,-.3,.3,0]);new Float32Array(data.buffer,48,12).set([0,0,1,0,0,1,0,0,1,0,0,1]);new Uint16Array(data.buffer,96,6).set([0,1,2,0,2,3]);const fixture={asset:{version:'2.0'},buffers:[{byteLength:108,uri:'data:application/octet-stream;base64,'+btoa(String.fromCharCode(...data))}],bufferViews:[{buffer:0,byteOffset:0,byteLength:48},{buffer:0,byteOffset:48,byteLength:48},{buffer:0,byteOffset:96,byteLength:12}],accessors:[{bufferView:0,componentType:5126,count:4,type:'VEC3',min:[-.3,-.3,0],max:[.3,.3,0]},{bufferView:1,componentType:5126,count:4,type:'VEC3'},{bufferView:2,componentType:5123,count:6,type:'SCALAR'}],meshes:[{primitives:[{attributes:{POSITION:0,NORMAL:1},indices:2}]}],nodes:[{mesh:0}],scenes:[{nodes:[0]}],scene:0};fixtureUrl=URL.createObjectURL(new Blob([JSON.stringify(fixture)],{type:'model/gltf+json'}));paths[family]=fixtureUrl;if(family==='batching-heterogeneous'){fixture.materials=[{pbrMetallicRoughness:{baseColorFactor:[.9,.08,.15,1]}}];fixture.meshes[0].primitives[0].material=0;alternateUrl=URL.createObjectURL(new Blob([JSON.stringify(fixture)],{type:'model/gltf+json'}));}}

 for(const i of insertion){
 window.benchProgress.phase=paths[family]?'model root creation':'primitive creation';window.benchProgress.lastLogicalId=i;window.benchProgress.elapsedMs=performance.now()-startupAt;
 let o;if(paths[family]){if(alternateUrl&&i%2){o=alternate?alternate.createInstance():await scene.loadModel(alternateUrl);alternate??=o;}else{o=source?source.createInstance():await scene.loadModel(paths[family]);source??=o;}if(family==='skin')o.playAnimation('Walk').pauseAnimation();}else o=family==='heterogeneous'&&i%2?scene.createSphere():scene.createCube();
 const position=grid(i),scale=family==='skin'?.006:family==='rigid'?.25:family==='morph'?.3:family==='fragment'||family==='effects'?3:.5/Math.sqrt(load);
 if(family==='fragment'||family==='effects'){position[0]=0;position[1]=0;position[2]=-i*.02;o.setOpacity(.15).setEmission(2);}
 o.setPosition(position).setScale([scale,scale,scale]);objects[i]=o;window.benchProgress.createdObjects++;if(paths[family])window.benchProgress.createdModels++;window.benchProgress.elapsedMs=performance.now()-startupAt;if(window.benchProgress.createdObjects%128===0)await new Promise(resolve=>setTimeout(resolve,0));
 }
 if(fixtureUrl)URL.revokeObjectURL(fixtureUrl);if(alternateUrl)URL.revokeObjectURL(alternateUrl);
 if(family==='effects'){engine.set_render_effects(true,true);engine.postprocessing.enable('fxaa',{strength:1});}
}
function pose(seconds){
 if(family==='rim-active'){engine.setCameraView([Math.sin(seconds*.15)*2,1.7,8-Math.sin(seconds*.1)*3],[0,1.3,0]);operations.transforms++;scene.rimInput({movement:[Math.sin(seconds*.3)*.2,0],sprint:false});}
 else if(family==='arena-active')arena.world.apples.forEach((o,i)=>{o.setPosition([Math.sin(seconds+i)*.75,1.4+Math.sin(seconds*1.7+i)*.4,-1.3]);operations.transforms++;});
 else for(let i=0;i<objects.length;i++){const o=objects[i];if(!o.exists)continue;if(family==='dynamic'){const p=grid(i),cluster=(Math.sin(seconds*.8)+1)*.5;o.setPosition([p[0]*(1-cluster),p[1]*(1-cluster),0]);operations.transforms++;}if(family==='skin')o.seekAnimation(seconds%.7);else if(family==='morph'){for(let n=0;n<3;n++)o.setMorphWeights(n,[(Math.sin(seconds)+1)/2]);}else if(family!=='fragment'&&family!=='effects')o.setRotation([.12*Math.sin(seconds),seconds+i*.12,0]);operations.transforms++;}
 const event=Math.floor(seconds/2);if(event!==lastEvent){lastEvent=event;if(family==='dynamic'){
 operationStage='create custom closed cut mesh';const o=scene.createMesh(cutMesh).setPosition([0,0,0]).setScale([.4,.4,.4]);operationStage='mark triangle mesh cuttable';o.setCuttable(true);operations.spawns++;
 operationStage='register finite 2m world blade';const cutter=scene.createCube([0,1,0]).setScale([.01,.01,.01]).setCutter({base:[0,0,-100],tip:[0,0,100]});
 try{operationStage='native cutWith';const report=scene.cutWith(cutter,{motion:[0,-2,0],separation:.02});operations.cuts+=report.removed.length;operationStage='verify native cut result';if(report.removed.length!==1||report.pieces.length!==2)throw Error('Expected one closed target -> two pieces, got '+JSON.stringify({removed:report.removed.length,pieces:report.pieces.length}));operationStage='remove native cut pieces';for(const piece of report.pieces)if(piece.exists)piece.remove();}finally{cutter.remove();if(o.exists){o.remove();operations.removes++;}}operationStage='pose';
 }}
}
function tick(t){if(active)try{pose((t-epoch)/1000);}catch(error){active=false;window.benchFailure={family,operationStage,message:error?.message||String(error),stack:error?.stack||null};throw new Error('Workload '+family+' at '+operationStage+': '+(error?.message||String(error)),{cause:error});}requestAnimationFrame(tick);}requestAnimationFrame(tick);
window.benchProgress.phase='ready';window.benchProgress.elapsedMs=performance.now()-startupAt;
window.bench={engine,family,load,operations,start(){epoch=performance.now();lastEvent=-1;active=true;},stop(){active=false;},capturePose(){active=false;lastEvent=0;pose(.375);},metadata:{family,load,quality,viewport:{width:960,height:640,deviceScaleFactor:1},order,seed,overlap,insertionApplied:!rome&&!arena,insertionAlgorithm:'LCG32 Fisher-Yates v1; alternating low/high v1; logical grid independent of insertion',firstLogicalIds:insertion.slice(0,32),poseClock:'elapsed performance.now seconds',scene:rome?'actual Rome scene and native gameplay':arena?'actual arena scene; deterministic apple transform driver':'diagnostic workload',unmatchedThreeReference:false,loadUnit:rome||arena?'fixed authored scene (load does not replicate it)':'visible object count'}};
