import subprocess,pathlib,json,time,sys,ssl,urllib.request,re
root=pathlib.Path.cwd();primary=pathlib.Path('/Users/Honza/WebstormProjects/rust');originHost='192.168.0.17';tls=pathlib.Path.home()/'.local/share/rust-webxr/tls'
args=[sys.executable,str(primary/'scripts/serve-quest-shared.py'),'0','--host',originHost,'--cert',str(tls/'server.crt'),'--key',str(tls/'server.key'),'--fallback-root',str(root),'--arena-root',str(primary/'output/production')]
log=(root/'output/spatial-server-preflight.log').open('a');p=subprocess.Popen(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
try:
 port=None
 for i in range(40):
  if p.poll() is not None:raise RuntimeError('preflight server exited '+str(p.returncode))
  found=subprocess.run(['lsof','-a','-p',str(p.pid),'-iTCP','-sTCP:LISTEN','-Fn'],stdout=subprocess.PIPE,text=True).stdout
  match=re.search(r'^n[^\n]+:(\d+)$',found,re.M)
  if match:port=int(match.group(1));break
  time.sleep(.1)
 assert port
 context=ssl.create_default_context(cafile=str(tls/'rootCA.crt'));items=[]
 for path in ['examples/rim/','examples/neon-arena/','_neon/js/engine.js','_neon/pkg/webgpu_wasm_bg.wasm']:
  with urllib.request.urlopen(f'https://{originHost}:{port}/{path}',context=context,timeout=20) as r:items.append({'path':path,'status':r.status,'bytes':len(r.read())})
 state={'pid':p.pid,'port':port,'args':args,'checks':items,'cwd':str(root),'log':str(root/'output/spatial-server-preflight.log')};(root/'output/spatial-server-preflight.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state))
finally:
 p.terminate();p.wait(timeout=10);log.close()
