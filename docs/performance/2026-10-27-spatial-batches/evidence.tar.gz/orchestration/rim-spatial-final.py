import subprocess,pathlib,json,time,os
root=pathlib.Path.cwd();base=root/'output/spatial-batches';dest=base/'final';dest.mkdir()
node=subprocess.check_output(['git','config','--local','--get','verification.node'],text=True).strip()
driver='scripts/render-performance.mjs';common=['--family','rim-stress','--max-load','2048','--width','2880','--height','1920','--no-profile','--startup-timeout','60000','--max-time','1200']
b0=str(base/'baseline');v2=str(base/'candidate-v2');three=str(base/'three-reference')
stages=[
('cal-gl', ['calibrate','--baseline-root',b0,'--backend','webgl','--load','512','--warmup','2000','--sample','6000']),
('cal-wg-1024', ['calibrate','--baseline-root',b0,'--backend','webgpu','--load','1024','--warmup','2000','--sample','6000']),
('pairs-gl', ['compare','--baseline-root',b0,'--candidate-root',v2,'--config',str(dest/'cal-gl/config.json'),'--backend','webgl','--load','512','--warmup','8000','--sample','25000','--pairs','3']),
('pairs-wg-1024', ['compare','--baseline-root',b0,'--candidate-root',v2,'--config',str(dest/'cal-wg-1024/config.json'),'--backend','webgpu','--load','1024','--warmup','8000','--sample','25000','--pairs','3']),
('cal-final-gl', ['calibrate','--baseline-root',v2,'--backend','webgl','--load','512','--warmup','2000','--sample','6000']),
('three-gl', ['compare','--baseline-root',v2,'--three-root',three,'--config',str(dest/'cal-final-gl/config.json'),'--backend','webgl','--load','512','--warmup','8000','--sample','25000','--pairs','3']),
('control-wg-512', ['smoke','--baseline-root',v2,'--backend','webgpu','--load','512','--warmup','8000','--sample','25000']),
]
plan={'scope':'Serialized desktop experiments, not physical Quest or equal native/Three graphics. Existing unknown Chrome30810/GPU30816 retained without permission to close; background/thermal not isolated.','stages':[]}
for name,args in stages:
 cmd=[node,driver,*args,*common,'--out',str(dest/name)];plan['stages'].append({'name':name,'command':cmd})
(dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for item in plan['stages']:
 started=time.time();print(json.dumps({'started':item['name']}),flush=True)
 with (dest/(item['name']+'.log')).open('w') as f:res=subprocess.run(item['command'],stdout=f,stderr=subprocess.STDOUT)
 item.update(returncode=res.returncode,elapsedSeconds=time.time()-started)
 (dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'completed':item['name'],'rc':res.returncode}),flush=True)
 if res.returncode:raise SystemExit(res.returncode)
