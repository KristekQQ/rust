from pathlib import Path
import json,subprocess,os,signal,time,ssl,urllib.request
root=Path.cwd();old=79190;record=json.loads((root/'output/spatial-server-preflight.json').read_text());args=record['args'];args[2]='8443'
command=subprocess.check_output(['ps','-p',str(old),'-o','command='],text=True).strip()
assert 'scripts/serve-quest-shared.py 8443' in command and '--fallback-root '+str(root) in command
clients=subprocess.run(['lsof','-a','-p',str(old),'-iTCP','-sTCP:ESTABLISHED','-Fn'],stdout=subprocess.PIPE,text=True).stdout
assert not clients.strip(),'Active connections exist; failed server not stopped'
state={'oldPid':old,'oldCommand':command,'oldCwdInode':41519677,'currentCwdInode':root.stat().st_ino,'preflight':record['checks'],'args':args}
os.kill(old,signal.SIGTERM)
for _ in range(50):
 listener=subprocess.run(['lsof','-nP','-iTCP:8443','-sTCP:LISTEN','-t'],stdout=subprocess.PIPE,text=True).stdout.strip()
 if not listener:break
 time.sleep(.1)
else:raise RuntimeError('8443 did not become available')
log=(root/'output/spatial-shared-server.log').open('a');p=subprocess.Popen(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['newPid']=p.pid
context=ssl.create_default_context(cafile=str(Path.home()/'.local/share/rust-webxr/tls/rootCA.crt'))
for _ in range(50):
 try:
  with urllib.request.urlopen('https://192.168.0.17:8443/examples/rim/',context=context,timeout=2) as r:assert r.status==200;r.read()
  break
 except Exception:
  if p.poll() is not None:raise RuntimeError('replacement server exited')
  time.sleep(.1)
else:raise RuntimeError('replacement failed HTTPS readiness')
state['restoredOldRelease']='93b31ba5f9';state['sourceEdited']=False;state['primaryPackageEdited']=False;(root/'output/spatial-server-recovery.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({'newPid':p.pid,'https':200,'sameRoutes':True,'sourceEdited':False}))
