import pathlib,json,time,subprocess,os
root=pathlib.Path.cwd();deadline=time.time()+1800
while True:
 p=json.loads((root/'output/spatial-batches/final-v4/plan.json').read_text())
 if any(s.get('returncode',0)!=0 for s in p['stages']):raise SystemExit('v4 campaign failed; no build started')
 if all(s.get('returncode')==0 for s in p['stages']):break
 if time.time()>deadline:raise SystemExit('v4 wait bound reached; no build started')
 time.sleep(5)
node=subprocess.check_output(['git','config','--local','--get','verification.node'],text=True).strip()
env={**os.environ,'VERIFY_WASM_PROFILE':'release','RUSTFLAGS':'--cfg=web_sys_unstable_apis'}
commands=[
('fmt',['cargo','fmt','--all']),
('clippy',['cargo','clippy','--locked','--target','wasm32-unknown-unknown','--','-D','warnings']),
('build',['wasm-pack','build','--target','web','--release','--','--locked']),
('fingerprint',[node,'scripts/build-fingerprint.mjs','--write']),
('production',[node,'--input-type=module','-e','import {assertFreshBuild} from "./scripts/build-fingerprint.mjs";import {writeProduction} from "./scripts/build-production.mjs";const m=await writeProduction({build:await assertFreshBuild(),destination:"output/spatial-batches/candidate-v5-production"});console.log(JSON.stringify({release:m.releaseId,wasm:m.build.wasm,files:m.files.length}));']),
('freeze',[node,'scripts/freeze-render-build.mjs','output/spatial-batches/candidate-v5']),
('types',[node,'node_modules/typescript/bin/tsc','--noEmit']),
('browser',[node,'scripts/test-browser.mjs','--production-root','output/spatial-batches/candidate-v5-production','--page','gltf-batching,gltf-opaque-batching,gltf-light-classes,gltf-gpu-transforms,gltf-visibility,gltf-full,rim-spatial-batches-xr,webxr,webxr-webgpu','--backend','all']),
]
for name,cmd in commands:
 print(json.dumps({'started':name}),flush=True)
 with (root/f'output/spatial-v5-{name}.log').open('w') as f:result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(json.dumps({'completed':name,'rc':result.returncode}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 if name=='browser':(root/'output/spatial-browser-v5-report.json').write_bytes((root/'output/verification/browser-report.json').read_bytes())
for backend,load,config in [('webgl','512','cal-gl'),('webgpu','1024','cal-wg-1024')]:
 name=f'pilot-v5-{backend}';cmd=[node,'scripts/render-performance.mjs','compare','--baseline-root','output/spatial-batches/baseline','--candidate-root','output/spatial-batches/candidate-v5','--config',f'output/spatial-batches/final/{config}/config.json','--family','rim-stress','--backend',backend,'--load',load,'--max-load','2048','--width','2880','--height','1920','--warmup','2000','--sample','6000','--pairs','1','--no-profile','--startup-timeout','60000','--max-time','600','--out',f'output/spatial-batches/{name}']
 print(json.dumps({'started':name}),flush=True)
 with (root/f'output/spatial-{name}.log').open('w') as f:result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(json.dumps({'completed':name,'rc':result.returncode}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
