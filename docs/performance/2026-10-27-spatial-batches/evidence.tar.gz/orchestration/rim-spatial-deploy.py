from pathlib import Path
import json,hashlib,ssl,urllib.request,datetime,subprocess,os
root=Path.cwd();stage=root/'output/spatial-batches/accepted-production';live=root/'output/production';docs=root/'docs/performance/2026-10-27-spatial-batches'
report=json.loads((root/'output/verification/browser-report.json').read_text());assert report.get('finished') and not report.get('error') and len(report['results'])==11 and all(r['status']=='PASS' for r in report['results'])
(docs/'production-browser-report.json').write_text(json.dumps(report,indent=2)+'\n')
manifest=json.loads((stage/'production-manifest.json').read_text());assert manifest['releaseId']=='ba920dd931'
for f in manifest['files']:
 data=(stage/f['path']).read_bytes();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
old=json.loads((live/'production-manifest.json').read_text());assert old['releaseId']=='93b31ba5f9','Live package changed; inspect before installation'
ip=subprocess.check_output(['ipconfig','getifaddr','en0'],text=True).strip();assert ip=='192.168.0.17','LAN changed; certificate/address must be rechecked'
origin='https://'+ip+':8443';context=ssl.create_default_context(cafile=str(Path.home()/'.local/share/rust-webxr/tls/rootCA.crt'))
def request(path):
 with urllib.request.urlopen(urllib.request.Request(origin+'/'+path,headers={'Accept-Encoding':'identity'}),context=context,timeout=30) as response:
  data=response.read();return {'path':path,'status':response.status,'sha256':hashlib.sha256(data).hexdigest(),'noStore':'no-store' in response.headers.get('Cache-Control',''),'tls':True,'finalUrl':response.url,'contentType':response.headers.get('Content-Type')}
neon=['examples/neon-arena/','examples/neon-arena/main.js','examples/neon-arena/scene.js','_neon/js/engine.js','_neon/pkg/webgpu_wasm_bg.wasm']
neonBefore=[request(p) for p in neon]
checks=['examples/rim/?backend=webgpu','examples/rim/?backend=webgl','examples/rim/main.js','examples/rim/scene.js','pkg/webgpu_wasm_bg.wasm','pkg/webgpu_wasm.js','js/engine.js','examples/rim-three/','examples/rim-three/app.js','examples/rim-compare/','examples/rim-compare/style.css','examples/rim-compare/compare.js','examples/rim-compare/native-webgpu.png','examples/rim-compare/native-webgl.png','examples/rim-compare/three.png']
backup=root/'output/spatial-live-before-ba920dd931';assert not backup.exists()
state={'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':origin,'release':manifest['releaseId'],'build':manifest['build'],'files':len(manifest['files']),'productionBrowserCases':11,'physicalQuest':False,'serverRestarted':False,'previousRelease':old['releaseId'],'backup':str(backup),'payloads':[],'neonBefore':neonBefore}
live.rename(backup)
try:
 stage.rename(live)
 for path in checks:
  item=request(path);plain=path.split('?')[0];file=plain+'index.html' if plain.endswith('/') else plain
  assert item['status']==200 and item['noStore'] and item['sha256']==hashlib.sha256((live/file).read_bytes()).hexdigest(),path
  state['payloads'].append(item)
 state['neonAfter']=[request(p) for p in neon]
 state['neonPayloadsUnchanged']=all(a['sha256']==b['sha256'] for a,b in zip(neonBefore,state['neonAfter']))
 state['installed']=True
except BaseException as e:
 state['error']=repr(e);state['installed']=False
 if live.exists():live.rename(root/'output/spatial-rejected-ba920dd931')
 backup.rename(live)
 raise
finally:(docs/'deployment.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({'release':state['release'],'payloads':len(state['payloads']),'TLS':True,'noStore':True,'neonUnchanged':state['neonPayloadsUnchanged'],'serverRestarted':False}))
