from pathlib import Path
import tarfile,hashlib,json,subprocess,io
root=Path.cwd();base=root/'output/spatial-batches';dest=root/'docs/performance/2026-10-27-spatial-batches';dest.mkdir(exist_ok=True)
files=[]
# Every measurement/control report and raw frame sample is kept, including adverse runs.
for f in base.rglob('*'):
 rel=f.relative_to(base)
 if not f.is_file() or any(part in ['pkg','src','assets','examples','js','tests','scripts','.agents','docs','third_party'] for part in rel.parts[:-1]):continue
 if f.name in ['report.json','raw.json.gz','config.json','plan.json','manifest-baseline.json','manifest-candidate.json'] or (f.suffix=='.png' and (rel.parts[0]=='final-v5' or rel.parts[0]=='pilot-webgpu')):files.append((f,'measurements/'+str(rel)))
for f in root.joinpath('output').glob('spatial-*.log'):files.append((f,'logs/'+f.name))
for f in root.joinpath('output').glob('spatial-*.json'):files.append((f,'checks/'+f.name))
for f in root.joinpath('output').glob('spatial-v5-*.log'):files.append((f,'checks/'+f.name))
for version in ['baseline','candidate-v1','candidate-v2','candidate-v3','candidate-v4','candidate-v5']:
 for name in ['render-build.json','pkg/verification-build.json']:
  f=base/version/name
  if f.exists():files.append((f,'identities/'+version+'/'+name))
for version in ['baseline','candidate-v5']:
 for f in (base/version/'pkg').iterdir():
  if f.is_file():files.append((f,'runtime/'+version+'/pkg/'+f.name))
for f in Path('/tmp').glob('rim-spatial-*.py'):files.append((f,'orchestration/'+f.name))
# Record hashes for all members; identical PNGs become archive hardlinks, no source deletion.
entries={};seen={};archive=dest/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for f,name in sorted(dict((name,(f,name)) for f,name in files).values(),key=lambda x:x[1]):
  data=f.read_bytes();sha=hashlib.sha256(data).hexdigest();entries[name]={'sha256':sha,'bytes':len(data)}
  info=tar.gettarinfo(str(f),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  if f.suffix=='.png' and sha in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[sha];info.size=0;tar.addfile(info)
  else:
   tar.addfile(info,io.BytesIO(data))
   if f.suffix=='.png':seen[sha]=name
 data=(json.dumps(entries,indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
(dest/'evidence-sha256.json').write_text(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries),'uniquePngs':len(seen)},indent=2)+'\n')
owned=['src/lib.rs','src/render/gltf_gpu.rs','src/render/renderer.rs','src/visibility.rs','js/engine.d.ts','scripts/render-performance-lib.mjs','scripts/test-browser.mjs','tests/gltf-batching.js','tests/gltf-opaque-batching.js']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*owned]);new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','src/render_batch.rs'],stdout=subprocess.PIPE)
assert new.returncode==1
(dest/'source.patch').write_bytes(patch+new.stdout)
parts=[]
for name in ['src/render/gltf_gpu.rs','tests/gltf-batching.js']:
 diff=subprocess.run(['git','diff','--no-index','--',str(base/'candidate-v4'/name),str(base/'candidate-v5'/name)],stdout=subprocess.PIPE);assert diff.returncode in [0,1];parts.append(diff.stdout)
(dest/'attribute-experiment.patch').write_bytes(b''.join(parts))
print((dest/'evidence-sha256.json').read_text())
