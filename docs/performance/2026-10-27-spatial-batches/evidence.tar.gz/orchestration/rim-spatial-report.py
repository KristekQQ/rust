from pathlib import Path
import json,statistics,sys
version=int(sys.argv[1]);folder=Path('docs/performance/2026-10-27-spatial-batches');s=json.loads((folder/'summary.json').read_text());prefix=f'final-v{version}'
gl=s['campaigns'][prefix+'/pairs-gl'];wg=s['campaigns'][prefix+'/pairs-wg-1024'];three=s['campaigns'][prefix+'/three-gl']
assert all(p['complete'] for p in [gl,wg,three]),'Final comparisons incomplete'
for p in [gl,wg]:
 assert all(pair['pixel']['pass'] is True for c in p['pixels'] for pair in c['paired'])
 assert all(r['instanceBuffersCreated']==0 and r['instanceUploadBytes']==0 for r in p['runs'])
fps=lambda p,side: p['medians'][side]['fps']
number=lambda x:f'{x:.3f}'
runs=lambda p,side:', '.join(number(r['fps']) for r in p['runs'] if r['side']==side)
first=lambda p,side:next(r for r in p['runs'] if r['side']==side)
b=first(gl,'baseline');c=first(gl,'candidate');reduction=100*(1-c['instanceBufferBytes']/b['instanceBufferBytes'])
manifest=json.loads(Path(f'output/spatial-batches/candidate-v{version}/render-build.json').read_text())
badgl=sum(r<1 for r in gl['pairedFpsRatios']);badwg=sum(r<1 for r in wg['pairedFpsRatios'])
qualitytext=f'GL has{badgl}/3 adverse pairs; WG has{badwg}/3. Background/thermal conditions remain uncontrolled, so a general reliable FPS gain is unproven.'
uitext=f'WebGL2: {badgl} horší pár ze 3. WebGPU: {badwg} horší pár ze 3. Souběžná zátěž stále omezuje jistotu výsledku.'
geometrytext='Conditional absent-normal-map tangent omission removes16B per rigid vertex (56→40B without texture UVs), with full96B CPU fallback offsets unchanged; exact4-vertex fixture proves184B upload including indices, versus248B. Original normal-map layouts, skin/morph position/normal math and CPU queries remain.' if version==5 else 'The tangent-omission experiment is not part of this selected source; retain original attribute layouts.'
text=f'''# Spatial opaque batches and lossless GPU records — 2026-10-27

Selected local implementation: v{version}. Scope: reusable Rust preparation/instancing, not a glTF format replacement. No example/asset-name branches, geometry reduction, quality-setting changes or gameplay changes.

## Result

Desktop AppleM1, Chrome155 ANGLE/Metal,2880×1920,DPR1,profiler off;3 alternating AB/BA/AB pairs,8s warmup/25s measurement. FPS=1000/mean application RAF interval, then median across runs. Separate campaigns and different loads are not a three-way ranking.

| Self-comparison | Stress models | Baseline FPS | Selected FPS | Actual total calls before→after |
|---|---:|---:|---:|---:|
| Native WebGL2 |512|{fps(gl,'baseline'):.3f}|{fps(gl,'candidate'):.3f}|{gl['medians']['baseline']['actualCalls']:.0f}→{gl['medians']['candidate']['actualCalls']:.0f}|
| Native WebGPU |1024|{fps(wg,'baseline'):.3f}|{fps(wg,'candidate'):.3f}|{wg['medians']['baseline']['actualCalls']:.0f}→{wg['medians']['candidate']['actualCalls']:.0f}|

GL per-run baseline[{runs(gl,'baseline')}] / selected[{runs(gl,'candidate')}]; paired FPS ratios{gl['pairedFpsRatios']}. WG baseline[{runs(wg,'baseline')}] / selected[{runs(wg,'candidate')}]; paired ratios{wg['pairedFpsRatios']}. {qualitytext} Preparation counters and resource reductions below are separate evidence.

Separate direct authored-Three diagnostic,512models/same camera/resolution: selected nativeGL{fps(three,'baseline'):.3f}FPS/{three['medians']['baseline']['actualCalls']:.0f}calls versus Three r170{fps(three,'candidate'):.3f}FPS/{three['medians']['candidate']['actualCalls']:.0f}calls. Three wins this diagnostic. AA(FXAA versus MSAA4),PBR/shadows and full gameplay differ; do not call this equal full graphics or combine its absolute FPS with the self-series above. Requested stress asset/poses match; native10,553,756 versusThree10,554,110 submitted triangles/RAF differ by354 in the original scene.

## Implementation and measured work

- Replace the fixed128-root opaque scheduling window with a camera-relative depth span(far/near≤2), keeping the1024-instance draw limit independent. Explicit opaque-reorderable permission, rigid assets, same shared geometry/material/options, mirrored transforms, alpha/order barriers, clipping and auxiliary-pass fallback remain. Depth4 reached107total calls but repeatedly reduced GL throughput; retained as a rejected experiment, not the selected policy.
- Cache complete per-pose root bounds and active opaque/blend ordinal lists under the existing successful update stamp. Skip child-plane tests only with strict six-plane full-root containment; partial/touching/invalid bounds keep individual tests. GL primitive tests/RAF34,343→{c['primitiveTestsPerRaf']:.0f}, unchanged10,553,756 submitted glTF triangles. Camera, pose/options, removal and two-eye mutations remain covered.
- Exact identical affine basis/normal coefficients share the material uniform and use16B absolute translations, retaining the full112B instance record for differing bases. No approximate normal reconstruction. Mixed streams use byte offsets/capacities and separate pass/view ownership.512-model retained allocated instance buffers{b['instanceBufferBytes']:,}→{c['instanceBufferBytes']:,}B(−{reduction:.2f}%). This is instance-buffer allocation, not total process/physical VRAM. Stable timed runs assert no new instance buffers or instance uploads. New format/material combinations can compile cold pipelines; arbitrary first-use transitions are not proven hitch-free.
- {geometrytext}

Actual glTF event counters, including translations, root-proof tests and spatial barriers, are exposed through existing diagnostics. Whole stress-scene calls above are actual glTF submitted calls plus one FXAA compose; estimated root/primitive submission counters are not substituted.

## Correctness and evidence

Native4bounded-policy/frustum cases, strictwasmClippy, release build and TypeScript pass. Unchanged performance-helper unit suite29PASS reused. Independent opaque/root-order and CPU-deformed pixel oracles cover translated/nonuniform/mirrored/rotated instances, stream grow/shrink/offsets, culling, materials, skin/morph and cleanup. Seventeen v3 and seventeen v5 minified browser cases pass, plus4focused v4 cases; direct WebGPU and WebGL simulatedXR include asymmetric eyes,256stressmodels, actual cut-worker completion/visible halves and continuation. These are browser/simulation checks, not physical Quest acceptance.

All6 selected before/after stress image comparisons pass the unchanged8/255,0.1% gate; see summary.json for exactness/maxima. GL/WG v4 were all pixel-exact. Independent read-only Sol review covered cache invalidation, mixed buffer lifetime/layout and shader keys. It caught a v5 unsigned UV-filter underflow before build; guarded and reinspected, then byte/pixel/runtime tests passed. Reviewer did not independently reproduce performance.

Frozen baseline source535ac6bc/WASMdcce4c0c. Selected WASM{manifest['build']['wasm']}; branchcodex/spatial-opaque-batches from restored archive7b90d4d18. Full input/build/request manifests and per-run raw frames are retained in evidence.tar.gz; summary.json and EXPERIMENTS.md retain adverse pilots/repetitions. source.patch captures the selected implementation; attribute-experiment.patch preserves the v4→v5 experiment. No commit/push/CI acceptance in this task.

## Limits and next bounded investigation

Existing unknown headlessChrome30810/GPU30816 stayed running(~30%CPU on its GPU helper); permission to close was not assumed. Background/thermal state was not isolated, and absolute native GL cadence changed strongly between campaigns. Repetitions do not eliminate that uncertainty. No physical-headset FPS/latency/comfort comparison is available.

Genuine v5 profiler diagnostics are separate from throughput: WebGPU1024yielded5valid pass samples(scene.main mean31.700ms,FXAA1.984ms); GL EXT elapsed queries yielded4samples(mean127.186ms) in a contended context, not isolated GPU busy time. Do not sum these scopes or claim a before/after GPU reduction. Earlier v4 stage named profile-gl inherited profiler-off calibration and supplies no GPU-time evidence.

Next candidates remain unimplemented: omit provably identity-white vertex colors with full-color fallback/variant ownership; choose lossless16-bit indices where legal(current native glTF usesu32); or retain prepared groups under complete view/pose/pipeline/resource keys. Three r170 conditionally requests vertex colors/tangents; any transfer needs its own pixels and matched timings. Vertex shadow projection must preserve current final-fragment normal bias; blindly copying Three's vertex bias changes graphics. No checklist establishes perfect optimization.

## Delivery

Final staged package, browser entry checks, actual HTTPS payload hashes and live release identity are recorded after installation in deployment.json. Normal8443URLs remain unchanged; no page version parameter. Shared server and primary Neon remain under their existing ownership. Final device acceptance remains outstanding.
'''
(folder/'REPORT.md').write_text(text)
# Replace only the owned comparison page's old dated measurement section.
p=Path('examples/rim-compare/index.html');html=p.read_text();start=html.index('<section><h2>Poslední data');end=html.index('<p class="caption">Snímky zachovávají',start)
f=lambda x:f'{x:.2f}'.replace('.',',')
new=f'''<section><h2>Nová optimalizace · 27. 10. 2026</h2><p>Desktop Apple M1 · 2880 × 1920 · 3 páry, 8 s zahřátí + 25 s měření. Počet příkazů je skutečně odeslaná práce. FPS níže pocházejí z oddělených sérií.</p><table><caption>Náš renderer před úpravou → po úpravě</caption><thead><tr><th>Renderer / zátěž</th><th>FPS</th><th>Kreslicí příkazy</th></tr></thead><tbody><tr><td>WebGL2 · 512 modelů</td><td>{f(fps(gl,'baseline'))} → {f(fps(gl,'candidate'))}</td><td>308 → {gl['medians']['candidate']['actualCalls']:.0f}</td></tr><tr><td>WebGPU · 1 024 modelů</td><td>{f(fps(wg,'baseline'))} → {f(fps(wg,'candidate'))}</td><td>576 → {wg['medians']['candidate']['actualCalls']:.0f}</td></tr></tbody></table><p>{uitext} Rozdílnou zátěž řádků vzájemně neporovnávej. Instanční buffery pro 512 modelů klesly přibližně o {reduction:.0f} %.</p><table><caption>Samostatné přímé srovnání · 512 modelů</caption><thead><tr><th>Renderer</th><th>FPS</th><th>Kreslicí příkazy</th></tr></thead><tbody><tr><td>Náš WebGL2</td><td>{f(fps(three,'baseline'))}</td><td>{three['medians']['baseline']['actualCalls']:.0f}</td></tr><tr><td>Three.js · instancování</td><td>{f(fps(three,'candidate'))}</td><td>108</td></tr></tbody></table><p><strong>Three.js stále vede.</strong> Vyhlazování a PBR/stíny nejsou sjednocené; měření ovlivňuje souběžná zátěž. Nové fyzické měření na Questu zatím nemáme.</p><p>Variantu se 107 příkazy jsme odmítli: WebGL v ní bylo pomalejší. Menší počet příkazů sám vyšší FPS nezaručuje.</p></section>\n'''
html=html[:start]+new+html[end:];html=html.replace('Nový vizuální test nemění renderer ani nastavení hry.','Optimalizace zachovává geometrii, rozlišení a nastavení hry.');p.write_text(html)
print(json.dumps({'selected':version,'wasm':manifest['build']['wasm'],'calls':c['actualCalls'],'instanceBufferReductionPercent':reduction}))
