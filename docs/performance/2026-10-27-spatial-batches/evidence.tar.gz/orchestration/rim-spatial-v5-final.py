import subprocess,pathlib,json,time
root=pathlib.Path.cwd();deadline=time.time()+1800
while True:
 rows=[]
 for line in (root/'output/spatial-v5-progress.log').read_text().splitlines():
  try:rows.append(json.loads(line))
  except ValueError:continue
 if any(r.get('rc',0)!=0 for r in rows):raise SystemExit('v5 prepare failed; no benchmark started')
 if any(r.get('completed')=='pilot-v5-webgpu' and r.get('rc')==0 for r in rows):break
 if time.time()>deadline:raise SystemExit('bounded prepare wait expired')
 time.sleep(5)
base=root/'output/spatial-batches';dest=base/'final-v5';dest.mkdir();node=subprocess.check_output(['git','config','--local','--get','verification.node'],text=True).strip()
common=['--family','rim-stress','--max-load','2048','--width','2880','--height','1920','--startup-timeout','60000','--max-time','1200'];b0=str(base/'baseline');v5=str(base/'candidate-v5');three=str(base/'three-reference')
stages=[
('profile-gl', ['smoke','--baseline-root',v5,'--backend','webgl','--load','512','--warmup','2000','--sample','6000']),
('profile-wg', ['smoke','--baseline-root',v5,'--backend','webgpu','--load','1024','--warmup','2000','--sample','6000']),
('pairs-gl', ['compare','--baseline-root',b0,'--candidate-root',v5,'--config',str(base/'final/cal-gl/config.json'),'--backend','webgl','--load','512','--warmup','8000','--sample','25000','--pairs','3','--no-profile']),
('pairs-wg-1024', ['compare','--baseline-root',b0,'--candidate-root',v5,'--config',str(base/'final/cal-wg-1024/config.json'),'--backend','webgpu','--load','1024','--warmup','8000','--sample','25000','--pairs','3','--no-profile']),
('cal-three', ['calibrate','--baseline-root',v5,'--backend','webgl','--load','512','--warmup','2000','--sample','6000','--no-profile']),
('three-gl', ['compare','--baseline-root',v5,'--three-root',three,'--config',str(dest/'cal-three/config.json'),'--backend','webgl','--load','512','--warmup','8000','--sample','25000','--pairs','3','--no-profile']),
]
plan={'scope':'Contended desktop M1. Existing unknown Chrome30816 retained. Not physical Quest; native/Three appearance differences remain.','stages':[]}
for name,args in stages:plan['stages'].append({'name':name,'command':[node,'scripts/render-performance.mjs',*args,*common,'--out',str(dest/name)]})
(dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for item in plan['stages']:
 print(json.dumps({'started':item['name']}),flush=True);started=time.time()
 with (dest/(item['name']+'.log')).open('w') as f:res=subprocess.run(item['command'],stdout=f,stderr=subprocess.STDOUT)
 item.update(returncode=res.returncode,elapsedSeconds=time.time()-started)
 (dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'completed':item['name'],'rc':res.returncode}),flush=True)
 if res.returncode:raise SystemExit(res.returncode)
