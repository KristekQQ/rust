import pathlib,json,statistics
base=pathlib.Path('output/spatial-batches')
names=['pilot-webgl','pilot-webgpu','pilot-v3-gl','pilot-v3-wg','pilot-v4-gl','pilot-v5-webgl','pilot-v5-webgpu','final/pairs-gl','final/pairs-wg-1024','final/three-gl','final-v4/profile-gl','final-v4/pairs-gl','final-v4/pairs-wg-1024','final-v4/three-gl','final-v5/pairs-gl','final-v5/pairs-wg-1024','final-v5/three-gl']
summary={'metric':'FPS=1000/mean application RAF interval; medians across runs, not compositor FPS','limits':'Contended desktop M1; existing unknown headlessChrome30816 retained. Different campaigns cannot be mixed into one ranking. Native/Three AA,PBR,shadow,gameplay differences remain. No physical Quest.','campaigns':{}}
for name in names:
 file=base/name/'report.json'
 if not file.exists():continue
 p=json.loads(file.read_text());out={'backend':p['settings']['backend'],'load':p['settings']['load'],'viewport':p['viewport'],'warmupMs':p['settings']['warmup'],'sampleMs':p['settings']['sample'],'profiling':p['settings']['profiling'],'comparisonKind':p['comparisonKind'],'inputsChanged':p.get('driverInputsChangedDuringRun'),'serverErrors':p.get('serverErrors'),'runs':[],'pixels':p.get('comparisons')}
 for r in p.get('results',[]):
  w=r.get('work') or {};g=w.get('gltf') or {};end=(w.get('gauges') or {}).get('end') or {}
  def per(k):return (g.get(k) or {}).get('perApplicationRaf')
  nativeCalls=per('drawCalls');native=nativeCalls is not None
  out['runs'].append({'side':r['label'],'pair':r['pair'],'fps':1000/r['rafInterval']['mean'],'callbackMeanMs':r['rafCallbackCpu']['mean'],'callbackP95Ms':r['rafCallbackCpu']['p95'],'actualCalls':nativeCalls+1 if native else r['renderer'].get('calls'),'actualCallsScope':'glTF actual commands + one FXAA compose; whole stress scene' if native else 'Three renderer.info.render.calls','gltfTrianglesPerRaf':per('trianglesDrawn'),'translatedInstancesPerRaf':per('translatedInstances'),'primitiveTestsPerRaf':per('primitiveTests'),'rootFullyInsidePerRaf':per('rootFullyInside'),'rigidUploadBytesTotal':end.get('rigidUploadBytes'),'instanceBufferBytes':end.get('instanceBufferBytes'),'instanceBuffersCreated':(g.get('instanceBuffersCreated') or {}).get('delta'),'instanceUploadBytes':(g.get('instanceUploadBytes') or {}).get('delta'),'gpuAvailable':r.get('gpuAvailable'),'gpuPassMs':r.get('gpuPassMs'),'glRafGpuMs':r.get('glRafGpuMs')})
 sides={side:[r for r in out['runs'] if r['side']==side] for side in ['baseline','candidate']}
 out['complete']=all(len(runs)==p['settings']['pairs'] for runs in sides.values()) and 'cleanup' in p
 out['medians']={side:{key:statistics.median(r[key] for r in runs) for key in ['fps','callbackMeanMs','callbackP95Ms','actualCalls'] if all(r[key] is not None for r in runs)} for side,runs in sides.items() if runs}
 if all(sides.values()):
  out['pairedFpsRatios']=[c['fps']/b['fps'] for b,c in zip(sides['baseline'],sides['candidate'])]
  out['ratioOfMedianFps']=out['medians']['candidate']['fps']/out['medians']['baseline']['fps']
 summary['campaigns'][name]=out
path=pathlib.Path('docs/performance/2026-10-27-spatial-batches/summary.json');path.write_text(json.dumps(summary,indent=2)+'\n')
for name,p in summary['campaigns'].items():
 print(name,p['medians'],p.get('pairedFpsRatios'))
