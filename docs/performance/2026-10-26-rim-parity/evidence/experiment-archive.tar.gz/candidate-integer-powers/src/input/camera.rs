use glam::{Mat4, Vec3};
use std::collections::HashSet;

pub trait CameraController {
    fn key_down(&mut self, code: String);
    fn key_up(&mut self, code: String);
    fn mouse_move(&mut self, dx: f32, dy: f32);
    fn clear_input(&mut self);

    fn update(&mut self, dt: f32);
    fn matrix(&self) -> Mat4;
    fn position(&self) -> Vec3;
}

pub struct Camera {
    pub position: Vec3,
    yaw: f32,
    pitch: f32,
    pub speed: f32,
    pub sensitivity: f32,
    pressed: HashSet<String>,
    aspect: f32,
}

impl Camera {
    pub fn new(aspect: f32) -> Self {
        Self {
            position: Vec3::new(5.0, 3.0, 5.0),
            yaw: -3.0 * std::f32::consts::FRAC_PI_4,
            pitch: -0.4,
            speed: 2.0,
            sensitivity: 0.002,
            pressed: HashSet::new(),
            aspect,
        }
    }

    /// Configure a free-camera view. All orientation calculations remain in Rust.
    pub fn set_view(&mut self, position: Vec3, target: Vec3) -> bool {
        let direction = target - position;
        if !position.is_finite()
            || !target.is_finite()
            || !direction.is_finite()
            || direction.length_squared() < 1e-8
            || !direction.length_squared().is_finite()
        {
            return false;
        }
        let forward = direction.normalize();
        if forward.x * forward.x + forward.z * forward.z < 1e-4 {
            return false;
        }
        self.position = position;
        self.yaw = forward.z.atan2(forward.x);
        self.pitch = forward.y.asin();
        self.pressed.clear();
        true
    }

    pub fn set_aspect(&mut self, aspect: f32) {
        self.aspect = aspect;
    }

    pub fn key_down(&mut self, code: String) {
        self.pressed.insert(code);
    }

    pub fn key_up(&mut self, code: String) {
        self.pressed.remove(&code);
    }

    pub fn mouse_move(&mut self, dx: f32, dy: f32) {
        self.yaw -= dx * self.sensitivity;
        self.pitch = (self.pitch + dy * self.sensitivity).clamp(-1.54, 1.54);
    }

    pub fn update(&mut self, dt: f32) {
        let speed = self.speed
            * if self.pressed.contains("ShiftLeft") || self.pressed.contains("ShiftRight") {
                4.0
            } else {
                1.0
            };
        let forward = self.forward();
        let right = Vec3::Y.cross(forward).normalize();
        if self.pressed.contains("KeyW") {
            self.position += forward * speed * dt;
        }
        if self.pressed.contains("KeyS") {
            self.position -= forward * speed * dt;
        }
        if self.pressed.contains("KeyA") {
            self.position -= right * speed * dt;
        }
        if self.pressed.contains("KeyD") {
            self.position += right * speed * dt;
        }
        if self.pressed.contains("KeyE") {
            self.position.y += speed * dt;
        }
        if self.pressed.contains("KeyQ") {
            self.position.y -= speed * dt;
        }
    }

    pub fn matrix(&self) -> Mat4 {
        let view = glam::camera::lh::view::look_at_mat4(
            self.position,
            self.position + self.forward(),
            Vec3::Y,
        );
        let proj = glam::camera::lh::proj::directx::perspective(
            std::f32::consts::FRAC_PI_4,
            self.aspect,
            0.1,
            100.0,
        );
        proj * view
    }

    fn forward(&self) -> Vec3 {
        Vec3::new(
            self.yaw.cos() * self.pitch.cos(),
            self.pitch.sin(),
            self.yaw.sin() * self.pitch.cos(),
        )
        .normalize()
    }
}

impl CameraController for Camera {
    fn clear_input(&mut self) {
        self.pressed.clear();
    }

    fn key_down(&mut self, code: String) {
        Camera::key_down(self, code);
    }

    fn key_up(&mut self, code: String) {
        Camera::key_up(self, code);
    }

    fn mouse_move(&mut self, dx: f32, dy: f32) {
        Camera::mouse_move(self, dx, dy);
    }

    fn update(&mut self, dt: f32) {
        Camera::update(self, dt);
    }

    fn matrix(&self) -> Mat4 {
        Camera::matrix(self)
    }

    fn position(&self) -> Vec3 {
        self.position
    }
}
