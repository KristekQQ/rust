from pathlib import Path
p=Path('src/render/gltf_gpu.rs');s=p.read_text();baseline=Path('output/render-performance-rim-parity/candidate-bindings/src/render/gltf_gpu.rs').read_text();assert s==baseline
s=s.replace('struct InstancePage {\n    buffer: wgpu::Buffer,','struct InstancePage {\n    buffer: Option<wgpu::Buffer>,',1)
mark='struct PreparedDraw {\n'
new='''// Bounded pass/view-owned stream. Material uniforms remain per draw group;
// only the existing rigid instance records share one contiguous upload.
struct InstanceStream {
    buffer: wgpu::Buffer,
    capacity: usize,
    last: Vec<RigidInstance>,
    scratch: Vec<RigidInstance>,
}
struct InstanceBinding {
    buffer: wgpu::Buffer,
    offset: u64,
    bytes: u64,
}
'''
assert mark in s;s=s.replace(mark,new+mark,1).replace('    instance: Option<wgpu::Buffer>,','    instance: Option<InstanceBinding>,',1)
s=s.replace('    instance_pages: HashMap<(PipelineKey, usize), Vec<InstancePage>>,','    instance_pages: HashMap<(PipelineKey, usize), Vec<InstancePage>>,\n    instance_streams: HashMap<(PipelineKey, usize), InstanceStream>,',1)
s=s.replace('            instance_pages: HashMap::new(),','            instance_pages: HashMap::new(),\n            instance_streams: HashMap::new(),',1)
s=s.replace('.map(|p| p.capacity * 112 + std::mem::size_of::<Uniform>())\n            .sum();','.map(|p| p.buffer.as_ref().map_or(0, |_| p.capacity * 112) + std::mem::size_of::<Uniform>())\n            .sum::<usize>()\n            + self.instance_streams.values().map(|s| s.capacity * 112).sum::<usize>();',1)
s=s.replace('        self.instance_pages.clear();','        self.instance_pages.clear();\n        self.instance_streams.clear();',1)
mark='''        let mut page_index = 0;
        for group in &scratch.groups {'''
new='''        // Blend preparation shares this key with the opaque preparation and
        // occurs before its submission. It must never overwrite/drop its stream.
        let records = scratch.groups.iter().filter(|g| g.len() > 1).map(|g| g.len()).sum::<usize>();
        let stream_limit = device.limits().max_buffer_size.min(16 * 1024 * 1024);
        let stream_bytes = records.checked_mul(112).filter(|&n| n as u64 <= stream_limit);
        let mut stream = if !blend && records > 0 && stream_bytes.is_some() {
            let capacity = records.next_power_of_two().min((stream_limit / 112) as usize);
            let mut existing = self.instance_streams.remove(&(key, view_slot));
            if existing.as_ref().is_none_or(|s| s.capacity < records) {
                let mut stats = self.counters.get();
                stats.instance_buffers_created += 1;
                self.counters.set(stats);
                existing = Some(InstanceStream {
                    buffer: device.create_buffer(&wgpu::BufferDescriptor {
                        label: Some("glTF pass-view instance stream"),
                        size: (capacity * 112) as u64,
                        usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                        mapped_at_creation: false,
                    }),
                    capacity,
                    last: Vec::new(),
                    scratch: Vec::new(),
                });
            }
            existing.as_mut().unwrap().scratch.clear();
            existing
        } else {
            if !blend { self.instance_streams.remove(&(key, view_slot)); }
            None
        };
        let mut page_index = 0;
        for group in &scratch.groups {'''
assert mark in s;s=s.replace(mark,new,1)
s=s.replace('''                if pages.len() <= page_index || pages[page_index].capacity < capacity {
                    stats.instance_pages_created += 1;
                    stats.instance_buffers_created += 2;''','''                if pages.len() <= page_index || (stream.is_none() && (pages[page_index].buffer.is_none() || pages[page_index].capacity < capacity)) {
                    stats.instance_pages_created += 1;
                    stats.instance_buffers_created += if stream.is_some() { 1 } else { 2 };''',1)
s=s.replace('''                        buffer: device.create_buffer(&wgpu::BufferDescriptor {
                            label: Some("glTF rigid instances"),
                            size: (capacity * 112) as u64,
                            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                            mapped_at_creation: false,
                        }),''','''                        buffer: stream.is_none().then(|| device.create_buffer(&wgpu::BufferDescriptor {
                            label: Some("glTF rigid instances"),
                            size: (capacity * 112) as u64,
                            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                            mapped_at_creation: false,
                        })),''',1)
old='''                if page.last != *payload {
                    queue.write_buffer(&page.buffer, 0, as_bytes(payload));
                    stats.buffer_upload_calls += 1;
                    stats.uniform_upload_bytes += (payload.len() * 112) as u64;
                    stats.instance_upload_bytes += (payload.len() * 112) as u64;
                    page.last.clone_from(payload);
                }
                page_index += 1;
                Some(page.buffer.clone())'''
new='''                let binding = if let Some(s) = stream.as_mut() {
                    let offset = (s.scratch.len() * 112) as u64;
                    s.scratch.extend_from_slice(payload);
                    page.buffer = None;
                    page.last.clear();
                    InstanceBinding { buffer: s.buffer.clone(), offset, bytes: (payload.len() * 112) as u64 }
                } else {
                    let buffer = page.buffer.as_ref().expect("standalone instance buffer");
                    if page.last != *payload {
                        queue.write_buffer(buffer, 0, as_bytes(payload));
                        stats.buffer_upload_calls += 1;
                        stats.uniform_upload_bytes += (payload.len() * 112) as u64;
                        stats.instance_upload_bytes += (payload.len() * 112) as u64;
                        page.last.clone_from(payload);
                    }
                    InstanceBinding { buffer: buffer.clone(), offset: 0, bytes: (payload.len() * 112) as u64 }
                };
                page_index += 1;
                Some(binding)'''
assert old in s;s=s.replace(old,new,1)
mark='''        if !blend {
            self.active_instance_pages'''
new='''        if let Some(mut s) = stream {
            if s.last != s.scratch {
                queue.write_buffer(&s.buffer, 0, as_bytes(&s.scratch));
                let bytes = (s.scratch.len() * 112) as u64;
                let mut stats = self.counters.get();
                stats.buffer_upload_calls += 1;
                stats.uniform_upload_bytes += bytes;
                stats.instance_upload_bytes += bytes;
                self.counters.set(stats);
                std::mem::swap(&mut s.last, &mut s.scratch);
            }
            self.instance_streams.insert((key, view_slot), s);
        }
        if !blend {
            self.active_instance_pages'''
assert mark in s;s=s.replace(mark,new,1)
old='''            if let Some(buffer) = d.instance.as_ref().or(d.skin.as_ref()) {
                pass.set_vertex_buffer(1, buffer.slice(..));
            }'''
new='''            if let Some(binding) = &d.instance {
                pass.set_vertex_buffer(1, binding.buffer.slice(binding.offset..binding.offset + binding.bytes));
            } else if let Some(buffer) = &d.skin {
                pass.set_vertex_buffer(1, buffer.slice(..));
            }'''
assert old in s;s=s.replace(old,new,1)
p.write_text(s)
