# Actual Rome GPU investigation — 2026-10-26

Status: experiments in progress, not a release or a full-game/Quest parity claim.

## Confirmed limiting path

At 2880x1920 DPR1, profiler OFF, three alternating 8s/25s pairs:
- Native WebGL2 (7b0 stream candidate): RAF mean20.829/20.812/20.888ms (~48FPS), CPU median1.3/1.2/1.3ms.
- Unchanged original Three r170 Rome: RAF mean16.666ms (~60FPS), CPU median3.1/3.0/3.1ms.
- The native CPU is already faster for this static view; more CPU-only tuning cannot explain or resolve the observed cadence gap.
- Cross-engine image/work equivalence is NOT established: original hardware MSAA4 vs native FXAA, different shadow filters/shader semantics and independent gameplay remain explicit.

One3s/8s native GL diagnostic per mode: full48.00FPS, no-FXAA48.88FPS, no-shadows60.00FPS, high-performance context48.13FPS. No quality-reducing ablation is retained. This localizes shadow-dependent work; it does not alone prove a particular shader instruction dominates.

## Shadow dispatch experiment

Frozen release669d72f18db2602bbc6b56187964ab26671bcc16ba8a1eeffd17a43d57977fcd (candidate-shadow): move light/resource dispatch outside the unchanged3x3 PCF loops in glTF and vertex-color shaders. Preserve UV, texture dimensions, compare sampler, normal/slope bias, tap order, per-tap min(static,dynamic), accumulation and division. No render settings or shadow update-policy changes.

Maintained scene-appearance/shadow-cache/gltf-full:6/6 backend cases PASS. Independent frozen7b0 pixel oracle:96/96 EXACT, four distinguishable lights, masks0/1/2/3, normalbias0/.12, both receiver paths with separate visible-shadow controls. Initial oracle failures were setup errors (unsupported SDK backend string, unavailable per-light visibility fields), preserved in shadow-pixels and shadow-pixels-v2. Fixed fixture uses auto+actualbackend assertion and actual aggregate caster counts with cullingdisabled. No runtime patch or tolerance relaxation resulted.

A single3s/8s OFF pilot at2880x1920 gives57.26FPS (RAFmean17.465ms,p9516.8,p9933.4), vs prior~48. Promising, NOT repeated acceptance. Astra independently found no shader algebra defect; its two oracle concerns (indistinguishable lights and tolerance-only gate) were fixed. Pixel oracle now requires exact equality.

Next declared experiment hoists uniform static-only/dynamic-only/both selection outside each helper's tap loop; internal EffectsUniforms layer masks are constructed solely from two occupancy booleans (0..3). Test against669d and7b0 with the same oracle and matched repeated timings. Reject if added shader size gives no repeatable gain.

Live8443 and8878 remain unchanged. Local source is uncommitted. CPU-only binding/stream changes remain under separate acceptance; their counter reductions do not prove GPU/Quest improvement.

## Completed first long pairs

7b0→9223, three8s/25s OFF GL pairs at2880x1920:48.002/47.499/47.842→60.002/60.002/59.922FPS. LateRAF intervals300/313/304→0/0/2. ActualRome captures pass unchanged channel8/fraction.001 gates; maxchannel6/255 with meanabsolute~1e-5/255, NOT whole-image exact equality. Independent fixture oracles remain96/96exact per experiment.

Direct9223vsoriginalThree long pairs: native59.962/57.924/57.884 versusThree60.002/60.003/60.002. Preserve unfavorable results: this does NOT establish stable parity or a throughput win. Three still holds60 while native falls~3.5% below in two runs.

Layer increment669d→9223 measured separately, final source review no scoped findings. The next declared experiment ports Three's constant-index light-loop unrolling, preserving four ordered contributions and zero-color guards; expands oracle to simultaneous colored lights, alternating zeros, legacy/authored, metallic and shadowcount0/1/4. Source is prepared, pkg9223 intentionally stale until serialGPU runs finish; no build during timing. Existing warm input snapshots remain immutable.
