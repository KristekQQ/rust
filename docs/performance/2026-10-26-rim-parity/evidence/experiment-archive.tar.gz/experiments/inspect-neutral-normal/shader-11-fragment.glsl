#version 300 es

precision highp float;
precision highp int;

struct Uniforms {
    mat4x4 inverse_view_projection;
    mat4x4 view_projection;
    vec4 camera;
    vec4 light_position;
    vec4 light_color;
    vec4 params;
    vec4 mask_params;
    mat4x4 shadow_view_projection;
    vec4 volume_params;
    vec4 environment_center;
    vec4 environment_half_extents;
    vec4 sky_cube_params;
    vec4 sky_cube_center;
    vec4 sky_cube_half_extents;
    vec4 reflection_trace;
    vec4 receiver_bounds_min;
    vec4 receiver_bounds_max;
};
struct Output {
    vec4 position;
    vec2 uv;
};
uniform highp sampler2D _group_0_binding_0_fs;

layout(std140) uniform Uniforms_block_0Fragment { Uniforms _group_0_binding_3_fs; };

uniform highp sampler2DShadow _group_1_binding_0_fs;

uniform highp sampler2DShadow _group_1_binding_1_fs;

uniform highp sampler2D _group_0_binding_2_fs;

smooth in vec2 _vs2fs_location0;
layout(location = 0) out vec4 _fs2p_location0;

vec3 world_at(vec2 uv, float depth) {
    mat4x4 _e4 = _group_0_binding_3_fs.inverse_view_projection;
    vec4 p = (_e4 * vec4(((uv.x * 2.0) - 1.0), (1.0 - (uv.y * 2.0)), depth, 1.0));
    return (p.xyz / vec3(p.w));
}

bool inside(vec2 uv_1) {
    bool local = false;
    if (all(greaterThan(uv_1, vec2(0.0)))) {
        local = all(lessThan(uv_1, vec2(1.0)));
    } else {
        local = false;
    }
    bool _e12 = local;
    return _e12;
}

vec4 scene_at(vec2 uv_2) {
    vec4 _e4 = textureLod(_group_0_binding_0_fs, vec2(uv_2), 0.0);
    return _e4;
}

float depth_at(vec2 uv_3) {
    vec4 _e3 = _group_0_binding_3_fs.params;
    ivec2 size = ivec2(_e3.zw);
    vec4 _e8 = _group_0_binding_3_fs.params;
    ivec2 pixel = min(max(ivec2((uv_3 * _e8.zw)), ivec2(0)), (size - ivec2(1)));
    vec4 _e26 = _group_0_binding_3_fs.params;
    vec4 _e30 = textureLod(_group_0_binding_2_fs, vec2(((vec2(pixel) + vec2(0.5)) / _e26.zw)), 0.0);
    vec3 packed_ = _e30.xyz;
    return clamp(dot(packed_, vec3(1.0, 0.003921569, 1.53787e-5)), 0.0, 1.0);
}

float volume_visibility(vec3 position) {
    bool local_1 = false;
    bool local_2 = false;
    mat4x4 _e3 = _group_0_binding_3_fs.shadow_view_projection;
    vec4 clip = (_e3 * vec4(position, 1.0));
    if ((clip.w <= 0.0)) {
        return 0.0;
    }
    vec3 ndc = (clip.xyz / vec3(clip.w));
    vec2 uv_5 = vec2(((ndc.x * 0.5) + 0.5), (0.5 - (ndc.y * 0.5)));
    bool _e26 = inside(uv_5);
    if (!(!(_e26))) {
        local_1 = (ndc.z <= 0.0);
    } else {
        local_1 = true;
    }
    bool _e35 = local_1;
    if (!(_e35)) {
        local_2 = (ndc.z >= 1.0);
    } else {
        local_2 = true;
    }
    bool _e43 = local_2;
    if (_e43) {
        return 0.0;
    }
    float edge = min(min(uv_5.x, (1.0 - uv_5.x)), min(uv_5.y, (1.0 - uv_5.y)));
    float cone_fade = smoothstep(0.0, 0.04, edge);
    float _e62 = _group_0_binding_3_fs.volume_params.x;
    if ((_e62 < 0.5)) {
        return cone_fade;
    }
    float reference_depth = (ndc.z - 8e-5);
    float static_visibility = textureLod(_group_1_binding_0_fs, vec3(uv_5, reference_depth), 0.0);
    float dynamic_visibility = textureLod(_group_1_binding_1_fs, vec3(uv_5, reference_depth), 0.0);
    return (min(static_visibility, dynamic_visibility) * cone_fade);
}

vec3 god_rays(vec2 uv_4, vec3 source) {
    float ray_length = 0.0;
    float transmission = 1.0;
    vec3 radiance = vec3(0.0);
    uint step_ = 0u;
    float _e5 = _group_0_binding_3_fs.light_color.x;
    float _e9 = _group_0_binding_3_fs.light_color.y;
    float _e14 = _group_0_binding_3_fs.light_color.z;
    if ((max(max(_e5, _e9), _e14) <= 0.0)) {
        return source;
    }
    float _e18 = depth_at(uv_4);
    vec3 _e21 = world_at(uv_4, min(_e18, 0.999999));
    vec4 _e24 = _group_0_binding_3_fs.camera;
    vec3 camera_to_surface = (_e21 - _e24.xyz);
    float surface_distance = length(camera_to_surface);
    if ((surface_distance < 0.0001)) {
        return source;
    }
    vec3 direction = (camera_to_surface / vec3(surface_distance));
    float _e35 = _group_0_binding_3_fs.volume_params.z;
    ray_length = min(surface_distance, _e35);
    if ((_e18 >= 0.999999)) {
        float _e43 = _group_0_binding_3_fs.volume_params.z;
        ray_length = _e43;
    }
    float _e44 = ray_length;
    float step_length = (_e44 / 32.0);
    float _e50 = _group_0_binding_3_fs.volume_params.y;
    float _e54 = _group_0_binding_3_fs.params.x;
    float density = (_e50 * _e54);
    float step_transmission = exp((-(density) * step_length));
    vec4 _e61 = _group_0_binding_3_fs.params;
    vec2 pixel_1 = floor((uv_4 * _e61.zw));
    float jitter = fract((52.982918 * fract(dot(pixel_1, vec2(0.06711056, 0.00583715)))));
    bool loop_init = true;
    while(true) {
        if (!loop_init) {
            uint _e151 = step_;
            step_ = (_e151 + 1u);
        }
        loop_init = false;
        uint _e81 = step_;
        if ((_e81 < 32u)) {
        } else {
            break;
        }
        {
            uint _e84 = step_;
            float t = ((float(_e84) + jitter) * step_length);
            vec4 _e90 = _group_0_binding_3_fs.camera;
            vec3 position_1 = (_e90.xyz + (direction * t));
            vec4 _e96 = _group_0_binding_3_fs.light_position;
            vec3 to_light = (_e96.xyz - position_1);
            float distance_squared = max(dot(to_light, to_light), 0.01);
            vec3 light_direction = (to_light * inversesqrt(distance_squared));
            float cosine = clamp(dot(direction, light_direction), -1.0, 1.0);
            float phase = ((1.0 - (0.45 * 0.45)) / (12.566371 * pow(max(((1.0 + (0.45 * 0.45)) - ((2.0 * 0.45) * cosine)), 0.001), 1.5)));
            float attenuation = (5.0 / (1.0 + (0.2 * distance_squared)));
            float _e131 = volume_visibility(position_1);
            vec3 _e132 = radiance;
            vec4 _e135 = _group_0_binding_3_fs.light_color;
            float _e140 = transmission;
            radiance = (_e132 + (max(_e135.xyz, vec3(0.0)) * ((((_e140 * (1.0 - step_transmission)) * phase) * attenuation) * _e131)));
            float _e149 = transmission;
            transmission = (_e149 * step_transmission);
        }
    }
    vec3 _e154 = radiance;
    float _e158 = _group_0_binding_3_fs.volume_params.w;
    vec3 scattering = (_e154 * _e158);
    return (source + (scattering / (vec3(1.0) + scattering)));
}

void main() {
    Output input_ = Output(gl_FragCoord, _vs2fs_location0);
    vec4 _e2 = scene_at(input_.uv);
    vec3 _e5 = god_rays(input_.uv, _e2.xyz);
    float _e10 = _group_0_binding_3_fs.params.y;
    _fs2p_location0 = vec4(_e5, ((_e10 > 0.5) ? 1.0 : _e2.w));
    return;
}

