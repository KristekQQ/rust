#version 300 es

precision highp float;
precision highp int;

struct Output {
    vec4 position;
    vec2 uv;
};
smooth out vec2 _vs2fs_location0;

void main() {
    uint index = uint(gl_VertexID);
    Output output_ = Output(vec4(0.0), vec2(0.0));
    vec2 positions[3] = vec2[3](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
    vec2 p = positions[index];
    output_.position = vec4(p, 0.0, 1.0);
    output_.uv = vec2(((p.x + 1.0) * 0.5), ((1.0 - p.y) * 0.5));
    Output _e29 = output_;
    gl_Position = _e29.position;
    _vs2fs_location0 = _e29.uv;
    gl_Position.yz = vec2(-gl_Position.y, gl_Position.z * 2.0 - gl_Position.w);
    gl_PointSize = 1.0;
    return;
}

