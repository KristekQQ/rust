# Restore ordinary WebGL VR entry — 2026-10-31

Physical Quest retest of the first-bind patch loaded the correct83d1e680 build, but repeatedly failed the next guard: `WebGL XR framebuffer is not active or complete`. The preceding first-bind patch fixed one independently reproduced check, **not physical-device acceptance**. Actual run records are preserved here.

## Recovery

Ordinary Rome and Neon WebGL entry buttons now use the original canvas-transfer route. The shared-context scene-foveation prototype is explicit only via `xrPresentation=shared-framebuffer`; unavailable capability still uses the existing fallback. WebGPU eye/presentation code, content, resolution and effects are unchanged. This restores the established presentation choice; it does **not** solve shared-context FFR or claim foveation enabled.

The unresolved experimental guard is retained. Its error now includes hexadecimal framebuffer status. Independent Lupa primary-source audit confirms DRAW_FRAMEBUFFER is supported and that opaque status has both active-frame and native-GL completeness conditions. No evidence justified dropping the guard or blindly replacing its target. Numeric status and before/after-eye phase diagnostics are the next device investigation; no speculative interop rewrite was made.

Sources: [Chromium WebGL checks](https://raw.githubusercontent.com/chromium/chromium/main/third_party/blink/renderer/modules/webgl/webgl_rendering_context_base.cc), [XR layer lifecycle](https://raw.githubusercontent.com/chromium/chromium/main/third_party/blink/renderer/modules/xr/xr_webgl_layer.cc).

## Actual verification

- Release WASM/minified production build PASS; current source/pkg fingerprint matches.
- Maintained `info-rim` and `info-neon-arena` now click the actual example VR button (rather than generic SDK enter). Both enter and produce real stereo images with the safe route. Strengthened reruns also advertise foveateBoundTexture capability, so missing desktop support cannot accidentally hide the old unsafe selection. Both PASS.
- `xr-gl-presentation` PASS, including negative/state/first-bind controls, context loss/reentry and6exact independent original/shared stereo image pairs. It still uses simulator FBOs, not a physical opaque XR layer.
-3distinct scenarios passed; the2button scenarios were additionally rerun after strengthening their capability oracle. Do not count this as5distinct scenarios or a full publication gate.
-5actual trusted-CA HTTPS/no-store/hash checks PASS for both entries/main modules and current WASM. Same owned server PID95623 and stable8443 URLs; no certificate/server restart.

Commands:

```sh
bash scripts/build-release.sh
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgl --page info-rim,info-neon-arena,xr-gl-presentation
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgl --page info-rim,info-neon-arena
```

Native tests were not rerun for the wasm-only error-string/example-selection patch. Browser and physical-device evidence remain distinct. No new speed/quality/FFR success claim, commit/push/merge/CI. Actual Quest ordinary-entry retest remains pending user confirmation; prototype completeness is explicitly unresolved. Earlier reports/archives and the separate animation benchmark checkout are preserved.
