# Quest WebGL XR first-bind fix — 2026-10-31

Actual Quest Browser154 entered then immediately ended WebGL XR with `WebGL XR framebuffer must belong to the renderer context`. Multiple real runs at21:07UTC show the same failure. This was our pre-bind ownership check, not evidence that the browser had supplied another context.

Chromium initializes opaque XR framebuffers with HasEverBeenBound false, and isFramebuffer rejects them before first public bind. Primary implementation: [isFramebuffer](https://chromium.googlesource.com/chromium/src/+/HEAD/third_party/blink/renderer/modules/webgl/webgl_rendering_context_base.cc), [opaque framebuffer implementation](https://raw.githubusercontent.com/chromium/chromium/main/third_party/blink/renderer/modules/webgl/webgl_framebuffer.cc). The simulator had prebound its normal framebuffer during attachment setup and masked this condition.

## Minimal correction

Only an initially unrecognized framebuffer takes the cold probe: save DRAW binding, bind candidate DRAW, validate actual identity plus post-bind isFramebuffer and completeness, restore exact previous DRAW on success/error. READ remains untouched, attachments are never inspected/changed, and the backend resumes with the original state/cache assumptions. Recognized framebuffers retain the old fast path: do not describe this as a new per-frame lifetime/completeness oracle. Foreign/deleted/incomplete inputs still fail before consuming staged eyes. Rendering/submission remains in pinned wgpu; no broad state-validation removal, new renderer, quality reduction or WebGPU staging change.

Independent Lupa review — GPT-6.1 Sol Medium — confirmed the mechanism and found no material defect in the helper by inspection. Parent executed tests.

## Fresh evidence

- First-bind injection added to maintained xr-gl-presentation: old release fails with the exact real Quest message. `failing-before.log` retained.
- A test-only attempt to replace a frozen SDK property failed; corrected to import the already-loaded raw WASM module in the fixture. That failed test log is retained, not reported as a renderer failure.
- Current xr-gl-presentation PASS: injected initially-unrecognized FBO, one cold bind/restoration, foreign/deleted/incomplete input rejection, distinct READ/DRAW state on failed probes, valid stereo completion after rejection, context loss/reinitialization/reentry. Six independent canvas-transfer/shared stereo capture pairs are exactly equal.
- Scene foveation symmetric/asymmetric PASS; Rome shared-context actual gameplay PASS; Neon XR PASS; WebGPU attachment/stereo regression PASS. Six distinct maintained browser scenarios passed across the scoped runs. Tests mount current fixtures against the verified/minified production package. Native tests do not compile this wasm-only adapter and were not rerun; no historical native/full-gate count is claimed.
- Release build, final source/pkg fingerprint, diff-check PASS. Six actual trusted-CA HTTPS requests match production hashes and no-store headers, including both examples, host and WASM. No TLS bypass.

Exact commands:

```sh
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgl --page xr-gl-presentation
bash scripts/build-release.sh
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgl --page xr-gl-presentation,xr-scene-foveation,xr-scene-foveation-asymmetric,rim-gameplay-gl-shared,neon-arena
# After fixing the test-only frozen-SDK access, rerun only affected/new coverage:
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgl --page xr-gl-presentation,neon-arena-xr
VERIFY_WASM_PROFILE=release node scripts/test-browser.mjs --production-root output/production --backend webgpu --page webxr-webgpu
```

The first scoped invocation executed FFR, asymmetric FFR, XR presentation and Rome-shared scenarios; its failed presentation fixture was repaired and rerun. Neon-XR is separately explicit in the next invocation. Logs plus per-suite result snapshots record actual executed counts, not the length of the requested comma list.

## Delivery / limits

The existing release helper automatically rebuilds output/production. The local server consequently picked up the package when packaging completed; the above targeted checks then completed against those bytes. Same owned PID95623/HTTPS192.168.0.17:8443, no server restart/certificate change. Ordinary backend-only URLs remain stable; no version query is required.

This fixes a reproduced check failure. **Real Quest reentry and actual hardware FFR effect still require user retest**; observational foveation shims do not prove hardware quality/FPS. No new performance win, full publication gate, commit, push, merge or CI. Earlier animation-workspace benchmark candidates remain separate/unmodified. The unrelated WebGPU end-of-session getViewSubImage error is not repaired by this patch.
