"""Offline verification/reduction for existing native/Three driver reports."""
import gzip,hashlib,json,math,statistics
from pathlib import Path
root=Path.cwd();out=root/'output/current-three-comparison';docs=root/'docs/performance/current-three-comparison'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stats(a):
 a=sorted(a)
 return {'count':len(a),'mean':sum(a)/len(a),'median':a[math.ceil(len(a)*.5)-1],'p95':a[math.ceil(len(a)*.95)-1],'p99':a[math.ceil(len(a)*.99)-1],'max':a[-1]}
reports={be:load(out/f'{be}-three/report.json') for be in ['wg','gl']};runs=[];pairs=[]
for be,d in reports.items():
 assert len(d['results'])==6 and not d['driverInputsChangedDuringRun'] and not any(d['serverErrors'].values())
 assert all(c['complete'] for c in d['cleanup'])
 raw={r['id']:r for r in json.loads(gzip.decompress((out/f'{be}-three/raw.json.gz').read_bytes()))}
 for r in d['results']:
  x=raw[r['id']];assert not x['profiling'] and not x['abort'] and x['samples']==[] and x['gpu']==[]
  assert x['measurement']['mode']=='minimal' and x['measurement']['samplerPolls']==0 and not x['measurement']['overflow']
  assert x['actualQualityState']['canvas']=={'width':1280,'height':720}
  assert not x['glRafGpu'] or (not x['glRafGpu']['enabled'] and not x['glRafGpu']['queriesBegun'])
  cpu=stats([f['cpu'] for f in x['frames']]);frame=stats([b['stamp']-a['stamp'] for a,b in zip(x['frames'],x['frames'][1:])])
  for key in cpu:assert abs(cpu[key]-r['rafCallbackCpu'][key])<1e-8
  for key in frame:assert abs(frame[key]-r['rafInterval'][key])<1e-8
  native=r['label']=='baseline'; actual=r['work'].get('gltf') if native else None
  runs.append({'campaign':be,'pair':r['pair']+1,'renderer':('native-'+be) if native else 'Three-WebGL2','fps':1000/frame['mean'],'frameIntervalMs':frame,'callbackWallMs':cpu,'draws':actual['drawCalls']['perApplicationRaf'] if native else r['renderer']['drawCalls'],'triangles':actual['trianglesDrawn']['perApplicationRaf'] if native else r['renderer']['triangles'],'workScope':'native glTF command/triangle counter' if native else 'Three renderer.info.render','nativeWorkPerRaf':({k:actual[k]['perApplicationRaf'] for k in ['pipelineChanges','bindGroupChanges','bufferUploadCalls','instanceUploadBytes','uniformUploadBytes','instancePool.buffersCreated','instancePool.bindGroupsCreated']} if native else None),'metadata':r['metadata'],'quality':r['actualQualityState'],'powerBefore':r['powerBefore'],'powerAfter':r['powerAfter'],'capture':r['capture'],'gpuMs':None})
 for pair in range(1,4):
  a=next(r for r in runs if r['campaign']==be and r['pair']==pair and r['renderer'].startswith('native-'));b=next(r for r in runs if r['campaign']==be and r['pair']==pair and r['renderer']=='Three-WebGL2')
  pairs.append({'campaign':be,'pair':pair,'nativeFps':a['fps'],'threeFps':b['fps'],'nativeVsThreeFpsRatio':a['fps']/b['fps'],'nativeCallbackMeanMs':a['callbackWallMs']['mean'],'threeCallbackMeanMs':b['callbackWallMs']['mean']})
 # Verify identical requested shared GLB bytes and pinned reference module, not merely declared asset names.
 manifests={label:{x['url']:x for x in load(out/f'{be}-three/manifest-{label}.json')} for label in ['baseline','candidate']}
 for f in ['/assets/models/rim/rim-city.glb','/assets/models/rim/drone-orbiter.glb','/assets/models/rim/layout.json']:
  assert manifests['baseline'][f]['sha256']==manifests['candidate'][f]['sha256']
 assert manifests['candidate']['/examples/rim-three/vendor/three.module.js']['sha256']=='ce1fa418de16a19495a9f72495580e3015d7745c296d3ce0485897f902ddedfb'
summary=[]
for be in reports:
 for native in [True,False]:
  a=[r for r in runs if r['campaign']==be and r['renderer'].startswith('native-')==native]
  summary.append({'campaign':be,'renderer':a[0]['renderer'],'meanOfRunFps':statistics.mean(r['fps'] for r in a),'fpsRange':[min(r['fps'] for r in a),max(r['fps'] for r in a)],'meanOfRunCallbackMs':statistics.mean(r['callbackWallMs']['mean'] for r in a),'drawRange':[min(r['draws'] for r in a),max(r['draws'] for r in a)],'triangleRange':[min(r['triangles'] for r in a),max(r['triangles'] for r in a)]})
pixels=load(out/'pixel-audit.json');assert len(pixels)==6
result={'scope':'limited base-color shared city/drone static profile; not exact equal GPU work, full gameplay, production quality or Quest','runs':runs,'pairs':pairs,'summary':summary,'pixelAudit':pixels,'gpuMs':None}
(docs/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Current native renderer vs pinned Three r170 — 2026-10-31','','Fresh direct comparison, not historical numbers and not the preceding moving-camera A/A test. Current local native release WASM59615b78/sourcec8b6ee44; Three r170 uses the existing per-part InstancedMesh reference. Both sides request the same city/drone GLB bytes,2048orbiters in the same positions and Idle@0, same gate camera and1280x720DPR1. Actual asset/module request hashes were checked.','','**This is a static limited common base-color profile:** no AA, lighting, shadows, fog, tone mapping or postprocessing on either side. It is not production graphics, active animations/gameplay or VR. The new animation allocation optimization is therefore not the work being stressed. Native per-primitive culling and Three aggregate instance bounds still submit different triangle counts. Exact cross-engine pixel equality is not claimed. Do not turn these results into a universal equal-quality renderer ranking.','','## Main result','','Each row averages three per-run FPS values (1000/mean RAF interval), not inverse-median cadence. Three is shown separately beside each native campaign, preserving time-local paired observations.','','| Campaign | Renderer | FPS mean (run range) | Mean callback wall ms | Actual draws | Submitted triangles |','|---|---|---:|---:|---:|---:|']
for r in summary:lines.append(f'| {r["campaign"]} | {r["renderer"]} | {r["meanOfRunFps"]:.3f} ({r["fpsRange"][0]:.3f}–{r["fpsRange"][1]:.3f}) | {r["meanOfRunCallbackMs"]:.4f} | {r["drawRange"][0]:.1f}–{r["drawRange"][1]:.1f} | {r["triangleRange"][0]:,.0f}–{r["triangleRange"][1]:,.0f} |')
lines+=['','Native counts are actual glTF command/triangle counters, not the legacy unbatched estimate. Three counts come from renderer.info.render; this profile has no postprocess pass, but counter scopes remain labelled. Do not normalize different triangles into hypothetical equal-work FPS. CPU callback is wall time, including browser/API/scheduling, not pure compute. GPU timings are unavailable in clean profiler-off samples; shorter CPU callback does not automatically imply higher FPS.','','## Every pair','','| Native backend | Pair | Native FPS | Three FPS | Native callback mean ms | Three callback mean ms |','|---|---:|---:|---:|---:|---:|']
for p in pairs:lines.append(f'| {p["campaign"]} | {p["pair"]} | {p["nativeFps"]:.3f} | {p["threeFps"]:.3f} | {p["nativeCallbackMeanMs"]:.4f} | {p["threeCallbackMeanMs"]:.4f} |')
lines+=['','## Tails and exact image observations','','| Campaign | Pair | Side | Frame p95/p99/max ms | Callback p95/p99/max ms |','|---|---:|---|---|---|']
for r in runs:
 f=r['frameIntervalMs'];c=r['callbackWallMs'];lines.append(f'| {r["campaign"]} | {r["pair"]} | {r["renderer"]} | {f["p95"]:.2f}/{f["p99"]:.2f}/{f["max"]:.2f} | {c["p95"]:.2f}/{c["p99"]:.2f}/{c["max"]:.2f} |')
lines+=['','Independently decoded native/Three PNG differences (no tolerance adjustment):','','| Campaign | Pair | Changed RGBA pixels | Max channel difference /255 |','|---|---:|---:|---:|']
for p in pixels:lines.append(f'| {p["backend"]} | {p["pair"]} | {p["changedPixels"]} | {p["maxChannelDelta"]} |')
lines+=['','These are cross-engine output differences in an already limited profile, not an accepted native before/after pixel match or a fix for historical native A/B/C/D blockers. Whole gameplay and Quest acceptance remain separate.','','## Execution and reproducibility','','12clean runs:3alternating pairs for each native backend against ThreeWebGL2.8s warmup/25s sample; native-only2s/5s fixed-load calibration is pilot-only. Actual profiler=false/minimal sampler/zero sampled polls/no recorder overflow, no server errors/input drift; full raw-series distributions independently recomputed. Configured headless Chrome, matched browser version within each campaign, host power/thermal endpoints retained; normal desktop contention remains unisolated. No API observer/GPU timer during clean runs. [Protocol and exact commands](PROTOCOL.md).','','Raw local evidence: output/current-three-comparison/{wg-calibration,gl-calibration,wg-three,gl-three}; raw.json.gz/full manifests/PNG/report.json per campaign. analyze.py and pixel-audit.json preserve reduction/image evidence. Initial redundant --candidate-root flag attempt failed CLI validation before browser startup; error log preserved. No runtime/driver source edits, native rebuild/test rerun, deployment/shared8443 restart/commit/push/merge. This report is a new measurement only; it does not replace earlier evidence or claim a production/VR victory.']
(docs/'REPORT.md').write_text('\n'.join(lines)+'\n')
manifest={'nativeBuild':reports['wg']['baselineBuildFingerprint'],'three':{'version':'r170','moduleSha256':'ce1fa418de16a19495a9f72495580e3015d7745c296d3ce0485897f902ddedfb','representation':'existing per-part InstancedMesh','usesNativeWasm':False},'browser':{be:d['browser'] for be,d in reports.items()},'driverIdentity':{be:d['driverIdentity'] for be,d in reports.items()},'reportHashes':{be:sha(out/f'{be}-three/report.json') for be in reports},'analysisSha256':sha(out/'analyze.py'),'pixelAuditSha256':sha(out/'pixel-audit.json'),'docs':{p.name:sha(p) for p in docs.iterdir() if p.name!='MANIFEST.json'},'runtimeChanged':False,'deployed':False,'scope':result['scope']}
(docs/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(summary))
