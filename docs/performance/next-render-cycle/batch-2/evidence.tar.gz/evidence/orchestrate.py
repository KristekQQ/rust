import os, json, subprocess, time, pathlib, datetime
root=pathlib.Path('/private/tmp/rust-next-render-cycle-2');out=root/'output/next-render-cycle-2';node='/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
os.chdir(root);env=os.environ.copy();env['PATH']=str(pathlib.Path(node).parent)+':'+env['PATH'];env['VERIFY_WASM_PROFILE']='release'
journal=[]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def environment(label):
    data={'at':utc(),'phase':label}
    try:
        rows=subprocess.check_output(['ps','-axo','pid,pcpu,command'],text=True).splitlines();data['gpuProcesses']=[{'pid':int(r.split()[0]),'cpuPercent':float(r.split()[1]),'browserGPUProcess':True} for r in rows if '--type=gpu-process' in r and 'Chrome' in r]
    except Exception as e:data['processUnavailable']=str(e)
    try:
        import plistlib
        entries=plistlib.loads(subprocess.check_output(['ioreg','-r','-c','AGXAccelerator','-a']))
        data['aggregateGPU']=[e.get('PerformanceStatistics',{}) for e in entries]
    except Exception as e:data['gpuStatisticsUnavailable']=str(e)
    (out/('environment-'+label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
def run(label,args):
    cmd=[node,'scripts/render-performance.mjs']+args+['--out',str(out/label)]
    item={'label':label,'argv':cmd,'cwd':str(root),'start':utc(),'status':'RUNNING'};journal.append(item);(out/'measurement-commands.json').write_text(json.dumps(journal,indent=2)+'\n')
    print('START '+label,flush=True);start=time.time()
    with open(out/(label+'.log'),'w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    item.update(end=utc(),elapsedSeconds=time.time()-start,exitCode=p.returncode,status='PASS' if p.returncode==0 else 'FAIL');(out/'measurement-commands.json').write_text(json.dumps(journal,indent=2)+'\n')
    print(item['status']+' '+label,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
base='output/next-render-cycle-2/baseline';candidate='output/next-render-cycle-2/candidate'
common=['--family','rim-stress','--load','2048','--max-load','2048','--width','1280','--height','720','--warmup','8000','--sample','25000','--no-profile','--max-time','900']
environment('before')
for be in ['webgpu','webgl']:
 run('calibrate-'+be,['calibrate','--baseline-root',base,'--backend',be]+common)
for be in ['webgpu','webgl']:
 environment('before-pairs-'+be)
 run('pairs-'+be,['compare','--baseline-root',base,'--candidate-root',candidate,'--config',str(out/('calibrate-'+be)/'config.json'),'--backend',be,'--pairs','3']+common)
 environment('after-pairs-'+be)
for be in ['webgpu','webgl']:
 run('candidate-stages-'+be,['smoke','--baseline-root',candidate,'--backend',be,'--family','rim-stress','--load','1024','--max-load','1024','--width','1280','--height','720','--warmup','4000','--sample','10000','--max-time','180'])
for be in ['webgpu','webgl']:
 run('candidate-ordinary-'+be,['smoke','--baseline-root',candidate,'--backend',be,'--family','rim-static','--load','1','--width','1280','--height','720','--warmup','8000','--sample','25000','--no-profile','--max-time','180'])
environment('after')
print('ALL MEASUREMENTS COMPLETE',flush=True)
