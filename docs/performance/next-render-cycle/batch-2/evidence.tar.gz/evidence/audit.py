from pathlib import Path
import json,gzip,hashlib,statistics,math,datetime
root=Path('/private/tmp/rust-next-render-cycle-2');out=root/'output/next-render-cycle-2';doc=root/'docs/performance/next-render-cycle/batch-2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):
 a=sorted(v);q=lambda n:a[max(0,math.ceil(len(a)*n)-1)]
 return dict(count=len(a),mean=sum(a)/len(a),median=q(.5),p95=q(.95),p99=q(.99),max=a[-1])
summary={'version':1,'scope':'batch2 static exact-plan cache; desktop, no physical Quest or fresh Three comparison','protocol':{'warmupMs':8000,'sampleMs':25000,'pairs':3,'order':'AB/BA/AB','width':1280,'height':720,'DPR':1,'family':'rim-stress','load':2048,'profiling':False},'backends':{},'diagnostics':{},'ordinaryControls':{},'acceptance':{},'frozenSnapshots':{}}
accepted=[]
for be in ['webgpu','webgl']:
 report=json.loads((out/f'pairs-{be}/report.json').read_text());raw=json.load(gzip.open(out/f'pairs-{be}/raw.json.gz','rt'));assert len(report['results'])==6 and len(raw)==6
 assert not report.get('error') and not report['driverInputsChangedDuringRun'] and all(x['complete'] and not x['forced'] for x in report['cleanup'])
 assert report['measurementProtocol']['profiling'] is False and report['calibration']['loads']==[2048]
 assert all(x['pixel']['exact'] and x['pixel']['maxChannelDelta']==0 for c in report['comparisons'] for x in c['paired'])
 assert json.loads((out/f'calibrate-{be}/config.json').read_text())['levels']['over']==2048
 rows=[]
 for r in report['results']:
  d=next(x for x in raw if x['id']==r['id']);assert d['profiling'] is False and r['profiling'] is False and not d['gpu'] and not d['glRafGpu']['enabled'] and d['glRafGpu']['queriesCreated']==0
  assert d['boundaryStart']['profile']['enabled'] is False and d['boundaryEnd']['profile']['enabled'] is False
  for name,arr in [('rafInterval',[b['stamp']-a['stamp'] for a,b in zip(d['frames'],d['frames'][1:])]),('rafCallbackCpu',[v['cpu'] for v in d['frames']])]:
   for k,v in stats(arr).items():assert abs(v-r[name][k])<1e-8,(r['id'],name,k)
  assert r['work']['gltf']['prepareTimedCalls']['delta'] in [0,None]
  assert r['work']['gltf']['drawCalls']['perApplicationRaf']==307
  assert r['work']['gltf']['instancesDrawn']['perApplicationRaf']==126823
  assert r['work']['gltf']['trianglesDrawn']['perApplicationRaf']==39067116
  assert r['work']['gltf']['bufferUploadCalls']['delta']==0 and r['work']['gltf']['instanceUploadBytes']['delta']==0
  if r['label']=='candidate':
   for k in ['prepareEligibleRebuilds','prepareGroupRebuilds','prepareOpaqueGroupRebuilds','preparePayloadRebuilds','prepareRecordRebuilds','preparedPlanCache.misses']:
    assert r['work']['gltf'][k]['delta']==0,(be,k)
   assert r['work']['gltf']['preparedPlanCache.hits']['perApplicationRaf']==1
   c=r['debug']['gltf']['preparedPlanCache'];assert c['retainedBytes']==102520 and c['retainedBytes']<=c['byteLimit'] and c['retainedSlots']<=c['slotLimit']
  row={k:r[k] for k in ['id','label','pair','frames','rafInterval','rafCallbackCpu','work','heapBytes','profiling','capture']};row['fpsFromMeanInterval']=1000/r['rafInterval']['mean'];rows.append(row);accepted.append(r['id'])
 groups={}
 for label in ['baseline','candidate']:
  a=[x for x in rows if x['label']==label]
  groups[label]={'medianRunMeanCpuMs':statistics.median(x['rafCallbackCpu']['mean'] for x in a),'medianRunMeanRafMs':statistics.median(x['rafInterval']['mean'] for x in a),'medianRunFps':statistics.median(x['fpsFromMeanInterval'] for x in a),'fpsRange':[min(x['fpsFromMeanInterval'] for x in a),max(x['fpsFromMeanInterval'] for x in a)],'meanCpuRange':[min(x['rafCallbackCpu']['mean'] for x in a),max(x['rafCallbackCpu']['mean'] for x in a)]}
 pairs=[]
 for i in range(3):
  a=next(x for x in rows if x['label']=='baseline' and x['pair']==i);b=next(x for x in rows if x['label']=='candidate' and x['pair']==i)
  pairs.append({'pair':i,'cpuMeanRatio':b['rafCallbackCpu']['mean']/a['rafCallbackCpu']['mean'],'rafMeanRatio':b['rafInterval']['mean']/a['rafInterval']['mean'],'fpsRatio':b['fpsFromMeanInterval']/a['fpsFromMeanInterval']})
 summary['backends'][be]={'rows':rows,'groups':groups,'pairedMeanRatios':pairs,'medianPairedCpuReduction':1-statistics.median(x['cpuMeanRatio'] for x in pairs),'medianPairedFpsGain':statistics.median(x['fpsRatio'] for x in pairs)-1,'driverFrameMedianRatios':report['comparisons'],'report':str((out/f'pairs-{be}/report.json').relative_to(root)),'browser':report['browser'],'hardware':report['hardware'],'driverIdentity':report['driverIdentity']}
 for kind in ['stages','candidate-stages']:
  r=json.loads((out/f'{kind}-{be}/report.json').read_text());q=r['results'][0]
  summary['diagnostics'][kind+'-'+be]={'kind':'single unpaired profiler-enabled diagnostic pilot, 4s warmup/10s sample; not clean throughput','load':1024,'rafInterval':q['rafInterval'],'rafCallbackCpu':q['rafCallbackCpu'],'fps':1000/q['rafInterval']['mean'],'stagesMsPerRaf':{k:v['perApplicationRaf'] for k,v in q['work']['gltf'].items() if k.startswith('prepareStageMs.')},'cpuScopeEvidence':q['cpuScopeEvidence'],'work':q['work'],'gpuPassMs':q['gpuPassMs'],'gpuSamples':q['gpuSamples'],'glRafGpuMs':q['glRafGpuMs'],'glRafGpu':q['glRafGpu']}
 q=json.loads((out/f'candidate-ordinary-{be}/report.json').read_text())['results'][0]
 summary['ordinaryControls'][be]={'kind':'candidate-only 8s/25s stationary ordinary Rome control; no paired improvement inference','fps':1000/q['rafInterval']['mean'],'rafInterval':q['rafInterval'],'rafCallbackCpu':q['rafCallbackCpu'],'work':q['work']}
summary['acceptance']={'primaryRunsAccepted':len(accepted),'acceptedIDs':accepted,'frameRecords':sum(x['frames'] for b in summary['backends'].values() for x in b['rows']),'rawFullDistributionRecalculation':True,'profilingOffIncludingNativeBoundaryAndGlTimerAssertions':True,'allSixPairsExactPixels':True,'identicalActualGltfWorkPerRaf':{'drawCommands':307,'instances':126823,'triangles':39067116,'uploadCalls':0,'instanceUploadBytes':0},'candidateWarmRebuilds':0,'candidateHitsPerRaf':1,'candidateRetainedAccountedBytes':102520,'byteLimit':16777216,'slotLimit':64,'GPUtimesInPrimary':None,'GPUtimesReason':'profiling intentionally disabled; separate diagnostics carry scoped samples'}
# Immutable snapshots: verify every captured file, not merely their dirty names.
for name in ['baseline','instrumented-baseline','candidate']:
 p=out/name;m=json.loads((p/'render-build.json').read_text());assert m['complete']
 for f,v in m['files'].items():assert sha(p/f)==v['sha256'],(name,f)
 summary['frozenSnapshots'][name]={'filesVerified':len(m['files']),'manifestSha256':sha(p/'render-build.json'),'build':m['build']}
for be in ['webgpu','webgl']:
 for label in ['baseline','candidate']:
  entries=json.loads((out/f'pairs-{be}'/f'manifest-{label}.json').read_text())
  for e in entries:
   base=root if e['source']=='harness' else out/label
   assert sha(base/e['url'].lstrip('/'))==e['sha256'],(be,label,e['url'])
summary['acceptance']['servedPayloadAndCommonHarnessHashesRechecked']=True
summary['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(doc/'RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'acceptance.json').write_text(json.dumps(summary['acceptance'],indent=2)+'\n')
print(json.dumps(summary['acceptance'],indent=2))
