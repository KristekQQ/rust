from pathlib import Path
p=Path('src/render/gltf_gpu.rs');s=p.read_text();s=s.replace('draws: Vec<PreparedDraw>,\n    pub upload_bytes','draws: Rc<Vec<PreparedDraw>>,\n    pub upload_bytes',1)
pos=s.index('/// Frame-local indices only:')
s=s[:pos]+'''// One entry per logical pass/view, never one entry per camera matrix. The
// content epoch covers every mutable glTF buffer write, including writes made
// through a different pipeline/light variant sharing the same storage.
const PLAN_SLOTS: usize = 64;
const PLAN_BYTES: usize = 16 * 1024 * 1024;
#[derive(Clone, PartialEq, Eq)]
struct PlanKey {
    pipeline: PipelineKey,
    camera: [u32; 3],
    view_projection: [u32; 16],
    scene: u64,
    inputs: u64,
    content: u64,
    culling: bool,
    diagnostics: bool,
}
struct CachedPlan {
    key: PlanKey,
    models: Vec<(u32, u64, bool)>,
    draws: Rc<Vec<PreparedDraw>>,
    bytes: usize,
}
struct PlanCache {
    enabled: bool,
    slots: [Option<CachedPlan>; PLAN_SLOTS],
    hits: u64,
    misses: u64,
    // cold, scene, inputs, membership, view, pipeline, content, diagnostics,
    // lifecycle, toggle, budget eviction/rejection, unsupported slot.
    reasons: [u64; 12],
    bytes: usize,
}
impl Default for PlanCache {
    fn default() -> Self {
        Self { enabled: true, slots: std::array::from_fn(|_| None), hits: 0,
            misses: 0, reasons: [0; 12], bytes: 0 }
    }
}
impl PlanCache {
    fn clear(&mut self, reason: usize) {
        self.slots.fill_with(|| None);
        self.bytes = 0;
        self.reasons[reason] += 1;
    }
    fn lookup(&mut self, slot: usize, key: &PlanKey, models: &[(u32, &GpuModel)]) -> Option<Rc<Vec<PreparedDraw>>> {
        let reason = match self.slots.get(slot) {
            None => 11,
            Some(None) => 0,
            Some(Some(p)) => {
                if p.key.scene != key.scene { 1 }
                else if p.key.inputs != key.inputs { 2 }
                else if p.models.len() != models.len() || !p.models.iter().zip(models).all(|(a, (id, m))| *a == (*id, m.generation, m.opaque_reorderable)) { 3 }
                else if p.key.camera != key.camera || p.key.view_projection != key.view_projection || p.key.culling != key.culling { 4 }
                else if p.key.pipeline != key.pipeline { 5 }
                else if p.key.content != key.content { 6 }
                else if p.key.diagnostics != key.diagnostics { 7 }
                else { self.hits += 1; return Some(p.draws.clone()); }
            }
        };
        self.misses += 1;
        self.reasons[reason] += 1;
        // Drop invalid entries immediately; no stale resource ownership across
        // misses or lifecycle transitions, even when the next plan is too big.
        if let Some(entry) = self.slots.get_mut(slot) {
            if let Some(old) = entry.take() { self.bytes -= old.bytes; }
        }
        None
    }
    fn store(&mut self, slot: usize, key: PlanKey, models: &[(u32, &GpuModel)], draws: Rc<Vec<PreparedDraw>>) {
        if slot >= PLAN_SLOTS { return; }
        let models: Vec<_> = models.iter().map(|(id, m)| (*id, m.generation, m.opaque_reorderable)).collect();
        let bytes = draws.capacity() * std::mem::size_of::<PreparedDraw>()
            + draws.iter().map(|d| d.records.capacity() * std::mem::size_of::<(u32, usize, usize)>()).sum::<usize>()
            + models.capacity() * std::mem::size_of::<(u32, u64, bool)>()
            + std::mem::size_of::<CachedPlan>();
        if bytes > PLAN_BYTES { self.reasons[10] += 1; return; }
        for entry in &mut self.slots {
            if self.bytes + bytes <= PLAN_BYTES { break; }
            if let Some(old) = entry.take() { self.bytes -= old.bytes; self.reasons[10] += 1; }
        }
        self.bytes += bytes;
        self.slots[slot] = Some(CachedPlan {key, models, draws, bytes});
    }
}

'''+s[pos:]
s=s.replace('pub struct GpuModel {\n','pub struct GpuModel {\n    generation: u64,\n',1)
s=s.replace('    queue_scratch: QueueScratch,\n','    queue_scratch: QueueScratch,\n    plan_cache: RefCell<PlanCache>,\n    input_epoch: Cell<u64>,\n    content_epoch: Cell<u64>,\n',1)
s=s.replace('            queue_scratch: QueueScratch::default(),','            queue_scratch: QueueScratch::default(),\n            plan_cache: RefCell::new(PlanCache::default()),\n            input_epoch: Cell::new(0),\n            content_epoch: Cell::new(0),',1)
s=s.replace('    fn create_model(&self, device:', '''    fn invalidate_plan_inputs(&self) {
        self.input_epoch.set(self.input_epoch.get().checked_add(1).expect("glTF input epoch exhausted"));
        self.plan_cache.borrow_mut().clear(2);
    }
    fn wrote_content(&self) {
        self.content_epoch.set(self.content_epoch.get().checked_add(1).expect("glTF content epoch exhausted"));
    }
    pub fn set_plan_cache_enabled(&self, enabled: bool) {
        let mut cache = self.plan_cache.borrow_mut();
        if cache.enabled != enabled { cache.clear(9); cache.enabled = enabled; }
    }
    pub fn plan_cache_stats(&self) -> serde_json::Value {
        let c = self.plan_cache.borrow();
        serde_json::json!({"enabled":c.enabled,"hits":c.hits,"misses":c.misses,
            "reasons":c.reasons,"reasonNames":["cold","scene","inputs","membership","view","pipeline","content","diagnostics","lifecycle","toggle","budget","unsupportedSlot"],
            "retainedBytes":c.bytes,"byteLimit":PLAN_BYTES,"slotLimit":PLAN_SLOTS,
            "retainedSlots":c.slots.iter().filter(|s|s.is_some()).count(),
            "inputEpoch":self.input_epoch.get(),"contentEpoch":self.content_epoch.get(),
            "memoryScope":"CPU plan element storage; existing referenced GPU allocations reported separately"})
    }
    fn create_model(&self, device:''',1)
s=s.replace('        let asset = &shared.asset;\n        let materials = shared.materials.clone();','        self.invalidate_plan_inputs();\n        let asset = &shared.asset;\n        let materials = shared.materials.clone();',1)
s=s.replace('        GpuModel {\n            active_draws,','        GpuModel {\n            generation: self.input_epoch.get(),\n            active_draws,',1)
s=s.replace('        model.active.clear();','        self.invalidate_plan_inputs();\n        model.active.clear();',1)
s=s.replace('        self.diagnostics.set(enabled);','        if self.diagnostics.get() != enabled { self.plan_cache.borrow_mut().clear(7); }\n        self.diagnostics.set(enabled);',1)
s=s.replace('    pub fn clear_instance_pages(&mut self) {','    pub fn clear_instance_pages(&mut self) {\n        self.plan_cache.borrow_mut().clear(8);\n        self.wrote_content();',1)
s=s.replace('        culling: bool,\n    ) -> PreparedDraws','        culling: bool,\n        scene_revision: u64,\n    ) -> PreparedDraws',1)
s=s.replace('        let frustum = crate::visibility::Frustum::from_view_projection(view_projection);','''        let mut plan_key = PlanKey {
            pipeline: key, camera: camera.to_array().map(f32::to_bits),
            view_projection: view_projection.to_cols_array().map(f32::to_bits),
            scene: scene_revision, inputs: self.input_epoch.get(), content: self.content_epoch.get(),
            culling, diagnostics: self.diagnostics.get(),
        };
        let cache_enabled = !blend && !models.is_empty() && self.plan_cache.borrow().enabled;
        if cache_enabled {
            let hit = self.plan_cache.borrow_mut().lookup(view_slot, &plan_key, &models);
            if let Some(draws) = hit {
                // Do not attribute lookup/model-list validation to rebuild stages.
                // These are cumulative work counters, not the parent queue scope.
                stages.finish();
                return PreparedDraws { draws, upload_bytes: 0 };
            }
        }
        let frustum = crate::visibility::Frustum::from_view_projection(view_projection);''',1)
# Stage0currentlystarts beforelookup; fixhitstagezero bystart eligibleafterlookup instead.
s=s.replace('        stages.switch(Some(0));\n        let upload_before','        let upload_before',1)
s=s.replace('        let frustum = crate::visibility::Frustum::from_view_projection(view_projection);','        stages.switch(Some(0));\n        let frustum = crate::visibility::Frustum::from_view_projection(view_projection);',1)
s=s.replace('        let mut prepared = PreparedDraws {\n            draws: Vec::with_capacity(scratch.groups.len()),\n            upload_bytes: 0,\n        };','        let mut prepared_draws = Vec::with_capacity(scratch.groups.len());',1)
s=s.replace('            prepared.draws.push(PreparedDraw {','            prepared_draws.push(PreparedDraw {',1)
s=s.replace('        prepared.upload_bytes = (self.counters.get().uniform_upload_bytes - upload_before) as usize;','''        let prepared = PreparedDraws {
            draws: Rc::new(prepared_draws),
            upload_bytes: (self.counters.get().uniform_upload_bytes - upload_before) as usize,
        };
        if cache_enabled {
            plan_key.content = self.content_epoch.get();
            self.plan_cache.borrow_mut().store(view_slot, plan_key, &models, prepared.draws.clone());
        }''',1)
s=s.replace('        for d in &prepared.draws {','        for d in prepared.draws.iter() {',1)
# All mutable writes advance content epoch, including existing palette/deformation writes.
lines=s.splitlines();out=[]
for l in lines:
 out.append(l)
 if 'queue.write_buffer(' in l and l.rstrip().endswith(';'):
  out.append(l[:len(l)-len(l.lstrip())]+'self.wrote_content();')
s='\n'.join(out)+'\n';p.write_text(s)
p=Path('src/render/renderer.rs');s=p.read_text();s=s.replace('                "prepareEligibleRebuilds":','                "preparedPlanCache": self.gltf_gpu.plan_cache_stats(),\n                "prepareEligibleRebuilds":',1)
# All4prepare calls unique culling trailing; replace limited exact indentation.
s=s.replace('            self.frustum_culling,\n        );','            self.frustum_culling,\n            self.scene.render_revision(),\n        );')
s=s.replace('                self.frustum_culling,\n            );','                self.frustum_culling,\n                self.scene.render_revision(),\n            );')
pos=s.index('    pub fn debug_values(&self)')
s=s[:pos]+'''    pub fn set_prepared_plan_cache_enabled(&self, enabled: bool) {
        self.gltf_gpu.set_plan_cache_enabled(enabled);
    }
'''+s[pos:];p.write_text(s)
p=Path('src/web.rs');s=p.read_text();pos=s.index('#[wasm_bindgen]\npub fn renderer_stats()');s=s[:pos]+'''/// Independent uncached preparation path for correctness/performance controls.
#[wasm_bindgen]
pub fn set_prepared_plan_cache_enabled(enabled: bool) {
    STATE.with(|state| {
        if let Some(state) = state.borrow().as_ref() {
            state.borrow().set_prepared_plan_cache_enabled(enabled);
        }
    });
}

'''+s[pos:];p.write_text(s)
p=Path('js/engine.js');s=p.read_text().replace('        debugStats() {','        /** Exact opaque prepared-plan reuse; disable for independent comparison. @param {boolean} enabled */\n        setPreparedPlanCacheEnabled(enabled) { wasm.set_prepared_plan_cache_enabled(enabled); },\n        debugStats() {',1);p.write_text(s)
p=Path('js/engine.d.ts');s=p.read_text().replace('setDebugOverlay(enabled: boolean): void; debugStats()', 'setDebugOverlay(enabled: boolean): void; setPreparedPlanCacheEnabled(enabled: boolean): void; debugStats()');p.write_text(s)
