import os,json,hashlib,tarfile,io,subprocess
from pathlib import Path
repo=Path.cwd();root=repo/'output/next-render-cycle-4';dest=repo/'docs/performance/next-render-cycle/batch-4/evidence.tar.gz';selected={}
def add(name,p):
 assert p.is_file() and not p.is_symlink(),str(p)
 selected[name]=p
for p in root.rglob('*'):
 if p.is_file() and not p.is_symlink() and p.relative_to(root).parts[0] not in ['baseline','candidate'] and p.name not in ['ARCHIVE-AUDIT.json']:
  add('evidence/'+str(p.relative_to(root)),p)
b=json.loads((root/'baseline/render-build.json').read_text());c=json.loads((root/'candidate/render-build.json').read_text())
changed={p for p in set(b['files'])|set(c['files']) if b['files'].get(p)!=c['files'].get(p)}
assert not any(p.startswith('assets/') for p in changed),'Changed assets must be included explicitly'
for label,m in [('baseline',b),('candidate',c)]:
 add('frozen/'+label+'/render-build.json',root/label/'render-build.json')
 for name in m['files']:
  if name.startswith('pkg/') or name in changed:
   add('frozen/'+label+'/'+name,root/label/name)
for p in (repo/'output/verification').rglob('*'):
 if p.is_file() and not p.is_symlink():add('verification/'+str(p.relative_to(repo/'output/verification')),p)
owned=['src/render/gltf_gpu.rs','src/render/renderer.rs','src/web.rs','js/engine.js','js/engine.d.ts','scripts/render-performance-api.mjs','scripts/render-performance-lib.mjs','scripts/render-performance.mjs','scripts/render-performance.test.mjs','scripts/test-browser.mjs','tests/render-performance.js','tests/xr/gltf-instance-checks.js','tests/webxr-webgpu.html','tests/gltf-instance-pool.html','tests/gltf-instance-pool.js']
for name in owned:add('final-source/'+name,repo/name)
readme=b'''Batch4 local evidence. Baseline parent 8e03df21ddc26f1a36c41bc7a12293d3405b4b22.
Reconstruct an isolated checkout from that local Git commit, preserving its tracked unchanged assets/dependencies. frozen/{baseline,candidate}/ contain full file-hash manifests, generated packages, and changed inputs (both sides where present). Overlay these changed files on the baseline parent. Unchanged assets and old historical documentation/archives are not duplicated. Verify every reconstructed file against render-build.json. Current final-source/ includes final SDK comment annotations, bounded diagnostics collector and lifecycle test revisions; primary-driver/ is the original exact measured common driver. Canonical SDK runtime hash equality is independently recorded. Full frozen roots remain in the ignored local output directories.
All primary, preliminary/adverse/failed diagnostic, fixed-pose, command, raw, capture and gate evidence is preserved here. Timestamps/process identifiers are descriptive only. SHA256SUMS.json covers each archived payload including exact-content hardlinks. Actual GPU physical release completion, per-process VRAM, pure CPU-cycle time, physical Quest/CI and fresh Three equivalence are unavailable. The strict stress image FAIL is not converted to PASS by the project gate.
'''
manifest={};seen={};links=0;total=0
with tarfile.open(dest,'w:gz',compresslevel=6) as tf:
 for name,p in sorted(selected.items()):
  data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();manifest[name]={'sha256':sha,'bytes':len(data)};total+=len(data)
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0
  key=(sha,len(data))
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];tf.addfile(info);links+=1
  else:
   info.size=len(data);tf.addfile(info,io.BytesIO(data));seen[key]=name
 for name,data in [('README.txt',readme),('SHA256SUMS.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as tf:
 actual=json.load(tf.extractfile('SHA256SUMS.json'));assert actual==manifest
 for name,m in actual.items():
  data=tf.extractfile(name).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256'],name
summary={'path':str(dest.relative_to(repo)),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payloads':len(manifest),'storedEntries':len(manifest)+2,'uniquePayloads':len(seen),'exactContentHardlinks':links,'recordedUncompressedBytes':total,'everyPayloadAndHardlinkReadBack':True,'frozenRuntimeChangedInputsIncluded':sorted(changed),'unchangedBaseAssetsExcluded':True}
(root/'ARCHIVE-AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
