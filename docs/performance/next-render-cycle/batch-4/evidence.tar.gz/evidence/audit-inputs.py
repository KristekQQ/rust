import json,hashlib
from pathlib import Path
root=Path('output/next-render-cycle-4');checks={'frozenFiles':0,'servedPayloadRecords':0,'primaryReports':0,'diagnosticReports':0,'driverFileChecks':0}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
for label in ['baseline','candidate']:
 m=json.loads((root/label/'render-build.json').read_text());assert m['complete']
 for name,v in m['files'].items():
  p=root/label/name;assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],str(p);checks['frozenFiles']+=1
for config in json.loads((root/'PRIMARY-CONFIGS.json').read_text())['cases']:
 p=root/f"primary-{config['family']}-{config['load']}-{config['backend']}";r=json.loads((p/'report.json').read_text());assert not r.get('error') and not r['driverInputsChangedDuringRun'] and all(x['complete'] for x in r['cleanup']);assert r['settings']['profiling'] is False
 for name,h in r['driverIdentity']['files'].items():assert sha(root/'primary-driver'/name)==h;checks['driverFileChecks']+=1
 for label in ['baseline','candidate']:
  for e in json.loads((p/f'manifest-{label}.json').read_text()):
   ref=(root/'primary-driver' if e['source']=='harness' else root/label)/e['url'].lstrip('/');assert ref.stat().st_size==e['bytes'] and sha(ref)==e['sha256'],str(ref);checks['servedPayloadRecords']+=1
 checks['primaryReports']+=1
for p in root.glob('diag-final-*/report.json'):
 r=json.loads(p.read_text());assert not r.get('error') and not r['driverInputsChangedDuringRun'] and all(x['complete'] for x in r['cleanup'])
 for name,h in r['driverIdentity']['files'].items():assert sha(Path(name))==h;checks['driverFileChecks']+=1
 for e in json.loads((p.parent/'manifest-baseline.json').read_text()):
  ref=(Path('.') if e['source']=='harness' else Path(r['baselineRoot']))/e['url'].lstrip('/');assert ref.stat().st_size==e['bytes'] and sha(ref)==e['sha256'];checks['servedPayloadRecords']+=1
 checks['diagnosticReports']+=1
assert checks['primaryReports']==10 and checks['diagnosticReports']==12
checks.update({'allPassed':True,'finalBuild':json.loads((root/'final-fingerprint.json').read_text()),'finalSdkSha256':sha(Path('js/engine.js')),'canonicalSdkRuntimeProof':json.loads((root/'sdk-comment-only-proof.json').read_text()),'sourceDumpSha256':sha(Path('all_sources.txt'))})
(root/'INPUT-AUDIT.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
