import json,statistics
from pathlib import Path
root=Path('output/next-render-cycle-4');r=json.loads((root/'DERIVED.json').read_text());quality=[]
metrics=['drawCalls','instancesDrawn','trianglesDrawn','uniformUploadBytes','bufferUploadCalls','instanceUploadBytes','prepareGroupRebuilds','preparePayloadRebuilds','finePayloadRecordsWritten','finePayloadBytesWritten']
for c in r['results']:
 report=json.loads((root/f"primary-{c['family']}-{c['load']}-{c['backend']}/report.json").read_text());reference=report['results'][0]['metadata']['quality']
 for row in report['results']:
  assert row['actualQualityState']['canvas']=={'width':1280,'height':720}
  assert row['metadata']['quality']==reference
  quality.append({'id':row['id'],'backend':c['backend'],'qualityMatched':True,'profileOff':report['settings']['profiling'] is False})
 for label in ['baseline','candidate']:
  rows=[row for row in report['results'] if row['label']==label]
  c['byLabel'][label]['workMediansPerApplicationRaf']={m:statistics.median([row['work']['gltf'][m]['perApplicationRaf'] for row in rows]) for m in metrics}
  c['byLabel'][label]['poolGaugeExample']=rows[0]['work']['gauges']['end'].get('instancePool')
r['scope']+='; full per-run counters/manifests/raw remain in evidence archive'
r['qualityAudit']={'all44Matched':len(quality)==44 and all(x['qualityMatched'] and x['profileOff'] for x in quality),'runs':len(quality)}
r['diagnostics']=json.loads((root/'DIAGNOSTICS-DERIVED.json').read_text())
r['pixels']=json.loads((root/'pixel-classification.json').read_text())
Path('docs/performance/next-render-cycle/batch-4/RESULTS.json').write_text(json.dumps(r,indent=2)+'\n')
