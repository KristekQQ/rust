import json,pathlib
base=pathlib.Path('output/next-render-cycle');s=json.loads((base/'summary.json').read_text());out={'schema':1,'scope':'contended desktop baseline; primary profiler off; separate instrumented diagnostics; no speedup or Quest claim','primary':{},'diagnostics':{},'cuts':s['cuts'],'unavailable':{'physicalQuest':None,'isolatedGpuCapacity':None,'perProcessGpuUtilization':None,'workerInternalComputeMs':None,'groupPreparationCpuMs':None,'instancePackingCpuMs':None,'wholeApiUploadBytes':None,'wholeApiUploadBytesReason':'wrappers count calls; native glTF cumulative bytes cover only glTF; renderer uploadBytes is a last-frame scene gauge, not whole-API cumulative bytes'}}
for k,v in s['groups'].items():
 out['primary'][k]={n:v[n] for n in ['runCount','fpsPerRun','medianRunFps','rafPooled','cpuPooled','rendererDrawGauge','mainDrawGauge','sceneUploadBytesGauge','scenePrepareMsGauge','gltfWork']}
 out['primary'][k]['workCoverage']='all passes/views summed by native glTF counters, divided by application RAF; instances are submitted primitive-instance events, not unique model handles; last-frame draw gauge is different from cumulative average'
for k,v in s['profiles'].items():
 api=v['api'];retry=s['apiRetries'].get(k.replace('profile-','api64-'));a=retry['api'] if retry else api; backend='webgl' if k.endswith('webgl') else 'webgpu';w=a['warm'];start=w['start']['counters'][backend];end=w['end']['counters'][backend];frames=w['engineFrames']
 events={n:{'delta':end.get(n,0)-start.get(n,0),'perEngineFrame':(end.get(n,0)-start.get(n,0))/frames if frames>0 else None} for n in set(start)|set(end) if isinstance(end.get(n,0),(int,float))}
 submitted={n:{'delta':end['submitted'].get(n,0)-start['submitted'].get(n,0),'perEngineFrame':(end['submitted'].get(n,0)-start['submitted'].get(n,0))/frames if frames>0 else None} for n in ['drawCalls','instances','primitives','triangles','lines','points']}
 complete=start['submitted']['complete'] and end['submitted']['complete'];proof={'complete':complete,'incompleteReasons':end['submitted']['incompleteReasons'],'submitted':submitted}
 if not complete:
  proof['unprovenPrimitiveLowerBounds']=submitted
  proof['submitted']={n:(submitted[n] if n in ['drawCalls','instances'] else None) for n in submitted}
 out['diagnostics'][k]={'cpuEvidence':v['cpuEvidence'],'gpuNamedPasses':v['gpuNamedPasses'],'gpuNamedSamples':v['gpuNamedSamples'],'gpuNamedSupported':v['gpuNamedSupported'],'glRafGpu':v['glRafGpu'],'glRafGpuMs':v['glRafGpuMs'],'apiSource':k.replace('profile-','api64-') if retry else k,'coldApiCounters':a['counters'][backend],'warmApi':{'elapsedMs':w['elapsedMs'],'engineFrames':frames,'events':events,'primitiveProof':proof,'indexShadowEnd':end.get('indexShadow'),'errors':w['end']['counters']['errors']}}
path=pathlib.Path('docs/performance/next-render-cycle/RESULTS.json');path.write_text(json.dumps(out,indent=2)+'\n')
