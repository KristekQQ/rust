// Serial orchestration only; all rendering/metrics use maintained project tools.
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const base='output/next-render-cycle',mode=process.argv[2],runtime=path.join(base,'baseline');
const journal=path.join(base,'commands.json');
const records=fs.existsSync(journal)?JSON.parse(fs.readFileSync(journal)):[];
function run(name,args){
 const log=path.join(base,'audit',name+'.log');
 const entry={name,startedAt:new Date().toISOString(),command:[process.execPath,...args],env:{VERIFY_WASM_PROFILE:'release',BROWSER_EXECUTABLE:process.env.BROWSER_EXECUTABLE||null},log};records.push(entry);fs.writeFileSync(journal,JSON.stringify(records,null,2)+'\n');
 const fd=fs.openSync(log,'w');console.log('START '+name);
 const result=spawnSync(process.execPath,args,{stdio:['ignore',fd,fd],env:{...process.env,VERIFY_WASM_PROFILE:'release'},timeout:900000});fs.closeSync(fd);
 entry.completedAt=new Date().toISOString();entry.exitCode=result.status;entry.signal=result.signal;entry.error=result.error?.message||null;fs.writeFileSync(journal,JSON.stringify(records,null,2)+'\n');
 if(result.status!==0)throw Error(name+' failed; see '+log);
 console.log('PASS '+name);return args.includes('--out')?JSON.parse(fs.readFileSync(path.join(args[args.indexOf('--out')+1],'report.json'))):null;
}
function render(name,{family,backend,load=1,warmup=1000,sample=2500,profile=false,diagnostics=false,command='smoke'}){
 const args=['scripts/render-performance.mjs',command,'--baseline-root',runtime,'--family',family,'--backend',backend,'--load',String(load),'--max-load','1024','--width','1280','--height','720','--warmup',String(warmup),'--sample',String(sample),'--startup-timeout','60000','--max-time','240','--out',path.join(base,name)];
 if(!profile)args.push('--no-profile');if(diagnostics)args.push('--diagnostics');return run(name,args);
}
if(mode==='pilots'){
 for(const [family,backend,load] of [['rim-camera','webgl',1],['rim-clustered','webgpu',16],['rim-clustered','webgl',16],['rim-static','webgpu',1],['rim-static','webgl',1],['arena-active','webgpu',1],['arena-active','webgl',1]])render('pilot-'+family+'-'+backend,{family,backend,load});
}else if(mode==='calibrate'){
 const selected={};
 for(const backend of ['webgl','webgpu']){
  for(const load of [128,512,1024]){
   const name='cal-'+backend+'-'+load,report=render(name,{family:'rim-stress',backend,load,command:'calibrate'});
   const config=JSON.parse(fs.readFileSync(path.join(base,name,'config.json'))),r=report.results[0];
   selected[backend]={load,config:path.join(base,name,'config.json'),capacityPass:config.capacityProbes[0].capacityPass,rafMedianMs:r.rafInterval.median,rafP95Ms:r.rafInterval.p95,cpuP95Ms:r.rafCallbackCpu.p95};
   if(!selected[backend].capacityPass)break;
  }
 }
 fs.writeFileSync(path.join(base,'selected-loads.json'),JSON.stringify(selected,null,2)+'\n');
}else if(mode==='primary'){
 const selected=JSON.parse(fs.readFileSync(path.join(base,'selected-loads.json')));
 const cases=[['A-static','rim-static',1],['B-camera','rim-camera',1],['C-gameplay','rim-active',1],['C-clustered','rim-clustered',16],['D-lifecycle','dynamic',128],['E-arena','arena-active',1],['stress-static','rim-stress',null],['stress-moving','rim-clustered',null]];
 fs.writeFileSync(path.join(base,'primary-plan.json'),JSON.stringify({protocol:{warmup:8000,sample:25000,profile:false,width:1280,height:720,repetitions:3},selected,cases},null,2)+'\n');
 for(let repetition=0;repetition<3;repetition++)for(const [caseId,family,fixedLoad] of cases)for(const backend of repetition%2?['webgpu','webgl']:['webgl','webgpu'])render('primary-'+caseId+'-'+backend+'-r'+repetition,{family,backend,load:fixedLoad??selected[backend].load,warmup:8000,sample:25000});
}else if(mode==='profiles'){
 const selected=JSON.parse(fs.readFileSync(path.join(base,'selected-loads.json')));
 for(const family of ['rim-static','rim-stress','rim-clustered','arena-active','dynamic'])for(const backend of ['webgpu','webgl'])render('profile-'+family+'-'+backend,{family,backend,load:['rim-stress','rim-clustered'].includes(family)?selected[backend].load:family==='dynamic'?128:1,warmup:4000,sample:['rim-stress','rim-clustered'].includes(family)?25000:10000,profile:true,diagnostics:true});
}else if(mode==='api64'){
 const selected=JSON.parse(fs.readFileSync(path.join(base,'selected-loads.json')));
 for(const family of ['rim-static','rim-stress','rim-clustered','dynamic'])render('api64-'+family+'-webgl',{family,backend:'webgl',load:['rim-stress','rim-clustered'].includes(family)?selected.webgl.load:family==='dynamic'?128:1,warmup:2000,sample:5000,profile:true,diagnostics:true});
}else if(mode==='cuts'){
 for(const backend of ['webgpu','webgl'])for(const stressCount of [0,1024])run('cuts-'+backend+'-'+stressCount,['scripts/benchmark-rim-cuts.mjs','next-cycle-1-'+(stressCount?'stress-':'')+backend,path.join(runtime,'pkg'),backend,String(stressCount)]);
}else if(mode==='cuts-v2'){
 for(const [backend,stressCount] of [['webgpu',1024],['webgl',0],['webgl',1024]])run('cuts-v2-'+backend+'-'+stressCount,['scripts/benchmark-rim-cuts.mjs','next-cycle-1-'+(stressCount?'stress-v2-':'')+backend,path.join(runtime,'pkg'),backend,String(stressCount)]);
}else throw Error('Unknown phase');
