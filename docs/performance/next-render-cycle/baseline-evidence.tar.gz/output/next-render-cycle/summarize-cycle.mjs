import fs from 'node:fs';
import path from 'node:path';
import {gunzipSync} from 'node:zlib';
import {stats,cpuScopeEvidence} from '../../scripts/render-performance-lib.mjs';
const base='output/next-render-cycle';
const groups={};
for(const entry of fs.readdirSync(base).filter(n=>n.startsWith('primary-'))){
 const dir=path.join(base,entry),file=path.join(dir,'report.json');if(!fs.existsSync(file))continue;
 const report=JSON.parse(fs.readFileSync(file));if(report.error||report.driverInputsChangedDuringRun?.length||!report.results?.length)throw Error('Invalid primary '+entry);
 const row=report.results[0],raw=JSON.parse(gunzipSync(fs.readFileSync(path.join(dir,'raw.json.gz'))))[0];
 if(row.profiling!==false||raw.glRafGpu?.queriesBegun||report.cleanup?.some(c=>!c.complete))throw Error('Primary controls failed '+entry);
 const key=entry.replace(/-r\d+$/,'').replace(/^primary-/,'');
 (groups[key]??=[]).push({entry,report,row,raw});
}
const summary={version:1,primaryCount:0,groups:{},profiles:{},cuts:{},limits:{physicalQuest:false,gpuIsolation:false,groupPreparationAndPackingSeparateCpu:false,wholeApiUploadsBytes:null,workerInternalComputeMs:null}};
const median=v=>stats(v)?.median??null;
for(const [key,runs] of Object.entries(groups)){
 const intervals=runs.flatMap(({raw})=>raw.frames.slice(1).map((f,i)=>f.stamp-raw.frames[i].stamp));
 const cpu=runs.flatMap(({raw})=>raw.frames.map(f=>f.cpu));
 const samples=runs.flatMap(({raw})=>raw.samples),workKeys=Object.keys(runs[0].row.work?.gltf||{});
 summary.primaryCount+=runs.length;
 summary.groups[key]={runCount:runs.length,runs:runs.map(({entry,row})=>({entry,frames:row.frames,elapsedMs:row.elapsedMs,fps:1000/row.rafInterval.mean,cpuMs:row.rafCallbackCpu,rafMs:row.rafInterval,phase:row.phaseEvidence,commands:row.commands})),fpsPerRun:runs.map(({row})=>1000/row.rafInterval.mean),medianRunFps:median(runs.map(({row})=>1000/row.rafInterval.mean)),rafPooled:stats(intervals),cpuPooled:stats(cpu),rendererDrawGauge:stats(samples.map(s=>s.debug.drawCalls)),mainDrawGauge:stats(samples.map(s=>s.debug.mainDrawCalls)),sceneUploadBytesGauge:stats(samples.map(s=>s.renderer.uploadBytes)),scenePrepareMsGauge:stats(samples.map(s=>s.renderer.prepareMs)),gltfWork:Object.fromEntries(workKeys.map(k=>[k,{deltas:runs.map(({row})=>row.work.gltf[k].delta),medianPerApplicationRaf:median(runs.map(({row})=>row.work.gltf[k].perApplicationRaf)),scope:'actual cumulative glTF event counter boundaries, not whole-renderer work'}])),primaryGpuTimes:null,profileEnabled:false};
}
for(const entry of fs.readdirSync(base).filter(n=>n.startsWith('profile-'))){
 const f=path.join(base,entry,'report.json');if(!fs.existsSync(f))continue;const d=JSON.parse(fs.readFileSync(f));
 if(d.error||!d.results?.length)throw Error('Invalid profile '+entry);const r=d.results[0],raw=JSON.parse(gunzipSync(fs.readFileSync(path.join(base,entry,'raw.json.gz'))))[0];summary.profiles[entry]={cpuEvidence:cpuScopeEvidence(raw),gpuNamedPasses:r.gpuPassMs,gpuNamedSamples:r.gpuSamples,gpuNamedSupported:r.gpuSupported,glRafGpu:r.glRafGpu,glRafGpuMs:r.glRafGpuMs,api:r.apiOperations,work:r.work,scope:'separate instrumented diagnostics; excluded from primary throughput'};
}
for(const entry of (fs.existsSync('output/review-optimization')?fs.readdirSync('output/review-optimization'):[]).filter(n=>n.startsWith('next-cycle-1-')&&n.endsWith('-cuts'))){
 const file=path.join('output/review-optimization',entry,'report.json');if(!fs.existsSync(file))continue;const d=JSON.parse(fs.readFileSync(file));summary.cuts[entry]={status:d.status,requestedBackend:d.requestedBackend,stressCount:d.stressCount??0,runs:d.runs.map(r=>({status:r.status,backend:r.backend,metrics:r.metrics,transport:r.evidence?.transport,halfVisibility:r.evidence?.halfVisibility})),summary:d.summary,inputsStable:d.inputs?.every(i=>i.stable),scope:'simulated XR replay; not headset FPS; handler last/max are not full per-message latency histograms'};
}
summary.apiRetries={};
for(const entry of fs.readdirSync(base).filter(n=>n.startsWith('api64-'))){
 const f=path.join(base,entry,'report.json');if(!fs.existsSync(f))continue;const r=JSON.parse(fs.readFileSync(f));if(r.error||!r.results?.length)throw Error('Invalid API retry '+entry);
 summary.apiRetries[entry]={api:r.results[0].apiOperations,scope:'separate API diagnostic retry; not primary throughput'};
}
fs.writeFileSync(path.join(base,'summary.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({primaryCount:summary.primaryCount,groups:Object.fromEntries(Object.entries(summary.groups).map(([k,v])=>[k,{runs:v.runCount,fps:v.fpsPerRun.map(x=>+x.toFixed(2)),medianFps:+v.medianRunFps.toFixed(2),rafP99:v.rafPooled.p99,cpuP95:v.cpuPooled.p95,draws:v.rendererDrawGauge.median}]))},null,2));
