import {verificationKey} from '../../scripts/verification-cache.mjs';
import {createHash} from 'node:crypto';
console.log(JSON.stringify({node:process.version,execPath:process.execPath,key:await verificationKey('all',[]),relevantEnvironment:Object.entries(process.env).filter(([k])=>/^(BROWSER_|PUPPETEER_|CARGO_|RUST|GITHUB_ACTIONS$)/.test(k)).map(([name,value])=>({name,valueSha256:createHash('sha256').update(value).digest('hex')}))},null,2));
