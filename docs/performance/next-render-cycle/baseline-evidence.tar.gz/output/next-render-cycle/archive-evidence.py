import pathlib,tarfile,hashlib,json,io,os
root=pathlib.Path.cwd();base=root/'output/next-render-cycle';dest=root/'docs/performance/next-render-cycle/baseline-evidence.tar.gz';temporary=dest.with_suffix(dest.suffix+'.tmp');paths=[]
for p in sorted(base.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(base)
 if rel.name in ['archive-identity.json','archive-content-index.json']:continue
 if rel.parts[0]=='baseline' and not (str(rel)=='baseline/render-build.json' or str(rel).startswith('baseline/pkg/')):continue
 paths.append(p)
paths+=sorted((root/'output/review-optimization').glob('next-cycle-1-*-cuts/report.json'))
paths+=sorted(p for p in (root/'output/verification').rglob('*') if p.is_file())
seen={};index={};saved=0
with tarfile.open(temporary,'w:gz',compresslevel=9) as archive:
 for p in paths:
  data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();name=str(p.relative_to(root));key=(sha,len(data));previous=seen.get(key);entry={'sha256':sha,'bytes':len(data)}
  if previous and (root/previous).read_bytes()==data:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=previous;info.size=0;archive.addfile(info);entry['hardlinkTo']=previous;saved+=len(data)
  else:
   archive.add(p,arcname=name,recursive=False);seen[key]=name
  index[name]=entry
 content=json.dumps({'version':1,'files':index},indent=2).encode()+b'\n';info=tarfile.TarInfo('output/next-render-cycle/archive-content-index.json');info.size=len(content);info.mode=0o644;archive.addfile(info,io.BytesIO(content))
# Verify actual archived payloads and every lossless link before replacing the prior container.
with tarfile.open(temporary,'r:gz') as archive:
 for name,entry in index.items():
  member=archive.getmember(name)
  if 'hardlinkTo' in entry:
   assert member.islnk() and member.linkname==entry['hardlinkTo']
   assert index[member.linkname]['sha256']==entry['sha256'] and index[member.linkname]['bytes']==entry['bytes']
  else:
   data=archive.extractfile(member).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name
os.replace(temporary,dest)
(base/'archive-content-index.json').write_bytes(content)
result={'path':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'files':len(paths)+1,'uniquePayloads':len(seen),'losslessHardlinkDeduplication':True,'duplicatePayloadBytesSaved':saved,'archivePayloadVerification':'all unique archived bytes and every hardlink target/hash/size verified','contains':'all raw primary/profile/API/cut evidence, captures, commands, audits, exact harness versions, verified release pkg, full frozen hash manifest, final local verification logs/receipt','reconstructRuntime':'git checkout baseline b7de3be56 plus archived pkg; verify all2461 files using render-build.json; current tool revisions are separate from frozen runtime'}
print(json.dumps(result,indent=2));(base/'archive-identity.json').write_text(json.dumps(result,indent=2)+'\n')
