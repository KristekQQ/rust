import json,hashlib,tarfile,io
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-8');base=root/'output/next-render-cycle-8';dest=root/'docs/performance/next-render-cycle/batch-8/evidence.tar.gz'
files={};served={}
def add(name,file):
 file=Path(file)
 if file.is_file():files[name]=file
for p in base.iterdir():
 if p.is_file() and p.name!='archive-build.log':add('logs/'+p.name,p)
 if p.is_dir() and p.name.startswith(('primary-','diagnostic-','pilot-','smoke-')):
  for q in p.iterdir():
   if q.is_file():add('runs/'+p.name+'/'+q.name,q)
  report=json.loads((p/'report.json').read_text())
  # All raw manifests retained; primary/diagnostic runtime bytes independently verified.
  for item in report.get('manifest',[]):
   if report['status']=='PASS' and p.name.startswith(('primary-','diagnostic-')):
    key=(item['source'],item['url']);old=served.get(key)
    if old and old['sha256']!=item['sha256']:raise ValueError('Accepted series served changing bytes '+str(key))
    served[key]=item
for relative in ['scripts/benchmark-xr-presentation.mjs','tests/xr/presentation-benchmark.js','tests/xr/presentation-benchmark.html']:
 add('snapshots/candidate/'+relative,base/'candidate'/relative)
for snap in ['baseline','candidate']:
 add('snapshots/'+snap+'/render-build.json',base/snap/'render-build.json')
 for p in (base/snap/'pkg').iterdir():
  if p.is_file():add('snapshots/'+snap+'/pkg/'+p.name,p)
for (kind,url),item in served.items():
 p=(root if kind=='harness' else base/'candidate')/url.lstrip('/')
 b=p.read_bytes()
 if hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('Served input no longer matches '+str(p))
 add('served/'+kind+'/'+url.lstrip('/'),p)
for p in (root/'output/verification').iterdir():
 if p.is_file() and (p.suffix in ['.json','.log'] or p.name.startswith(('xr-gl-presentation','rim-gameplay-gl-shared','webxr-webgpu'))):add('verification/'+p.name,p)
add('processing/summarize.py','/private/tmp/b8-summary.py');add('processing/archive.py','/private/tmp/b8-archive.py')
for name in ['RESULTS.json','PROTOCOL.md','DESIGN.md','REVIEW.md','COMMANDS.md','VERIFICATION.json']:
 add('documentation/'+name,root/'docs/performance/next-render-cycle/batch-8'/name)
index={};retained={};total=0
with tarfile.open(dest,'w:gz',compresslevel=6) as tar:
 for name,p in sorted(files.items()):
  b=p.read_bytes();sha=hashlib.sha256(b).hexdigest();total+=len(b);entry={'bytes':len(b),'sha256':sha}
  if sha in retained:entry['sameAs']=retained[sha]
  else:
   retained[sha]=name;info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
  index[name]=entry
 b=json.dumps(index,indent=2).encode();info=tarfile.TarInfo('INDEX.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
with tarfile.open(dest,'r:gz') as tar:
 for name,entry in index.items():
  b=tar.extractfile(entry.get('sameAs',name)).read()
  assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256'],name
record={'path':str(dest.relative_to(root)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'indexedFiles':len(index),'storedUniqueContents':len(retained),'logicalBytes':total,'entriesVerified':True,'scope':'all run records/captures, retained failures, actually served primary/diagnostic runtime/harness bytes, both pkg snapshots/manifests, gate logs; transient pilot harness hashes preserved in raw reports; deduplicated INDEX aliases; no nested historical archives'}
(dest.parent/'ARCHIVE.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
