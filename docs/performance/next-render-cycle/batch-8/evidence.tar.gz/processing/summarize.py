import json,statistics,hashlib
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-8');base=root/'output/next-render-cycle-8'
def stats(v):
 v=sorted(x for x in v if isinstance(x,(float,int)))
 if not v:return None
 import math
 return {'count':len(v),'mean':sum(v)/len(v),'median':statistics.median(v),'p95':v[max(0,math.ceil(.95*len(v))-1)],'p99':v[max(0,math.ceil(.99*len(v))-1)],'max':v[-1]}
r={'evidence':'desktop simulated XR only, no physical headset/compositor measurement','workloads':{},'diagnostics':{},'power':[],'failures':[]}
for p in sorted(base.glob('primary-*/report.json')):
 a=json.loads(p.read_text());case=p.parent.name.removeprefix('primary-');out={'status':a['status'],'options':a['options'],'exactPairs':a['comparisons'],'runs':[],'summary':{}}
 for row in a['runs']:
  if row['status']!='PASS':continue
  n=len(row['sample']['frames']);b=row['boundaryStart'];e=row['boundaryEnd'];work={k:(v['delta']/n if v['delta'] is not None else None) for k,v in row['summary']['work']['gltf'].items()};out['runs'].append({'id':row['id'],'route':row['route'],'pair':row['pair'],'frames':n,'cpuMs':row['summary']['callbackCpuMs'],'intervalMs':row['summary']['desktopRafIntervalMs'],'fps':row['summary']['observedDesktopHz'],'workPerFrame':work,'queryStart':b['cleanProof'],'queryEnd':e['cleanProof'],'head':b.get('actualWorldHead')});r['power'].append({'case':case,'id':row['id'],'before':row['powerBefore'],'after':row.get('powerAfter')})
 for route in ['canvas-transfer','shared-framebuffer']:
  rows=[v for v in out['runs'] if v['route']==route]
  out['summary'][route]={'runCount':len(rows),'frames':sum(v['frames'] for v in rows),'medianRunMeanCpuMs':statistics.median(v['cpuMs']['mean'] for v in rows) if rows else None,'medianRunFps':statistics.median(v['fps'] for v in rows) if rows else None,'cpuP95ByRun':[v['cpuMs']['p95'] for v in rows],'cpuP99ByRun':[v['cpuMs']['p99'] for v in rows],'cpuMaxByRun':[v['cpuMs']['max'] for v in rows]}
 out['pairedRatios']=[]
 for pair in [1,2,3]:
  rows={v['route']:v for v in out['runs'] if v['pair']==pair}
  if len(rows)==2:
   x,y=rows['canvas-transfer'],rows['shared-framebuffer'];out['pairedRatios'].append({'pair':pair,'cpuCandidateOverBaseline':y['cpuMs']['mean']/x['cpuMs']['mean'],'fpsCandidateOverBaseline':y['fps']/x['fps'],'workIdentical':x['workPerFrame']==y['workPerFrame']})
 r['workloads'][case]=out
for p in sorted(base.glob('diagnostic-*/report.json')):
 a=json.loads(p.read_text());out={'status':a['status'],'runs':[]}
 for row in a['runs']:
  if 'presentationProfile' not in row:continue
  prof=row['presentationProfile'];scopes={}
  for f in prof['frames']:
   for s in f['scopes']+([f['application']] if f['application'] else []):
    k=s['label'];entry=scopes.setdefault(k,{'cpu':[],'gpu':[],'statuses':{}})
    if s.get('cpuMs') is not None:entry['cpu'].append(s['cpuMs'])
    if s.get('gpuStatus')=='valid' and s.get('gpuMs') is not None:entry['gpu'].append(s['gpuMs'])
    st=s.get('gpuStatus','absent');entry['statuses'][st]=entry['statuses'].get(st,0)+1
  scopes={k:{'cpuMs':stats(v['cpu']),'validGpuMs':stats(v['gpu']),'gpuStatuses':v['statuses']} for k,v in scopes.items()}
  b=row['boundaryStart'];e=row['boundaryEnd'];n=len(row['sample']['frames'])
  def delta(x,y):
   if isinstance(x,dict) and isinstance(y,dict):return {k:delta(x.get(k),v) for k,v in y.items() if k in x}
   if isinstance(x,(float,int)) and isinstance(y,(float,int)) and not isinstance(x,bool):return {'delta':y-x,'perFrame':(y-x)/n}
   return None
  out['runs'].append({'route':row['route'],'frames':n,'scopes':scopes,'profileMetadata':{k:v for k,v in prof.items() if k!='frames'},'apiDelta':delta(b.get('api'),e.get('api')),'settings':row['metadata']['runtimeSettings']})
 r['diagnostics'][p.parent.name]=out
for p in base.glob('*/report.json'):
 a=json.loads(p.read_text())
 if a['status']=='FAIL':r['failures'].append({'path':str(p.relative_to(base)),'errors':a.get('errors')})
(root/'docs/performance/next-render-cycle/batch-8/RESULTS.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v['summary'] for k,v in r['workloads'].items()},indent=2))
