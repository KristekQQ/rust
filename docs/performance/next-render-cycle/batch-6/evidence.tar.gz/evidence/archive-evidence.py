import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();root=repo/'output/next-render-cycle-6';dest=repo/'docs/performance/next-render-cycle/batch-6/evidence.tar.gz';selected={}
def add(name,p):
 assert p.is_file() and not p.is_symlink(),str(p)
 selected[name]=p
labels=['baseline','candidate']
for p in root.rglob('*'):
 if p.is_file() and not p.is_symlink() and p.relative_to(root).parts[0] not in labels and p.name not in ['ARCHIVE-AUDIT.json']:
  add('evidence/'+str(p.relative_to(root)),p)
b=json.loads((root/'baseline/render-build.json').read_text());changed=set()
for label in labels:
 m=json.loads((root/label/'render-build.json').read_text());different={p for p in set(b['files'])|set(m['files']) if b['files'].get(p)!=m['files'].get(p)};changed|=different
 assert not any(p.startswith('assets/') for p in different),'Changed assets need explicit inclusion'
 add('frozen/'+label+'/render-build.json',root/label/'render-build.json')
 for name in m['files']:
  if name.startswith('pkg/') or name in different:add('frozen/'+label+'/'+name,root/label/name)
# Baseline sides of every changed input, including candidate-only changes.
for name in changed:
 if name in b['files']:add('frozen/baseline/'+name,root/'baseline'/name)
for p in (repo/'output/verification').rglob('*'):
 if p.is_file() and not p.is_symlink():add('verification/'+str(p.relative_to(repo/'output/verification')),p)
owned=['src/gltf_indices.rs','src/lib.rs','src/render/gltf_gpu.rs','src/render/renderer.rs','src/web.rs','js/engine.js','js/engine.d.ts','scripts/test-browser.mjs','tests/render-performance.js','tests/xr/gltf-instance-checks.js','tests/gltf-indices.html','tests/gltf-indices.js','tests/gltf-batching.js']
for name in owned:add('final-source/'+name,repo/name)
readme=b'''Batch6 local evidence; parent4969d9f984f152101dc4bf2d930442be535f9c7e.
Reconstruct isolated roots from this tracked parent and overlay frozen/{baseline,candidate} changed inputs and generated packages; verify full render-build.json. Unchanged assets, dependencies and historical documentation archives are not duplicated. Primary-driver contains the exact common harness. Final runtime/pkg must equal measured candidate.
Retains clean24runs, pilot calibration, original-U32 diagnostics, zero-tolerance pixels, actual API/index layouts, raw RAF, commands, environment and final gate. Partial compiler/type errors and first point/line shadow validation failure are retained. Initial diagnostic left an owned idle Node with no children after browser exit; only that Node received SIGTERM. Repeated probe records successful unforced bounded browser/server closure and an explicit exit after persisted results because native handles could linger. Primary maintained cleanup succeeded. Initial pre-repair binary was not separately snapshotted; the one condition repair is described in DESIGN/REPORT and source-review evidence. Earlier generic/direct XR and batching passed, but source editing during that first partial run invalidated its final build check; it is not accepted final evidence. Final full stable gate is authoritative. No tolerance weakening.
Requested index bytes/payload are not physical driver VRAM. CPU callback wall time is not pure CPU-cycle time; clean GPU timing intentionally unavailable. No physical Quest, fresh Three, CI, push, merge, deployment or shared-server restart evidence. Inherited B4 moving-stress strict image issue remains open. Every archived payload and exact-content hardlink is read back against SHA256SUMS.json.
'''
manifest={};seen={};links=0;total=0
with tarfile.open(dest,'w:gz',compresslevel=6) as tf:
 for name,p in sorted(selected.items()):
  data=p.read_bytes();h=hashlib.sha256(data).hexdigest();manifest[name]={'sha256':h,'bytes':len(data)};total+=len(data);info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;key=(h,len(data))
  if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];tf.addfile(info);links+=1
  else:info.size=len(data);tf.addfile(info,io.BytesIO(data));seen[key]=name
 for name,data in [('README.txt',readme),('SHA256SUMS.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as tf:
 assert json.load(tf.extractfile('SHA256SUMS.json'))==manifest
 for name,m in manifest.items():
  data=tf.extractfile(name).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256'],name
summary={'path':str(dest.relative_to(repo)),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payloads':len(manifest),'storedEntries':len(manifest)+2,'uniquePayloads':len(seen),'exactContentHardlinks':links,'recordedUncompressedBytes':total,'everyPayloadAndHardlinkReadBack':True,'frozenChangedInputsIncluded':sorted(changed),'unchangedBaseAssetsExcluded':True}
(root/'ARCHIVE-AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
