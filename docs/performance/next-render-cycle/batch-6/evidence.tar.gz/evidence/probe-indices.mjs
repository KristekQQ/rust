import fs from 'node:fs/promises';import puppeteer from 'puppeteer';import {PNG} from 'pngjs';
import {serveFrozen,hash,pixelDifference,boundedCleanup} from '../../scripts/render-performance-lib.mjs';import {browserArgs} from '../../scripts/browser-options.mjs';import {installApiCounters} from '../../scripts/render-performance-api.mjs';
const dir='output/next-render-cycle-6',configs=JSON.parse(await fs.readFile(dir+'/PRIMARY-CONFIGS.json')),server=await serveFrozen(dir+'/candidate',process.cwd());let browser;const rows=[];
try{
 browser=await puppeteer.launch({headless:true,args:browserArgs(),protocolTimeout:180000});
 for(const c of configs.cases){const captures=[];for(const original of [true,false]){
  const page=await browser.newPage();await page.setViewport({width:1280,height:720,deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});await page.evaluateOnNewDocument(installApiCounters);
  await page.evaluateOnNewDocument(()=>{window.indexApiProof={buffers:[],indexBindings:{},stripPipelines:{},glDrawTypes:{}};const p=window.indexApiProof;
   if(typeof GPUDevice!=='undefined'){
    const create=GPUDevice.prototype.createBuffer;GPUDevice.prototype.createBuffer=function(d){const b=create.call(this,d);if(d.label==='glTF shared indices')p.buffers.push({size:b.size,requestedSize:d.size,usage:d.usage});return b;};
    const pipeline=GPUDevice.prototype.createRenderPipeline;GPUDevice.prototype.createRenderPipeline=function(d){if(d.label==='glTF PBR variant'){const key=JSON.stringify(d.primitive);p.stripPipelines[key]=(p.stripPipelines[key]||0)+1;}return pipeline.call(this,d);};
    const bind=GPURenderPassEncoder.prototype.setIndexBuffer;GPURenderPassEncoder.prototype.setIndexBuffer=function(b,f,...rest){if(b.label==='glTF shared indices')p.indexBindings[f]=(p.indexBindings[f]||0)+1;return bind.call(this,b,f,...rest);};
   }
   if(typeof WebGL2RenderingContext!=='undefined')for(const name of ['drawElements','drawElementsInstanced']){const old=WebGL2RenderingContext.prototype[name];WebGL2RenderingContext.prototype[name]=function(...args){const key=name+':'+args[2];p.glDrawTypes[key]=(p.glDrawTypes[key]||0)+1;return old.apply(this,args);};}
  });
  const url=server.url+'/tests/render-performance.html?'+new URLSearchParams({family:c.family,load:c.load,backend:c.backend,profile:0,width:1280,height:720,...(original?{indices:'original'}:{})});await page.goto(url,{waitUntil:'domcontentloaded',timeout:60000});await page.waitForFunction('!!window.bench',{timeout:60000});await page.evaluate(()=>bench.capturePose());
  const value=await page.evaluate(async()=>{const {capturePixels}=await import('/tests/pixels.js');const image=await capturePixels(document.querySelector('canvas'));const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;canvas.getContext('2d').putImageData(image,0,0);return {image:canvas.toDataURL().split(',')[1],debug:bench.engine.debugStats(),layouts:bench.engine.gltfIndexLayouts(),backend:bench.engine.renderer_backend(),api:window.renderApiCounters,indexApiProof:window.indexApiProof};});if(errors.length||value.api.errors.length)throw Error(JSON.stringify({errors,api:value.api.errors}));
  const png=Buffer.from(value.image,'base64');delete value.image;const file=`indices-${c.family}-${c.load}-${c.backend}-${original?'original':'compact'}.png`;await fs.writeFile(dir+'/'+file,png);captures.push(PNG.sync.read(png));rows.push({...c,result:undefined,original,file,sha256:hash(png),...value});await fs.writeFile(dir+'/INDEX-PROOF.json',JSON.stringify(rows,null,2));await page.close();console.log('DONE '+file);
 }const delta=pixelDifference(captures[0],captures[1],{channelTolerance:0,pixelFractionTolerance:0});rows.at(-1).originalIndexPixelDifference=delta;await fs.writeFile(dir+'/INDEX-PROOF.json',JSON.stringify(rows,null,2));if(!delta.pass)throw Error('Independent Uint32 image mismatch '+JSON.stringify(delta));}
 await fs.writeFile(dir+'/index-served-manifest.json',JSON.stringify(server.manifest(),null,2));if(server.errors().length)throw Error(JSON.stringify(server.errors()));
}finally{
 const cleanup=[];
 if(browser)cleanup.push(await boundedCleanup(()=>browser.close(),{label:'owned browser',force:()=>{browser.disconnect();browser.process()?.kill('SIGKILL');}}));
 server.forceClose();cleanup.push(await boundedCleanup(()=>server.close(),{label:'server',force:()=>server.forceClose()}));
 await fs.writeFile(dir+'/probe-cleanup.json',JSON.stringify({cleanup,activeResourcesBeforeExplicitExit:process.getActiveResourcesInfo(),exit:'explicit after persisted results and bounded owned cleanup'},null,2));
}
process.exit(0);
