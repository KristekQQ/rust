import subprocess,json,os,datetime
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-7');os.chdir(root);out=root/'output/next-render-cycle-7';env=os.environ.copy();env['PATH']='/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'];commands=[]
for bk in ['webgpu','webgl']:
 count=2048 if bk=='webgpu' else 1024
 args=['node','scripts/render-performance.mjs','regression','--baseline-root',str(out/'diagnostic'),'--candidate-root',str(out/'restored'),'--config',str(out/('cal-rim-stress-'+bk)/'config.json'),'--warmup','8000','--sample','25000','--pairs','3','--no-profile','--family','rim-stress','--backend',bk,'--load',str(count),'--max-load','2048','--width','1280','--height','720','--startup-timeout','60000','--pixel-channel','0','--pixel-fraction','0','--out',str(out/('restored-'+bk))]
 entry={'args':args,'started':datetime.datetime.now().isoformat()};commands.append(entry);(out/'restored-commands.json').write_text(json.dumps(commands,indent=2))
 with open(out/('restored-'+bk+'.log'),'w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 entry.update(exit=r.returncode,finished=datetime.datetime.now().isoformat());(out/'restored-commands.json').write_text(json.dumps(commands,indent=2));print(bk,r.returncode,flush=True)
# Preserve any threshold failure and still measure the other backend.
raise SystemExit(int(any(x['exit'] for x in commands)))
