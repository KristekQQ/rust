from pathlib import Path
p=Path('/private/tmp/rust-next-render-cycle-7/src/render/gltf_gpu.rs');s=p.read_text()
s=s.replace('    active_draws: [Vec<usize>; 2],\n','    active_draws: [Vec<usize>; 2],\n    // Failed pose updates may already have changed active before publication.\n    active_draws_valid: bool,\n',1)
s=s.replace('            active_draws,\n','            active_draws,\n            active_draws_valid: false,\n',1)
s=s.replace('        model.active.clear();\n','        model.active_draws_valid = false;\n        model.active.clear();\n',1)
s=s.replace('        model.bounds = crate::render_overlap::union_bounds(\n','        model.active_draws_valid = true;\n        model.bounds = crate::render_overlap::union_bounds(\n',1)
a=s.index('pub fn draw_count(model: &GpuModel, blend: bool) -> usize {');b=s.index('\nfn wrap(',a)
s=s[:a]+'''pub fn draw_count(model: &GpuModel, blend: bool) -> usize {
    if model.last_pose.is_none() {
        return 0;
    }
    if model.active_draws_valid {
        return model.active_draws[usize::from(blend)].len();
    }
    // Preserve the original partial-update behavior after an Err. In particular,
    // returning to an older successful stamp must not publish stale lists.
    model
        .draws
        .iter()
        .filter(|d| {
            model.active.contains(&d.node)
                && (model.materials[d.material].alpha == AlphaMode::Blend) == blend
        })
        .count()
}
'''+s[b:]
p.write_text(s)
