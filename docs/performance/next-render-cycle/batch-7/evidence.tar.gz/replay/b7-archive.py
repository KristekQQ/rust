from pathlib import Path
import tarfile,hashlib,json,io
root=Path('/private/tmp/rust-next-render-cycle-7');out=root/'output/next-render-cycle-7';dest=root/'docs/performance/next-render-cycle/batch-7'
# Exact-content dedup: preserve every named measurement/capture, store repeated bytes as TAR hardlinks.
private={'hardware.txt','processes-before.txt'}
files={}
for p in out.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(out);parts=rel.parts
 if parts[0] in ['baseline','diagnostic','candidate','restored']:
  if len(parts)==2 and parts[1]=='render-build.json':pass
  elif len(parts)>2 and parts[1] in ['src','js','pkg','scripts','tests']:pass
  elif len(parts)==2 and parts[1] in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','package.json','package-lock.json','AGENTS.md']:pass
  else:continue
 if p.name in private:continue
 if rel.as_posix() in ['archive-inventory.json','archive-verification.json']:continue
 files[rel.as_posix()]=p
inventory=[];seen={};archive=dest/'evidence.tar.gz';unique=0
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for name,p in sorted(files.items()):
  data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo(name);info.mtime=0;info.mode=0o644
  row={'file':name,'bytes':len(data),'sha256':sha}
  if sha in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[sha];row['hardlink']=seen[sha];tf.addfile(info)
  else:
   seen[sha]=name;unique+=len(data);info.size=len(data);tf.addfile(info,io.BytesIO(data))
  inventory.append(row)
 inv=json.dumps(inventory,separators=(',',':')).encode();info=tarfile.TarInfo('archive-inventory.json');info.size=len(inv);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(inv))
with tarfile.open(archive,'r:gz') as tf:
 for row in inventory:
  data=tf.extractfile(row['file']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['file']
result={'passed':True,'archive':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(inventory),'logicalBytes':sum(x['bytes'] for x in inventory),'uniqueContentBytes':unique,'everyEntryAndHardlinkReadbackVerified':True,'privacyExclusions':sorted(private),'frozenScope':'Full src/js/pkg/scripts/tests and root build configs per build; complete render-build file inventory. Unchanged assets, vendored dependencies, fixtures and original examples require parent checkout and hash verification; full local frozen trees remain under ignored output.'}
(out/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
