import subprocess,json,os,datetime
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-7');os.chdir(root);out=root/'output/next-render-cycle-7';env=os.environ.copy();env['PATH']='/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'];commands=[]
def run(tag,args):
 entry={'tag':tag,'args':['node','scripts/render-performance.mjs']+args+['--out',str(out/tag)],'started':datetime.datetime.now().isoformat()};commands.append(entry);(out/'three-commands.json').write_text(json.dumps(commands,indent=2))
 with open(out/(tag+'.log'),'w') as f:r=subprocess.run(entry['args'],stdout=f,stderr=subprocess.STDOUT,env=env)
 entry.update(exit=r.returncode,finished=datetime.datetime.now().isoformat());(out/'three-commands.json').write_text(json.dumps(commands,indent=2));print(tag,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
common=['--max-load','2048','--width','1280','--height','720','--startup-timeout','60000']
for family,bk,count in [('rim-common','webgpu',2048),('rim-common','webgl',2048),('rim-stress','webgl',1024)]:
 cal='cal-three-'+family+'-'+bk;settings=['--family',family,'--backend',bk,'--load',str(count)]+common
 run(cal,['calibrate','--baseline-root',str(out/'candidate'),'--warmup','1000','--sample','3000','--no-profile']+settings)
 run('three-'+family+'-'+bk,['compare','--baseline-root',str(out/'candidate'),'--three-root',str(out/'candidate'),'--config',str(out/cal/'config.json'),'--warmup','8000','--sample','25000','--pairs','3','--no-profile']+settings)
# separately profiled common control, native WebGPU per-pass vs Three GL interval explicitly distinct
run('cal-three-profile',['calibrate','--baseline-root',str(out/'candidate'),'--family','rim-common','--backend','webgpu','--load','2048','--warmup','1000','--sample','3000']+common)
run('three-profile',['compare','--baseline-root',str(out/'candidate'),'--three-root',str(out/'candidate'),'--config',str(out/'cal-three-profile/config.json'),'--family','rim-common','--backend','webgpu','--load','2048','--warmup','8000','--sample','25000','--pairs','1']+common)
