import subprocess,json,os,datetime
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-7');os.chdir(root)
out=root/'output/next-render-cycle-7';env=os.environ.copy();env['PATH']='/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH']
axes=[('anchor','production',1280,720),('low','production',640,360),('high','production',1920,1080),('cheap','cheap-fragment',1280,720),('shadow-off','no-shadows',1280,720),('fxaa-off','no-fxaa',1280,720),('depth','depth-order',1280,720),('anchor-repeat','production',1280,720)]
commands=[]
for i,(name,mode,w,h) in enumerate(axes):
 for backend in (['webgpu','webgl'] if i%2==0 else ['webgl','webgpu']):
  tag='matrix-'+backend+'-'+name;dest=out/tag
  args=['node','scripts/render-performance.mjs','smoke','--baseline-root',str(out/'diagnostic'),'--family','rim-stress','--backend',backend,'--load',str(2048 if backend=='webgpu' else 1024),'--max-load','2048','--width',str(w),'--height',str(h),'--experiment',mode,'--warmup','8000','--sample','25000','--startup-timeout','60000','--out',str(dest)]
  entry={'tag':tag,'args':args,'started':datetime.datetime.now().isoformat()};commands.append(entry);(out/'matrix-commands.json').write_text(json.dumps(commands,indent=2))
  with open(out/(tag+'.log'),'w') as f: r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
  entry.update(exit=r.returncode,finished=datetime.datetime.now().isoformat());(out/'matrix-commands.json').write_text(json.dumps(commands,indent=2));print(tag,r.returncode,flush=True)
  if r.returncode: raise SystemExit(r.returncode)
