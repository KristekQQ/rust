import subprocess,json,os,datetime
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-7');os.chdir(root);out=root/'output/next-render-cycle-7';env=os.environ.copy();env['PATH']='/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:'+env['PATH'];commands=[]
def run(tag,args):
 entry={'tag':tag,'args':['node','scripts/render-performance.mjs']+args+['--out',str(out/tag)],'started':datetime.datetime.now().isoformat()};commands.append(entry);(out/'primary-commands.json').write_text(json.dumps(commands,indent=2))
 with open(out/(tag+'.log'),'w') as f:r=subprocess.run(entry['args'],stdout=f,stderr=subprocess.STDOUT,env=env)
 entry.update(exit=r.returncode,finished=datetime.datetime.now().isoformat());(out/'primary-commands.json').write_text(json.dumps(commands,indent=2));print(tag,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
common=['--max-load','2048','--width','1280','--height','720','--startup-timeout','60000','--pixel-channel','0','--pixel-fraction','0']
for i,family in enumerate(['rim-static','rim-stress','rim-mixed','arena-static']):
 for bk in (['webgpu','webgl'] if i%2==0 else ['webgl','webgpu']):
  count=1 if family in ['rim-static','arena-static'] else (2048 if family=='rim-stress' and bk=='webgpu' else 1024)
  cal='cal-'+family+'-'+bk;settings=['--family',family,'--backend',bk,'--load',str(count)]+common
  run(cal,['calibrate','--baseline-root',str(out/'diagnostic'),'--warmup','1000','--sample','3000','--no-profile']+settings)
  run('primary-'+family+'-'+bk,['compare','--baseline-root',str(out/'diagnostic'),'--candidate-root',str(out/'candidate'),'--config',str(out/cal/'config.json'),'--warmup','8000','--sample','25000','--pairs','3','--no-profile']+settings)
# separate fresh profiled and API diagnostics at exactly the same workload
for bk in ['webgl','webgpu']:
 count=2048 if bk=='webgpu' else 1024
 run('profile-candidate-'+bk,['smoke','--baseline-root',str(out/'candidate'),'--family','rim-stress','--backend',bk,'--load',str(count),'--warmup','8000','--sample','25000','--diagnostics']+common)
