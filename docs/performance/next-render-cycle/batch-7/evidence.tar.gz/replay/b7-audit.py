import json,gzip,math,hashlib
from pathlib import Path
root=Path('/private/tmp/rust-next-render-cycle-7');out=root/'output/next-render-cycle-7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(a):
 a=sorted(a);n=len(a)
 if not n:return None
 return dict(count=n,mean=sum(a)/n,median=a[math.ceil(n*.5)-1],p95=a[math.ceil(n*.95)-1],p99=a[math.ceil(n*.99)-1],max=a[-1])
checks=[];frame_total=0
for p in sorted(out.glob('*/report.json')):
 name=p.parent.name
 if not name.startswith(('primary-','three-','matrix-','profile-candidate-','restored-')):continue
 r=json.load(open(p))
 assert not r.get('error'),(name,r.get('error'))
 assert not r.get('driverInputsChangedDuringRun'),name
 raw=json.loads(gzip.decompress((p.parent/'raw.json.gz').read_bytes()))
 for v in r['results']:
  d=next(x for x in raw if x['id']==v['id']);frame_total+=len(d['frames'])
  for field,a in [('rafInterval',[b['stamp']-a['stamp'] for a,b in zip(d['frames'],d['frames'][1:])]),('rafCallbackCpu',[x['cpu'] for x in d['frames']])]:
   expect=stats(a)
   for k,val in expect.items():assert abs(v[field][k]-val)<1e-7,(name,v['id'],field,k,v[field][k],val)
  if not v['profiling']:
   assert not d['gpu'] and not d['glRafGpu']['enabled'] and not d['glRafGpu']['queriesBegun'],name
  for g in d['gpu']:
   assert g['available'] and g['ageFrames']>=0 and all(math.isfinite(x) and x>=0 for x in g['passesMs'].values()),name
  for g in d['glRafGpu']['samples']:assert math.isfinite(g['elapsedMs']) and g['elapsedMs']>=0,name
  assert sha(p.parent/v['capture']['file'])==v['capture']['sha256'],name
 if name.startswith(('primary-','restored-')):
  assert len(r['results'])==6 and r['measurementProtocol']['warmup']==8000 and r['measurementProtocol']['sample']==25000,name
  assert [v['label'] for v in r['results']]==['baseline','candidate','candidate','baseline','baseline','candidate'],name
  assert all(q['pixel']['exact'] and q['pixel']['pass'] for c in r['comparisons'] for q in c['paired']),name
 for label in ['baseline','candidate']:
  mp=p.parent/f'manifest-{label}.json'
  if not mp.exists():continue
  runtime=Path(r[label+'Root'])
  for item in json.load(open(mp)):
   f=item['url'].lstrip('/');expected=r['driverIdentity']['files'].get(f) if item['source']=='harness' else None
   if item['source']=='harness':assert expected==item['sha256'],(name,f,'harness identity')
   else:assert sha(runtime/f)==item['sha256'],(name,f,'frozen payload')
 checks.append({'report':name,'runs':len(r['results']),'driver':r['driverIdentity']['sha256'],'frames':sum(len(x['frames']) for x in raw)})
# All snapshot bytes; this runs only after timing, never concurrently with samples.
frozen=0
for name in ['baseline','diagnostic','candidate','restored']:
 p=out/name;m=json.load(open(p/'render-build.json'));assert m['complete']
 for f,v in m['files'].items():assert sha(p/f)==v['sha256'],(name,f);frozen+=1
current=json.load(open(out/'restored/render-build.json'))
for f in current['files']:
 if f.startswith(('src/','js/','pkg/')):assert sha(root/f)==current['files'][f]['sha256'],('current measured runtime',f)
result={'passed':True,'reports':checks,'runs':sum(x['runs'] for x in checks),'rawFrames':frame_total,'frozenFiles':frozen,'independentRawDistributions':True,'servedPayloadsAndDriverHashes':True,'cleanProfilerOffAsserted':True,'restoredRuntimeEqualsCurrent':True}
(out/'final-input-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='reports'}))
