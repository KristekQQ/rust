import json,subprocess,shlex,os,signal,datetime
from pathlib import Path
root=Path('output/next-render-cycle-3');out=root/'worker-extra-cli-cleanups.json';items=json.loads(out.read_text())if out.exists()else[]
for line in subprocess.check_output(['ps','-Ao','pid,ppid,command'],text=True).splitlines()[1:]:
 fields=line.strip().split(None,2)
 if len(fields)!=3:continue
 pid,parent,command=fields
 if int(parent)!=74023 or 'scripts/benchmark-rim-cuts.mjs b3-final-'not in command:continue
 args=shlex.split(command);i=args.index('scripts/benchmark-rim-cuts.mjs');label=args[i+1];p=Path('output/review-optimization')/(label+'-cuts')/'report.json'
 if not p.exists():continue
 r=json.loads(p.read_text())
 if r['status']!='PASS':continue
 assert len(r['runs'])==3 and all(x['status']=='PASS'for x in r['runs'])and all(x['stable']for x in r['inputs'])
 items.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedPid':int(pid),'parent':int(parent),'command':command,'completedReport':str(p),'status':'PASS actual3replays; browser/server close returned','action':'SIGTERM completed own CLI retaining Node handles; original coordinator reports null exit code (signal), not a fresh test PASS'})
 os.kill(int(pid),signal.SIGTERM)
 print('Completed own CLI cleaned',pid,label)
out.write_text(json.dumps(items,indent=2)+'\n')
