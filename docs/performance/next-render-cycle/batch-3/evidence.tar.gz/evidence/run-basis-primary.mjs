import fs from 'node:fs/promises';
import {spawn,execFileSync} from 'node:child_process';
const root='output/next-render-cycle-3',configs=JSON.parse(await fs.readFile(root+'/PRIMARY-CONFIGS.json'));
async function snapshot(label){const evidence={at:new Date().toISOString(),label};for(const [key,cmd,args] of [['gpuProcesses','ps',['-Ao','pid,ppid,%cpu,etime,command']],['power','pmset',['-g','batt']],['gpuUtilization','ioreg',['-r','-c','AGXAccelerator','-d','1']]]){try{let s=execFileSync(cmd,args,{encoding:'utf8',maxBuffer:8388608});if(key==='gpuProcesses')s=s.split('\n').filter(l=>l.includes('gpu-process')).map(l=>l.slice(0,300)).join('\n');if(key==='gpuUtilization')s=[...s.matchAll(/"(?:Device Utilization %|Renderer Utilization %|Tiler Utilization %|In use system memory)"\s*=\s*\d+/g)].map(m=>m[0]).join('\n')||'unavailable';evidence[key]=s;}catch(e){evidence[key]='unavailable: '+e.message;}}await fs.appendFile(root+'/basis-primary-environment.jsonl',JSON.stringify(evidence)+'\n');}

const expected=(JSON.parse(await fs.readFile(root+'/candidate-basis/render-build.json'))).build;
if(expected.wasm!=='cf135b73fba51cd5096ef70a149a5ba7a4d3408be1dee46f4dc4ca5201a94699')throw Error('Unexpected candidate identity');
const steps=[];
for(const c of [...configs.cases].sort((a,b)=>(b.family==='rim-clustered'&&b.load===1024)-(a.family==='rim-clustered'&&a.load===1024))){
 const out=root+'/primary-basis-'+c.family+'-'+c.load+'-'+c.backend;
 try{const r=JSON.parse(await fs.readFile(out+'/report.json'));if(r.candidateBuildFingerprint?.wasm!==expected.wasm)throw Error('Existing results belong to a different candidate: '+out);if(r.results.length===6&&!r.error&&r.cleanup.every(x=>x.complete)){console.log('REUSE '+out);continue;}}catch(e){if(e.code!=='ENOENT')throw e;}
 try{await fs.access(root+'/STOP');throw Error('Owned runner pause requested');}catch(e){if(e.code!=='ENOENT')throw e;}
 const command={at:new Date().toISOString(),executable:process.execPath,args:['scripts/render-performance.mjs','compare','--baseline-root',root+'/baseline','--candidate-root',root+'/candidate-basis','--config',c.file,'--max-load','2048','--warmup','8000','--sample','25000','--pairs','3','--no-profile','--pixel-channel','0','--pixel-fraction','0','--startup-timeout','60000','--out',out]};steps.push(command);await fs.writeFile(root+'/basis-primary-commands.json',JSON.stringify(steps,null,2));
 await snapshot(out);const handle=await fs.open(out+'.log','w');command.exitCode=await new Promise(resolve=>spawn(process.execPath,command.args,{stdio:['ignore',handle.fd,handle.fd]}).on('exit',resolve));await handle.close();await fs.writeFile(root+'/basis-primary-commands.json',JSON.stringify(steps,null,2));if(command.exitCode)throw Error(out);console.log('DONE '+out);
}

await snapshot('complete');
