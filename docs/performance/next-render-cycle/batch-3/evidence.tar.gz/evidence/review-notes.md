# Batch 3 independent review record

This is the coordinator's compact record of the bounded read-only reviewer reports delivered in this task, not a new runtime test or a verbatim transcript. Reviewer: batch3_cache_review. No reviewer builds, GPU runs, edits or delegation overlapped primary measurements.

- Core dependency/lifetime review: no actionable material correctness finding within the inspected cache, stream/content generation and per-view ownership changes. Runtime acceptance remained separate.
- Reduced basis predicate: inspected actual implementation and independent literal-legacy tests, including IEEE cases; no actionable equivalence gap found.
- Canonical Uniform refinement: inspected removal of the duplicate 112-byte draw record and actual dirty compact/full packing paths; no material finding.
- Final admission: inspected current-visible eligible-item weighting, minimum changed-root guard, visible/offscreen-heavy and small-fleet independent-reference tests; no material finding within this scope.
- Evidence audit: found a misleading metric name. The numerator contained fine-path record writes while the denominator contained ALL submitted glTF instances (including exact hits, other passes and fallbacks). Coordinator corrected it to fineRecordsWrittenPerAllSubmittedInstances with an explicit frame-wide-normalization scope; it is NOT a within-fine rebuild fraction. Group rebuilt fractions also explicitly mean any partial/full refresh attempted, not wholesale group copying. Reviewer checked a completed small report/raw schema and the audit math/provenance handling; no other material finding was reported. Final full audit execution is separate evidence.

These are scoped review results, not proof that every possible renderer state is correct or optimal.

## Additional pixel-evidence review

Primary WebGPU all-moving1024 has two strict failures: four pixels differ by1LSB; the other40 deterministic pairs are exact. Read-only reviewer inspected final-pose control and found no concrete new grouping/packing defect, but identified that primary phase boundaries precede final screenshot capture. The additional oracle therefore records phase state before/after every actual capture and enforces elapsedSeconds=.375.

Additional3pages/package, four captures/page show baseline temporal instability (one same-page repeat:14pixels,max63). Every candidate image SHA is one of the two variants already present among primary baseline captures. Candidate independent cache-off/culling-off comparison is exact2/3, with one4pixel/1LSB mismatch. Reviewer accepts reporting demonstrated baseline repeat instability, but rejects universal exact parity or attribution to GPU noise. Shared output sets do not exclude changed frequency or a shared older cache bug. Exact repeatability remains unresolved. Both primary FAIL results and the independent mismatch remain FAIL, no reference/tolerance edits. This is a known acceptance limit, not a test PASS.

The standalone diagnostic completed24images and closed all owned browsers/servers; its Node process retained library timers and was terminated by verified exact PID/command after output completion. Foreign GPU processes remained running. Cleanup record is separate from pixel status. A candidate-self command using original baseline calibration was correctly rejected by runtime-hash validation before launch; its failure log is retained. No original calibration or timing data was rewritten.

## Final reporting review

Reviewer sampled primary camera/mixed callback/FPS/tail/memory rows and checked CPU/GPU/API/worker scope language and the unresolved strict-pixel disclosures. Found one material contradiction: prose claimed all warm resource creation was zero, while all-moving candidate API rows show0.870WG/0.957GL createBuffer per engine frame. Coordinator limited the zero-allocation statement to static/camera/one-root windows and explicitly retained dynamic churn. Reviewer found no other actionable reporting defect within the sampled scope. This is source/data reading, not a new GPU run or whole-archive audit.
