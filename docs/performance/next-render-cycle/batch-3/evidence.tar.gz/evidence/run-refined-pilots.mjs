import fs from 'node:fs/promises';
import {spawn} from 'node:child_process';
const base='output/next-render-cycle-3',steps=[];
async function run(args,out){const command={at:new Date().toISOString(),executable:process.execPath,args:['scripts/render-performance.mjs',...args,'--out',out]};steps.push(command);await fs.writeFile(base+'/refined-pilot-commands.json',JSON.stringify(steps,null,2));const log=await fs.open(out+'.log','w');command.exitCode=await new Promise(resolve=>spawn(process.execPath,command.args,{stdio:['ignore',log.fd,log.fd]}).on('exit',resolve));await log.close();await fs.writeFile(base+'/refined-pilot-commands.json',JSON.stringify(steps,null,2));if(command.exitCode)throw Error(out);console.log('DONE '+out);}
for(const [family,load] of [['rim-camera-stress',2048],['rim-mixed',1024],['rim-clustered',1024],['rim-camera',1],['rim-clustered',16]])for(const backend of ['webgpu','webgl']){
 const id=family+'-'+load+'-'+backend,config=base+'/refined-cal-'+id;
 const common=['--baseline-root',base+'/baseline','--family',family,'--load',String(load),'--max-load','2048','--backend',backend,'--width','1280','--height','720','--warmup','1000','--sample','2500','--no-profile','--startup-timeout','60000'];
 await run(['calibrate',...common],config);
 await run(['compare',...common,'--candidate-root',base+'/candidate','--config',config+'/config.json','--pairs','1','--pixel-channel','0','--pixel-fraction','0'],base+'/refined-pilot-'+id);
}
