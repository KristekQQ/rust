import json,hashlib,gzip,math,statistics
from pathlib import Path
root=Path('output/next-render-cycle-3')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results={'scope':'separate diagnostic pages and actual worker publication replays, not clean primary throughput','diagnostics':[],'workers':[]}
expected={label:read(root/folder/'render-build.json')['build']for label,folder in [('baseline','baseline'),('candidate','candidate-admission')]}
checked={}
def check_file(p,digest):
 key=str(p)
 if key not in checked:checked[key]=sha(p)
 assert checked[key]==digest,key
for family,load in [('rim-stress',2048),('rim-camera-stress',2048),('rim-mixed',1024),('rim-clustered',1024)]:
 for backend in ['webgpu','webgl']:
  for label in ['baseline','candidate']:
   p=root/f'diag-{family}-{load}-{backend}-{label}';r=read(p/'report.json');assert not r.get('error'),p
   assert len(r['results'])==1 and all(c['complete']for c in r['cleanup'])
   assert r['baselineBuildFingerprint']==expected[label]
   x=r['results'][0];assert x['profiling'] is True and x['backend']==('Gl'if backend=='webgl'else'BrowserWebGpu')
   assert r['settings']['warmup']==4000 and r['settings']['sample']==10000
   assert not r['driverInputsChangedDuringRun']
   d=json.loads(gzip.decompress((p/'raw.json.gz').read_bytes()))[0];assert not d['abort']
   assert d['boundaryStart']['profile']['enabled'] and d['boundaryEnd']['profile']['enabled']
   for sample in d['gpu']:
    assert sample['sampleFrame']>d['boundaryStart']['profile']['frame']
    assert 0<=sample['ageFrames']<=max(128,(sample.get('sampleEveryFrames')or 16)*4)
    assert all(math.isfinite(v)and v>=0 for v in sample['passesMs'].values())
   if backend=='webgl':assert x['glRafGpuMs'] is None or x['glRafGpuMs']['count']>0
   a=x['apiOperations'];assert a['separateInstrumentedPage']and not a['runtimeLosses']
   assert not a['counters']['errors']and not a['warm']['end']['counters']['errors']
   count=a['warm']['engineFrames'];assert count>0
   first=a['warm']['start']['counters'][backend];last=a['warm']['end']['counters'][backend]
   calls={k:{'delta':v-first[k],'perEngineFrame':(v-first[k])/count}for k,v in last.items()if type(v)in(int,float)and type(first.get(k))in(int,float)}
   submitted={k:{'delta':last['submitted'][k]-first['submitted'][k],'perEngineFrame':(last['submitted'][k]-first['submitted'][k])/count}for k in ['drawCalls','instances','primitives','triangles','lines','points']}
   complete=first['submitted']['complete']and last['submitted']['complete']
   phases={name:x['work']['gltf']['prepareStageMs.'+name]['perApplicationRaf']for name in ['eligible','groups','basis','payload','records','resources']}
   for e in read(p/'manifest-baseline.json'):
    folder=Path('.')if e['source']=='harness'else root/('baseline'if label=='baseline'else'candidate-admission');check_file(folder/e['url'].lstrip('/'),e['sha256'])
   results['diagnostics'].append({'family':family,'load':load,'backend':backend,'packageLabel':label,'report':str(p/'report.json'),'runtimeBuild':r['baselineBuildFingerprint'],'prepareStageMsPerRaf':phases,'prepareStageTotalMsPerRaf':sum(phases.values()),'timedPrepareCallsPerRaf':x['work']['gltf']['prepareTimedCalls']['perApplicationRaf'],'gpuPassMs':x['gpuPassMs'],'gpuFreshSamples':x['gpuSamples'],'glWholeRafGpuMs':x['glRafGpuMs'],'gpuScope':'WebGPU native individual pass timestamps; GL whole RAF query interval; different scopes, never added to CPU wall time','cpuScopeEvidence':x['cpuScopeEvidence'],'api':{'coldInitializationPlus1s':a['counters'][backend],'warm':{'engineFrames':count,'elapsedMs':a['warm']['elapsedMs'],'calls':calls,'submitted':submitted,'primitiveProofComplete':complete,'exactTriangleEvents':submitted['triangles']if complete else None,'incompleteReasons':last['submitted']['incompleteReasons'],'indexShadowEnd':last.get('indexShadow'),'scope':'API-only separate3s warm window after4s; incomplete primitive totals are not exact; native glTF counts remain independently available'}}})
for stress in [0,1024]:
 for backend in ['webgpu','webgl']:
  for label in ['baseline','candidate']:
   p=Path(f'output/review-optimization/b3-final-{label}-{backend}-{stress}-cuts/report.json');r=read(p);assert r['status']=='PASS'and len(r['runs'])==3,p
   assert r['hashes']['webgpu_wasm_bg.wasm']==expected[label]['wasm']and r['hashes']['webgpu_wasm.js']==expected[label]['bindings']
   assert all(x['status']=='PASS'and x['backend']==('Gl'if backend=='webgl'else'BrowserWebGpu')and x['evidence']['stressCount']==stress for x in r['runs'])
   for run in r['runs']:
    t=run['evidence']['transport'];assert t['errors']==0 and t['jobs']==6 and t['messages']==6 and t['inflight']==0
    assert len(run['evidence']['halfVisibility'])==2 and all(h['meshes']>0 and h['leftPixels']>0 and h['rightPixels']>0 for h in run['evidence']['halfVisibility'])
   for e in r['inputs']:assert e['stable'];check_file(Path(e['file']),e['sha256'])
   results['workers'].append({'packageLabel':label,'backend':backend,'stress':stress,'report':str(p),'runs':3,'status':r['status'],'actualStageEvents':[len(x['evidence']['stages'])for x in r['runs']],'actualWorkerJobs':[x['evidence']['transport']['jobs']for x in r['runs']],'halfVisibilityBothEyesVerified':True,'metrics':{k:{a:b for a,b in v.items()if a!='samples'}for k,v in r['summary'].items()},'scope':'three same-package simulated-XR replays per invocation, not alternating performance pairs; handler/prepare/installation/publication separate from RAF; worker-internal compute unavailable; no causal worker speedup claim'})
results['checks']={'diagnosticCaptures':len(results['diagnostics']),'actualWorkerReplays':sum(x['runs']for x in results['workers']),'workerStageEvents':sum(sum(x['actualStageEvents'])for x in results['workers']),'actualCompletedWorkerJobs':sum(sum(x['actualWorkerJobs'])for x in results['workers']),'extraRequestedFilesHashed':len(checked),'runtimeHashesAndBackends':True,'primaryTimingUnchanged':True}
(root/'extra-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results['checks']))
for x in results['diagnostics']:print(x['family'],x['backend'],x['packageLabel'],round(x['prepareStageTotalMsPerRaf'],3),{k:round(v,3)for k,v in x['prepareStageMsPerRaf'].items()},x['api']['warm']['primitiveProofComplete'])
