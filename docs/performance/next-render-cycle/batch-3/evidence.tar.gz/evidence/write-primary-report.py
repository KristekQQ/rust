import json,statistics
from pathlib import Path
r=json.loads(Path('output/next-render-cycle-3/audited-results.json').read_text());cases=r['cases']
name={'rim-stress':'Static Rome','rim-camera-stress':'Moving camera','rim-mixed':'One moving root','rim-clustered':'Moving clustered roots','rim-camera':'Ordinary camera','rim-active':'Native Rome gameplay','dynamic':'Cut/spawn/despawn','arena-active':'Native Neon arena'}
text='''# Batch 3 — fine invalidation during camera/model motion

Implementation and clean timing are complete; final diagnostic/worker verification is in progress. Only batch 3 is authorized. No push, main merge, deployment or shared8443 restart. Parent checkpoint: `1afcd015787a3bff3fb58afd54126a6c7728a512`; isolated `codex/next-render-cycle-3`.

**Known acceptance limit:** the strict primary pixel gate is **40/42 exact, 2 FAIL** in WebGPU fully-moving1024. Those failures remain FAIL. Additional fixed-pose captures demonstrate temporal instability in the unchanged baseline, and every candidate image is a variant already observed in primary baseline. This does not prove universal parity, unchanged frequency, GPU causation or absence of a shared older bug. Exact repeatability of that stress case remains unresolved. No tolerance, reference image or quality setting was changed.

## Change and dependency boundaries

[Design](DESIGN.md) describes the implemented separation: bounded immutable compatibility tokens; per-model/draw data and basis revisions over existing canonical Uniforms; fresh original root/primitive visibility, depth grouping and order barriers for every changed view. A moving root no longer globally clears static plans. Matching groups retain prepared rows and patch changed16B/112B records. Actual content epochs and storage generations protect pass/eye ownership. Transparent objects use their original ordered path. No camera rounding, cached image, simulation stop or content reduction.

The existing stream reserves power-of-two bytes per group index to avoid downstream offset ripple. Current live binding widths remain exact. This can increase retained capacity and union upload spans. Fixed64fine slots and16MiB accounted element storage remain separate from the exact cache's16MiB. Neither is a whole-process/GPU memory bound.

Measured fallback uses the original builder for views without instancing, or when >=8changed current contributing roots own >=75%of >=512currently selected items. A single heavy visible/offscreen root cannot trigger it. Conservative pose publications may cause unnecessary fallback. This simple policy is not universal tuning. Original preparation work remains counted when fine counters are zero.

## Frozen identity and protocol

Baseline is the completed batch2 release, not batch1 or unoptimized main: source `1452a9f7ca544a1490773130f92719d223511b5feaa6c5b819bd3a9d325a0358`, WASM `af2905cc7d71af63b731c586198bd201917d63375821e80d1a70e7a99f1ea088`.

Final candidate: source `e8b39fcf650592b36a9e5897e8c4f9e85f131ab4782307ff36f5657dedfcd2dd`, WASM `bdae44e11cd107177241ec19de3d44137399603cb42f2f5de2dc4513a1c553ea`. SDK and generated bindings are unchanged; full hashes/configuration are in [manifest](MANIFEST.json).

AppleM1,8CPU/7GPU cores,16GB; Chrome156.0.8078.48; bundled arm64Node24.22.1; pinned Rust1.99. Foreign GPU processes were preserved. Environment snapshots show contention; aggregate AGX utilization cannot be attributed to a process or interpreted as isolated capacity.

Primary:1280×720,DPR1,seed1337, unchanged effects/content;8s warmup/25s sample,3AB/BA/AB pairs independently per backend. Baseline-only bounded calibration extended static/camera stress to2048 actual drones after1024 reached60Hz. Mixed/all-moving stress remains1024, small moving16; ordinary/native/cut64/Neon controls remain. No busy-wait or synthetic delay. Engine profiling, native preparation clocks and GL timing queries are verified OFF in every primary run. No owned build or second GPU runner overlapped clean measurement.

108 runs retain131,673 full frame records. Every RAF/callback mean, median,p95,p99,max was independently recomputed; all requested-file/build/config hashes, cleanup and common driver identity were rechecked. Callback wall time includes driver waits and measurement callbacks, excludes separate worker/timer handlers, and is not pure CPU computation. Primary GPU times are unavailable by design; separate diagnostic timestamps are not added to CPU wall time. No fresh Three.js or physical Quest comparison was performed.

## Paired primary results

Values below are medians of three per-run callback means and medians of `1000 / mean RAF interval`. FPS describes observed browser cadence, not compositor/headset presentation. Full individual runs, paired median ratios and all tails are in [results](RESULTS.json). Small/capped differences under contention are not proven speedups.

| Workload / load | Backend | Callback wall ms B→C | Mean-cadence FPS B→C |
|---|---|---:|---:|
'''
for c in cases:
 a,b=c['baseline'],c['candidate'];text+=f"| {name[c['family']]} / {c['load']} | {c['backend']} | {a['rafCallbackCpu']['medianOfRunMeans']:.3f} → {b['rafCallbackCpu']['medianOfRunMeans']:.3f} | {a['cadenceMeanFPSMedian']:.2f} → {b['cadenceMeanFPSMedian']:.2f} |\n"
text+='''
Camera and sparse movement show lower CPU wall time; the fully-moving and static controls are approximately neutral. Static exact-plan gains belong to batch2 and are not claimed again. Ordinary camera callback medians are slightly adverse (+.049ms WG,+.057ms GL) while cadence remains60Hz; retain these results. This batch does not reduce glTF draw commands or establish general active-game/VR superiority.

## Work actually retained or rebuilt

Per-RAF medians. Prepared-row percentages cover fine-admitted groups only. Payload-refresh percentages cover instanced fine groups and mean **any partial/full refresh attempted**, not wholesale group copying. Fallback work is separately recorded. CPU copied records/bytes are actual differing record writes. A frame-wide writes/submitted-instance ratio in JSON is explicitly not a within-fine rebuild fraction.

| Workload | Backend | Prepared rows reused | Payload groups refreshed | CPU records / bytes copied | Actual instance GPU upload B |
|---|---|---:|---:|---:|---:|
'''
for c in cases:
 if c['family']not in ['rim-camera-stress','rim-mixed']:continue
 x=c['candidate'];f=x['fineFractionsRuns'];w=x['workPerRaf'];text+=f"| {name[c['family']]} | {c['backend']} | {statistics.median(v['preparedRowsReused']for v in f)*100:.2f}% | {statistics.median(v['payloadGroupsRebuilt']for v in f)*100:.2f}% | {w['finePayloadRecordsWritten']:.1f} / {w['finePayloadBytesWritten']:.0f} | {w['instanceUploadBytes']:.0f} |\n"
text+='''
One moving root retains240/240prepared rows and copies67records/1,072B, but its one union upload still spans540,688B. Fresh camera culling/depth/group selection still runs; row reuse is not zero grouping work. Material/representation/layout changes legitimately rebuild affected rows. No universal zero-copy/upload claim is made.

## Long-series tails and retained memory

For the four target cases, p95/p99 are medians of per-run quantiles; max is the worst observed sample across all three runs. These are full25s series, not60sample profiler windows. Every other case's tails remain in JSON.

| Workload/backend | Package | Callback p95 / p99 / max ms | RAF interval p95 / p99 / max ms |
|---|---|---:|---:|
'''
for c in cases:
 if c['family']not in ['rim-camera-stress','rim-mixed']:continue
 for label in ['baseline','candidate']:
  parts=[]
  for metric in ['rafCallbackCpu','rafInterval']:
   a=c[label][metric]['runs'];parts.append(f"{statistics.median(x['p95']for x in a):.2f} / {statistics.median(x['p99']for x in a):.2f} / {max(x['max']for x in a):.2f}")
  text+=f"| {name[c['family']]}/{c['backend']} | {label} | {parts[0]} | {parts[1]} |\n"
text+='''
Memory below is the maximum of observed debug snapshots across the three runs, not a continuously observed whole-process/GPU peak. Element accounting excludes allocator/Rc/class maps/model Uniforms and existing mirror/resource ownership. Both16MiBcache budgets passed every sampled boundary/snapshot check.

| Workload/backend | Package | Fine elements MiB | Instance-buffer gauge MiB | Active / reserved layout MiB |
|---|---|---:|---:|---:|
'''
for c in cases:
 if c['family']not in ['rim-camera-stress','rim-mixed']:continue
 for label in ['baseline','candidate']:
  def peak(key):
   a=[v[key]['max']for v in c[label]['sampledMemoryRangesRuns']if v.get(key)]
   return f'{max(a)/1048576:.3f}'if a else 'unavailable'
  text+=f"| {name[c['family']]}/{c['backend']} | {label} | {peak('fineCacheBytes')} | {peak('instanceBufferBytes')} | {peak('fineLayoutActiveBytes')} / {peak('fineLayoutReservedBytes')} |\n"
text+='''
## Correctness, diagnostics and completion

Final evidence is being assembled. Maintained exact cache-off/culling-off motion tests cover camera, individual root/pose/material changes, multiple assets, edge crossings, clustering/spawn/removal, nonuniform/negative scale and16B↔112B, transparent/order barriers and lifecycle. Actual stereo attachments test small/large left-only changes and head motion independently. Visible/offscreen4096-node updates preserve unrelated static rows; small-fleet admission proves actual original-builder work. These deterministic acceptance scenarios are distinct from the unresolved crowded WebGPU repeatability case described above.

Pending: separate phase/GPU/API/worker summary, final project gate, archive verification and owned local checkpoint. Stop before batch4.
'''
Path('docs/performance/next-render-cycle/batch-3/REPORT.md').write_text(text)
