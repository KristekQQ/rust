import fs from 'node:fs/promises';import {spawn} from 'node:child_process';
const root='output/next-render-cycle-3';let ready=false;
for(let n=0;n<240;n++){const log=await fs.readFile(root+'/primary-progress.log','utf8');if(log.includes('User stop file present')){ready=true;break;}await new Promise(r=>setTimeout(r,2000));}
if(!ready)throw Error('Owned runner pause did not complete in8min');
const report=JSON.parse(await fs.readFile(root+'/primary-rim-stress-2048-webgl/report.json'));if(report.results.length!==6||report.error||!report.cleanup.every(x=>x.complete))throw Error('Previous case not cleanly complete');
console.log('Owned series paused after complete case; strict WASM lint starts');
const log=await fs.open(root+'/strict-wasm-lint.log','w');const code=await new Promise(r=>spawn('cargo',['clippy','--locked','--target','wasm32-unknown-unknown','--','-D','warnings'],{env:{...process.env,RUSTFLAGS:'--cfg=web_sys_unstable_apis'},stdio:['ignore',log.fd,log.fd]}).on('exit',r));await log.close();await fs.writeFile(root+'/strict-wasm-lint-status.json',JSON.stringify({at:new Date().toISOString(),exitCode:code,command:'RUSTFLAGS=--cfg=web_sys_unstable_apis cargo clippy --locked --target wasm32-unknown-unknown -- -D warnings'}));
if(code)throw Error('Strict WASM lint failed; preserved pause');
await fs.unlink(root+'/STOP');console.log('Strict WASM lint PASS; resume identical frozen pairs');
const out=await fs.open(root+'/resumed-primary-progress.log','w');const result=await new Promise(r=>spawn(process.execPath,[root+'/resume-primary.mjs'],{stdio:['ignore',out.fd,out.fd]}).on('exit',r));await out.close();if(result)throw Error('Resumed series failed');console.log('Primary series complete');
