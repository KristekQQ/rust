from pathlib import Path
import json,hashlib,tarfile,io,os
root=Path('output/next-render-cycle-3');target=Path('docs/performance/next-render-cycle/batch-3/evidence.tar.gz')
exclude={'processes-before-pilots.txt','STOP'};frozen={'baseline','candidate-first','candidate','candidate-final','candidate-basis','candidate-uniform','candidate-admission'}
entries={}
def add(src,name):
 if src.is_file() and not src.is_symlink():entries['evidence/'+name]=src
for p in root.rglob('*'):
 rel=p.relative_to(root)
 if rel.parts[0] in frozen or rel.name in exclude or not p.is_file():continue
 add(p,str(rel))
baseline=json.loads((root/'baseline/render-build.json').read_text())['files']
for name in sorted(frozen):
 folder=root/name;manifest=json.loads((folder/'render-build.json').read_text());add(folder/'render-build.json',name+'/render-build.json')
 for rel,e in manifest['files'].items():
  if rel.startswith('pkg/') or (name!='baseline' and baseline.get(rel,{}).get('sha256')!=e['sha256']):add(folder/rel,name+'/'+rel)
for folder in Path('output/review-optimization').glob('b3-final-*-cuts'):
 for p in folder.rglob('*'):
  if p.is_file():add(p,'workers/'+folder.name+'/'+str(p.relative_to(folder)))
for p in Path('output/verification').rglob('*'):
 if p.is_file():add(p,'final-verification/'+str(p.relative_to('output/verification')))
records=[];seen={};target.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(target,'w:gz',compresslevel=9) as tar:
 for name,src in sorted(entries.items()):
  data=src.read_bytes();digest=hashlib.sha256(data).hexdigest();records.append({'path':name,'sha256':digest,'bytes':len(data)})
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0
  if digest in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[digest];tar.addfile(info)
  else:info.size=len(data);tar.addfile(info,io.BytesIO(data));seen[digest]=name
 data=(json.dumps(records,indent=2)+'\n').encode();info=tarfile.TarInfo('evidence/FILES.json');info.mode=0o644;info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(target) as tar:
 for record in records:
  data=tar.extractfile(record['path']).read();assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],record['path']
summary={'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'files':len(records)+1,'uniquePayloads':len(seen)+1,'exactContentHardlinks':len(records)-len(seen),'uncompressedRecordedBytes':sum(r['bytes']for r in records),'allMembersAndHardlinkTargetsVerified':True,'excluded':'unchanged base repository/runtime assets; full unfiltered process list; frozen changed source/pkg bytes and full manifests retained'}
(root/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
