import fs from 'node:fs/promises';
import {spawn,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='output/next-render-cycle-3',steps=[],cases=[['rim-stress',2048],['rim-camera-stress',2048],['rim-mixed',1024],['rim-clustered',1024],['rim-clustered',16],['rim-camera',1],['rim-active',1],['dynamic',64],['arena-active',1]];
const sha=b=>createHash('sha256').update(b).digest('hex');
async function snapshot(label){const evidence={at:new Date().toISOString(),label};for(const [key,cmd,args] of [['gpuProcesses','ps',['-Ao','pid,ppid,%cpu,etime,command']],['power','pmset',['-g','batt']],['gpuUtilization','ioreg',['-r','-c','AGXAccelerator','-d','1']]]){try{let s=execFileSync(cmd,args,{encoding:'utf8',maxBuffer:8388608});if(key==='gpuProcesses')s=s.split('\n').filter(l=>l.includes('gpu-process')).map(l=>l.slice(0,300)).join('\n');if(key==='gpuUtilization')s=[...s.matchAll(/"(?:Device Utilization %|Renderer Utilization %|Tiler Utilization %|In use system memory)"\s*=\s*\d+/g)].map(m=>m[0]).join('\n')||'unavailable';evidence[key]=s;}catch(e){evidence[key]='unavailable: '+e.message;}}await fs.appendFile(root+'/primary-environment.jsonl',JSON.stringify(evidence)+'\n');}
async function run(args,out){try{await fs.access(root+'/STOP');throw Error('User stop file present');}catch(e){if(e.code!=='ENOENT')throw e;}
 const command={at:new Date().toISOString(),executable:process.execPath,args:['scripts/render-performance.mjs',...args,'--out',out]};steps.push(command);await fs.writeFile(root+'/primary-commands.json',JSON.stringify(steps,null,2));await snapshot(out);const handle=await fs.open(out+'.log','w');command.exitCode=await new Promise(resolve=>spawn(process.execPath,command.args,{stdio:['ignore',handle.fd,handle.fd]}).on('exit',resolve));await handle.close();await fs.writeFile(root+'/primary-commands.json',JSON.stringify(steps,null,2));if(command.exitCode)throw Error('Failed '+out);console.log('DONE '+out);}
const configs=[];
for(const [i,[family,load]] of cases.entries())for(const backend of i%2?['webgl','webgpu']:['webgpu','webgl']){
 const id=family+'-'+load+'-'+backend,dir=root+'/cal-'+id;
 await run(['calibrate','--baseline-root',root+'/baseline','--family',family,'--load',String(load),'--max-load','2048','--backend',backend,'--width','1280','--height','720','--warmup','1000','--sample','2500','--no-profile','--startup-timeout','60000'],dir);
 configs.push({family,load,backend,file:dir+'/config.json',sha256:sha(await fs.readFile(dir+'/config.json'))});
}
await fs.writeFile(root+'/PRIMARY-CONFIGS.json',JSON.stringify({at:new Date().toISOString(),scope:'frozen before all primary pairs; baseline-only bounded explicit-load probes',cases:configs,protocol:{warmupMs:8000,sampleMs:25000,pairs:3,order:'AB/BA/AB',width:1280,height:720,DPR:1,profiling:false}},null,2));
for(const c of configs)await run(['compare','--baseline-root',root+'/baseline','--candidate-root',root+'/candidate','--config',c.file,'--max-load','2048','--warmup','8000','--sample','25000','--pairs','3','--no-profile','--pixel-channel','0','--pixel-fraction','0','--startup-timeout','60000'],root+'/primary-'+c.family+'-'+c.load+'-'+c.backend);
await snapshot('complete');
