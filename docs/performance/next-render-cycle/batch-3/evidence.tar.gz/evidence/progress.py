import json,glob,os,statistics
ps=glob.glob('output/next-render-cycle-3/primary-admission-*/report.json');done=0;active=[]
for p in sorted(ps):
 r=json.load(open(p));n=len(r['results']);complete=n==6 and bool(r.get('cleanup')) and all(x['complete'] for x in r['cleanup']);done+=6 if complete else n
 if not complete:active.append((p.split('/')[-2],n))
print('Primary completed runs',done,'/108; active',active)
for p in ps:
 if 'rim-clustered-1024' not in p:continue
 r=json.load(open(p))
 if len(r['results'])==6:
  print(p.split('/')[-2],[(l,round(statistics.median([x['rafCallbackCpu']['mean']for x in r['results']if x['label']==l]),3))for l in ['baseline','candidate']])
