import json,gzip,hashlib,math,statistics
from pathlib import Path
root=Path('output/next-render-cycle-3')
load=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stats(a):
 a=sorted(a);return {'count':len(a),'mean':statistics.mean(a),'median':a[math.ceil(len(a)*.5)-1],'p95':a[math.ceil(len(a)*.95)-1],'p99':a[math.ceil(len(a)*.99)-1],'max':a[-1]}
def close(a,b):return abs(a-b)<=1e-8*max(1,abs(a),abs(b))
def med(a):return statistics.median(a)
configs=load(root/'PRIMARY-CONFIGS.json');rows=[];browsers=set();harnesses=set();audit={'version':1,'primaryRuns':0,'frameRecords':0,'errors':[],'checks':{},'cases':[]}
for c in configs['cases']:
 path=root/f"primary-admission-{c['family']}-{c['load']}-{c['backend']}";r=load(path/'report.json')
 assert not r.get('error'),(path,r.get('error'))
 assert r['candidateBuildFingerprint']==load(root/'candidate-admission/render-build.json')['build']
 assert r['baselineBuildFingerprint']==load(root/'baseline/render-build.json')['build']
 browsers.add(r['browser']);harnesses.add(r['driverIdentity']['sha256'])
 assert len(r['results'])==6,path
 assert all(x['complete'] for x in r['cleanup'])
 assert not r['driverInputsChangedDuringRun']
 assert r['settings']['warmup']==8000 and r['settings']['sample']==25000 and r['settings']['profiling'] is False
 assert sha(c['file'])==c['sha256']
 raw=json.loads(gzip.decompress((path/'raw.json.gz').read_bytes()));assert len(raw)==6
 byid={x['id']:x for x in raw}
 for x in r['results']:
  d=byid[x['id']];assert d['profiling'] is False and not d['abort']
  assert d['backend']==('Gl' if c['backend']=='webgl' else 'BrowserWebGpu')
  assert d['boundaryStart']['profile']['enabled'] is False and d['boundaryEnd']['profile']['enabled'] is False
  assert d['glRafGpu'] is None or not (d['glRafGpu']['enabled'] or d['glRafGpu']['queriesBegun'])
  assert len(d['gpu'])==0
  for kind,values in [('rafInterval',[b['stamp']-a['stamp'] for a,b in zip(d['frames'],d['frames'][1:])]),('rafCallbackCpu',[v['cpu'] for v in d['frames']])]:
   actual=stats(values)
   for k,v in actual.items():assert close(v,x[kind][k]),(path,x['id'],kind,k,v,x[kind][k])
  audit['frameRecords']+=len(d['frames']);audit['primaryRuns']+=1
  x['cadenceMeanFPS']=1000/x['rafInterval']['mean']
  def event(k):return x['work']['gltf'][k]['perApplicationRaf']
  x['derivedWorkPerRaf']={k:event(k) for k in ['drawCalls','instancedDrawCalls','instancesDrawn','trianglesDrawn','bufferUploadCalls','instanceUploadBytes','uniformUploadBytes','instancePagesCreated','instanceBuffersCreated','instanceBindGroupsCreated','prepareGroupRebuilds','preparePayloadRebuilds','prepareRecordRebuilds','fineGroupsVisited','fineGroupMembershipHits','finePreparedRowsReused','finePreparedRowsCreated','finePayloadGroupsRebuilt','finePayloadGroupsReused','finePayloadRecordsWritten','finePayloadBytesWritten','fineWorldDataUpdates','fineFullRecordPacks','fineBasisComparisons','fineCompatibilityHits','fineDynamicFallbacks','fineNoInstanceFallbacks','fineCacheBudgetFallbacks']}
  assert event('prepareTimedCalls')==0
  assert x['actualQualityState']['canvas']=={'width':1280,'height':720}
  assert x['metadata']['seed']==1337 and x['metadata']['load']==c['load']
  groups=event('fineGroupsVisited');pr=event('finePayloadGroupsRebuilt');pu=event('finePayloadGroupsReused')
  x['fineFractions']={'preparedRowsReused':event('finePreparedRowsReused')/groups if groups else None,'membershipsRetained':event('fineGroupMembershipHits')/groups if groups else None,'payloadGroupsRebuilt':pr/(pr+pu) if pr is not None and pr+pu else None,'fineRecordsWrittenPerAllSubmittedInstances':event('finePayloadRecordsWritten')/event('instancesDrawn') if groups and event('instancesDrawn') else None,'scope':'group fractions cover fine-admitted views only; payloadGroupsRebuilt means any partial/full source or layout refresh attempted, not wholesale group copying; fallback/original builder work is separately visible in preparePayloadRebuilds/prepareRecordRebuilds','recordRatioScope':'fine-only CPU payload record writes divided by ALL submitted glTF instance events across exact hits, fallbacks and passes; frame-wide normalization, NOT a within-fine rebuild fraction'}
  x['accountedMemory']={k:x['debug']['gltf'].get(k) for k in ['fineCacheBytes','fineLayoutActiveBytes','fineLayoutReservedBytes','instanceBufferBytes','queueScratchBytes']};x['accountedMemory']['exactPlanBytes']=x['debug']['gltf']['preparedPlanCache']['retainedBytes']
  if x['label']=='candidate':assert x['accountedMemory']['fineCacheBytes']<=16777216 and x['accountedMemory']['exactPlanBytes']<=16777216
  snapshots=[d['boundaryStart']['debug']['gltf'],d['boundaryEnd']['debug']['gltf']]+[q['debug']['gltf'] for q in d['samples']]
  x['sampledMemoryRanges']={}
  for k in ['fineCacheBytes','fineLayoutActiveBytes','fineLayoutReservedBytes','instanceBufferBytes','queueScratchBytes']:
   values=[q.get(k) for q in snapshots if isinstance(q.get(k),(int,float))]
   x['sampledMemoryRanges'][k]={'min':min(values),'max':max(values),'samples':len(values)} if values else None
  exact=[q['preparedPlanCache']['retainedBytes']for q in snapshots]
  x['sampledMemoryRanges']['exactPlanBytes']={'min':min(exact),'max':max(exact),'samples':len(exact)}
  if x['label']=='candidate':assert x['sampledMemoryRanges']['fineCacheBytes']['max']<=16777216 and max(exact)<=16777216
  x['sampledMemoryRangeScope']='observed debug snapshots only; element-storage accounting excludes allocator/class-map/model/whole-process/GPU memory'
  assert sha(path/x['capture']['file'])==x['capture']['sha256']
  rows.append({'case':c['family'],'load':c['load'],'backend':c['backend'],'directory':str(path),**x})
 functional=c['family'] in ['rim-active','arena-active']
 assert all(p['pixel']['pass'] is None if functional else p['pixel']['exact'] is True for co in r['comparisons'] for p in co['paired'])
 a=[x for x in rows if x['directory']==str(path) and x['label']=='baseline'];b=[x for x in rows if x['directory']==str(path) and x['label']=='candidate']
 entry={'family':c['family'],'load':c['load'],'backend':c['backend'],'report':str(path/'report.json'),'profilerOff':True,'pixelExact':None if functional else True,'functionalPixelLimit':'active native simulation has independent functional acceptance; no deterministic final state pixel parity' if functional else None,'baseline':{},'candidate':{},'paired':r['comparisons']}
 for label,group in [('baseline',a),('candidate',b)]:
  for metric in ['rafCallbackCpu','rafInterval']:
   entry[label][metric]={'medianOfRunMeans':med([x[metric]['mean'] for x in group]),'medianOfRunMedians':med([x[metric]['median'] for x in group]),'runs':[{k:x[metric][k] for k in ['count','mean','median','p95','p99','max']} for x in group]}
  entry[label]['cadenceMeanFPSMedian']=med([x['cadenceMeanFPS'] for x in group])
  entry[label]['workPerRaf']={k:med([x['derivedWorkPerRaf'][k] for x in group]) if all(x['derivedWorkPerRaf'][k] is not None for x in group) else None for k in group[0]['derivedWorkPerRaf']}
  entry[label]['memoryRuns']=[x['accountedMemory'] for x in group];entry[label]['fineFractionsRuns']=[x['fineFractions'] for x in group]
  entry[label]['sampledMemoryRangesRuns']=[x['sampledMemoryRanges']for x in group]
  entry[label]['gpuTime']=None
 entry['callbackMeanRatio']=entry['candidate']['rafCallbackCpu']['medianOfRunMeans']/entry['baseline']['rafCallbackCpu']['medianOfRunMeans']
 entry['cadenceRatio']=entry['candidate']['cadenceMeanFPSMedian']/entry['baseline']['cadenceMeanFPSMedian']
 audit['cases'].append(entry)
assert audit['primaryRuns']==108
assert len(browsers)==1 and len(harnesses)==1,(browsers,harnesses)
audit['checks']['browserVersions']=sorted(browsers);audit['checks']['commonHarnesses']=sorted(harnesses)
# Verify every actually served resource against its frozen/runtime or common harness source.
checked={}
for c in configs['cases']:
 p=root/f"primary-admission-{c['family']}-{c['load']}-{c['backend']}"
 for label in ['baseline','candidate']:
  for e in load(p/f'manifest-{label}.json'):
   source=Path('.') if e['source']=='harness' else root/('candidate-admission' if label=='candidate' else 'baseline')
   file=source/e['url'].lstrip('/');key=str(file)
   checked.setdefault(key,sha(file));assert checked[key]==e['sha256'],key
for name in ['baseline','candidate-first','candidate','candidate-final','candidate-basis','candidate-uniform','candidate-admission']:
 folder=root/name;m=load(folder/'render-build.json');assert m['complete']
 for rel,e in m['files'].items():assert sha(folder/rel)==e['sha256'],(name,rel)
 audit['checks'][name+'FrozenFiles']=len(m['files'])
audit['checks'].update({'allFrameTailsRecomputed':True,'servedFileHashes':len(checked),'profilingOffIncludingNativeScopesAndGLQueries':True,'fullPrimaryRawRuns':108,'fineRetentionBudgets':True,'fixedCalibrationHashes':True,'noDriverMutation':True})
(root/'audited-results.json').write_text(json.dumps(audit,indent=2)+'\n')
(root/'audited-run-details.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS',audit['primaryRuns'],'runs',audit['frameRecords'],'frame records',len(checked),'served files')
for r in audit['cases']:print(r['family'],r['load'],r['backend'],*[round(r[l]['rafCallbackCpu']['medianOfRunMeans'],3) for l in ['baseline','candidate']],*[round(r[l]['cadenceMeanFPSMedian'],2) for l in ['baseline','candidate']])
