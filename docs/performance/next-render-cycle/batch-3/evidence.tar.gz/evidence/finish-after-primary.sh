#!/usr/bin/env bash
set -euo pipefail
export PATH="/Users/Honza/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH"
export VERIFY_WASM_PROFILE=release
python3 output/next-render-cycle-3/audit-results.py > output/next-render-cycle-3/audit-results.log 2>&1
printf '%s\n' 'DONE primary evidence audit'
node output/next-render-cycle-3/run-diagnostics.mjs > output/next-render-cycle-3/diagnostics-progress.log 2>&1
printf '%s\n' 'DONE separate diagnostic captures'
node output/next-render-cycle-3/run-workers.mjs > output/next-render-cycle-3/workers-progress.log 2>&1
printf '%s\n' 'DONE actual worker replays'
npm run verify:push > output/next-render-cycle-3/final-verify-push.log 2>&1
printf '%s\n' 'DONE final verify:push'
