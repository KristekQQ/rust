import fs from 'node:fs/promises';import {spawn} from 'node:child_process';
const root='output/next-render-cycle-3',commands=[];
for(const stress of [0,1024])for(const backend of ['webgpu','webgl'])for(const label of ['baseline','candidate']){
 const id='b3-final-'+label+'-'+backend+'-'+stress, runtime=root+'/'+(label==='candidate'?'candidate-admission':'baseline');
 const command={at:new Date().toISOString(),executable:process.execPath,args:['scripts/benchmark-rim-cuts.mjs',id,runtime+'/pkg',backend,String(stress)],output:'output/review-optimization/'+id+'-cuts/report.json'};commands.push(command);await fs.writeFile(root+'/worker-commands.json',JSON.stringify(commands,null,2));const h=await fs.open(root+'/'+id+'.log','w');command.exitCode=await new Promise(r=>spawn(process.execPath,command.args,{stdio:['ignore',h.fd,h.fd]}).on('exit',r));await h.close();await fs.writeFile(root+'/worker-commands.json',JSON.stringify(commands,null,2));if(command.exitCode)throw Error(id);console.log('DONE '+id);
}
