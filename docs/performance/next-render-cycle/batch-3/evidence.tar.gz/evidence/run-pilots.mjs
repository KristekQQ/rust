import fs from 'node:fs/promises';
import {spawn} from 'node:child_process';
const base='output/next-render-cycle-3',steps=[];
const run=async(args,out)=>{
 const command={at:new Date().toISOString(),executable:process.execPath,args:['scripts/render-performance.mjs',...args,'--out',out]};steps.push(command);await fs.writeFile(base+'/pilot-commands.json',JSON.stringify(steps,null,2));
 const handle=await fs.open(out+'.log','w');const code=await new Promise(resolve=>{const p=spawn(process.execPath,command.args,{stdio:['ignore',handle.fd,handle.fd],env:process.env});p.on('exit',resolve);});await handle.close();command.exitCode=code;await fs.writeFile(base+'/pilot-commands.json',JSON.stringify(steps,null,2));
 if(code!==0)throw Error('Failed '+out);console.log('DONE '+out);
};
for(const [family,load] of [['rim-camera-stress',1024],['rim-mixed',1024],['rim-clustered',1024],['rim-clustered',16],['rim-camera',1],['rim-stress',1024],['arena-active',1],['dynamic',64],['rim-active',1]])for(const backend of ['webgpu','webgl']){
 const id=family+'-'+load+'-'+backend,config=base+'/pilot-cal-'+id;
 const common=['--baseline-root',base+'/baseline','--family',family,'--load',String(load),'--max-load','2048','--backend',backend,'--width','1280','--height','720','--warmup','1000','--sample','2500','--no-profile','--startup-timeout','60000'];
 await run(['calibrate',...common],config);
 await run(['compare',...common,'--candidate-root',base+'/candidate-first','--config',config+'/config.json','--pairs','1','--pixel-channel','0','--pixel-fraction','0'],base+'/pilot-pair-'+id);
}
