from pathlib import Path
import json
x=json.loads(Path('output/next-render-cycle-3/extra-results.json').read_text());p=Path('docs/performance/next-render-cycle/batch-3/REPORT.md');s=p.read_text();s=s[:s.index('Pending: separate phase/GPU/API/worker summary')]
names={'rim-stress':'Static2048','rim-camera-stress':'Camera2048','rim-mixed':'One moving1024','rim-clustered':'All moving1024'}
s+='''
## Separate preparation/GPU/API diagnostics

16 captures, each4s warmup/10s profiled sample, plus a different instrumented API page with initialization+1s cold counters and a3s warm window after4s. They are exploratory unpaired diagnostics, not additional primary repetitions. Six exclusive native preparation phases are accumulated perRAF; all six and sparse CPU-history freshness are retained in JSON. Unchanged history is unproven freshness, not a zero measurement. These scopes are CPU wall time and are not added to primary/GPU values.

| Workload | Backend | Six-phase total B→C ms/RAF | Grouping B→C | Basis B→C | Payload B→C |
|---|---|---:|---:|---:|---:|
'''
for f in names:
 for backend in ['webgpu','webgl']:
  a,b=[next(v for v in x['diagnostics']if v['family']==f and v['backend']==backend and v['packageLabel']==l)for l in ['baseline','candidate']]
  vals=[f"{a['prepareStageTotalMsPerRaf']:.3f} → {b['prepareStageTotalMsPerRaf']:.3f}"]+[f"{a['prepareStageMsPerRaf'][k]:.3f} → {b['prepareStageMsPerRaf'][k]:.3f}"for k in ['groups','basis','payload']]
  s+=f"| {names[f]} | {backend} | "+' | '.join(vals)+' |\n'
s+='''
Camera selection remains about1.27–1.43ms/RAF and grouping4.35–4.65ms; basis/payload remain real work. Other large sparse observed CPU wall scopes are render.encode.overlays(~5.3ms) and scene.gpuUpdates(~2.3–2.8ms). Nested render.encode.color/gltf.queue scopes overlap these phases; do not sum them. Full-moving update/driver work remains expensive despite a cheaper queue phase.

Valid GPU intervals below are separate diagnostics. WebGPU is native `scene.main` pass timestamps; FXAA timestamps are separately retained. WebGL2 is an inclusive whole-RAF asynchronous query interval, potentially including queue/idle gaps, not the same scope or a pure draw-execution measurement. No cross-backend GPU winner or causal GPU improvement follows from this table; clean primary GPU time remains unavailable.

| Workload | GPU interval scope | Samples B→C | Mean B→C ms | p95 B→C ms |
|---|---|---:|---:|---:|
'''
for f in names:
 for backend in ['webgpu','webgl']:
  a,b=[next(v for v in x['diagnostics']if v['family']==f and v['backend']==backend and v['packageLabel']==l)for l in ['baseline','candidate']]
  a,b=[z['gpuPassMs']['scene.main']if backend=='webgpu'else z['glWholeRafGpuMs']for z in [a,b]]
  s+=f"| {names[f]} | {'WebGPU scene.main'if backend=='webgpu'else'WebGL2 whole RAF'} | {a['count']} → {b['count']} | {a['mean']:.3f} → {b['mean']:.3f} | {a['p95']:.3f} → {b['p95']:.3f} |\n"
s+='''
Whole-API instrumentation is separate from exact native glTF counters. Warm resource creation is zero in these steady workload windows; cold initialization+1s creates many per-draw resources and is not a pure startup duration. All API call counts, cold resources, uploads and warm submitted work remain in JSON. WebGL indexed primitive proof exceeds the existing8,192metadata bound under these stress loads; exact whole-API triangle totals stay unavailable. No bound inflation or invented total was used. Native glTF instances/triangles remain exact within their own scope.

| Candidate workload | Backend | Cold createBuffer calls | Warm createBuffer/frame | API draws/frame | Exact API primitive proof |
|---|---|---:|---:|---:|---|
'''
for z in x['diagnostics']:
 if z['packageLabel']!='candidate':continue
 a=z['api'];s+=f"| {names[z['family']]} | {z['backend']} | {a['coldInitializationPlus1s'].get('createBuffer','unavailable')} | {a['warm']['calls']['createBuffer']['perEngineFrame']:.3f} | {a['warm']['submitted']['drawCalls']['perEngineFrame']:.2f} | {a['warm']['primitiveProofComplete']} |\n"
s+='''
## Actual worker cuts and publication

24 maintained simulated-XR replays (three/package/backend at ordinary0 and stress1024),144completed real worker jobs,72installation-stage events. Every replay verified both separated halves with nonzero pixels in both actual eye attachments, then evaporation/lifecycle. This is simulated XR, not physical Quest acceptance. Runtime/source inputs and actual backend were rechecked. These grouped same-package repetitions are not alternating performance pairs; no causal worker-speedup claim is made.

The message-handler maximum, installation-stage p95, request-to-publication mean and worst death/cut RAF below cover different scopes. Publication runs from first nonempty rimTakeCutJob through the end of the first simulatedXRframe exposing complete uploaded pieces; it excludes GPU completion/compositor. Completion-from-kill includes observation delay. Worker-internal computation is unavailable. Native accept/prepare distributions and all frame events are retained separately. With only3replays/9stage samples per row, tail estimates are descriptive.

| Package/backend/load | Handler max ms | Install-stage p95 ms | Request→publish mean ms | Death/cut RAF max ms |
|---|---:|---:|---:|---:|
'''
for z in x['workers']:
 m=z['metrics'];s+=f"| {z['packageLabel']}/{z['backend']}/{z['stress']} | {m['workerHandlerMaxMs']['max']:.3f} | {m['stageMs']['p95']:.3f} | {m['requestToPublishMs']['mean']:.2f} | {m['deathAndCutFrameMs']['max']:.2f} |\n"
s+='''
Preserve ordinary WebGL candidate40.2ms worst death/cut frame versus baseline36.7ms, and stress WebGL49.8ms. These runs do not prove hitch-free VR or faster physics. Completed own Node CLIs retaining handles were cleaned only after final PASS/output and browser/server cleanup; verified PIDs, null signal exits and original coordinator are retained. This cleanup is not an extra performance test or a pixel PASS.

## Strict pixels and rejected experiments

The deterministic primary cases have40exact pairs and2strict FAIL (fully-moving1024WebGPU,4pixels/max1LSB). Native-gameplay final capture has no deterministic reset, so its12pairs deliberately have pixel acceptance unavailable rather than a false pass. Additional fixed.375pose before/after snapshots show baseline same-page repeat14pixels/max63. All candidate images are exactly one of the two image SHA variants already present in primary baseline; however one candidate independent cache-off/culling-off comparison and restoration comparisons still fail by the known4pixels/1LSB. This weakens attribution to a new cache defect but does not establish unchanged frequency or eliminate a shared older bug. Exact repeatability remains unresolved; do not describe every pixel test as passing. Original failures/captures and zero tolerance remain intact.

Rejected evidence is retained: tight offsets copied~87%of camera records despite~91%membership hits; global publication-count fallback let one offscreen heavy root discard unrelated reuse; contributing-model e57 regressed fully-moving callbacks~5%WG/~8%GL. A reduced basis proof alone left~2.9%GLoverhead. Removing duplicate112Bdraw data recovered large-motion neutrality, but e33still added.09–.14ms for16movingWGroots. Final eligible-item-weighted admission removes that observed small overhead in fresh pairs. A coordinator-path mistake loaded an older WASM; runtime-hash audit rejected/moved all six affected runs. No attempt was renamed as final, removed or mixed into final repetitions. [Journal](../EXPERIMENTS.md) and archive retain the unfavorable outcomes.

## Commands and final verification

Commands actually executed include the following; exact per-run arguments/timestamps and all failures are in the evidence archive. Scripts under output are evidence coordination around maintained tools, not a second benchmark framework.

```sh
RUSTFLAGS=--cfg=web_sys_unstable_apis wasm-pack build --target web --release -- --locked
VERIFY_WASM_PROFILE=release node scripts/build-fingerprint.mjs --write
EXPECTED_CANDIDATE_WASM=bdae44e11cd107177241ec19de3d44137399603cb42f2f5de2dc4513a1c553ea VERIFY_WASM_PROFILE=release node output/next-render-cycle-3/run-admission-primary.mjs
python3 output/next-render-cycle-3/audit-results.py
node output/next-render-cycle-3/run-diagnostics.mjs
node output/next-render-cycle-3/run-workers.mjs
python3 output/next-render-cycle-3/summarize-extra.py
VERIFY_WASM_PROFILE=release npm run verify:push
```

A representative clean invocation uses the existing render-performance.mjs compare command, frozen baseline/candidate roots, original calibrated --config, --max-load2048, --warmup8000 --sample25000 --pairs3 --no-profile --pixel-channel0 --pixel-fraction0. The pixel gate stays strict even where it fails. Additional same-package/pixel-oracle diagnostics are explicitly not primary performance data.

Final project gate, archive/member verification, matching receipt and local checkpoint are pending. Stop before batch4. Shared8443was not changed or re-audited; this candidate is not a headset deployment.
'''
p.write_text(s)
