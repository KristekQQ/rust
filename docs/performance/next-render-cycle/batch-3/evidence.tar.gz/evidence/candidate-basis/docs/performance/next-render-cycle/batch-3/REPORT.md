# Batch3 — fine invalidation during camera/model motion

Status: validation in progress. Only batch3; no push, main merge, deployment or shared8443 restart. Isolated `codex/next-render-cycle-3`, parent `1afcd015787a3bff3fb58afd54126a6c7728a512`.

## Implementation and dependency boundaries

A bounded per-uploaded-asset compatibility class proves the same immutable dependencies as the original comparison: primitive ordinal, asset/material/geometry ownership, mirror and render options. Only actual class changes re-intern. Unsupported/nonfinite keys retain original comparisons. The map is capped4096 entries/asset with weak ownership; no camera-key map.

Canonical world instance data and data/basis revisions belong to each GPU draw. Model updates no longer clear every plan. The exact batch2 cache validates individual model data revisions and remains the unchanged-input fast path. Fine metadata retains exact ordered draw identities, per-source data/basis revisions and prepared command rows in64 fixed view/pass slots. Accounted fine element storage has a16MiB total retention limit; the exact cache has its own16MiB limit. These are not total-process/GPU memory estimates. Model-owned records, allocator/Rc overhead, class-map metadata and existing CPU/GPU stream copies are separate.

Each moving view still executes fresh original root/primitive culling, depth grouping and order barriers. No previous visibility list is accepted merely because the camera moved a little. No matrix rounding, cached image, simulation stop or quality/content reduction was added. Matching groups reuse prepared rows; only changed payload records are patched in the pass/view CPU mirror. Resource generations, offsets, record formats, pipeline variants and membership guard reuse. Material uniforms still validate actual content before row reuse. Transparent objects retain their original ordered builder.

Power-of-two byte reservations in the existing per-view stream prevent small visibility/count changes from moving every later group. Actual bindings use current live bytes. Layout changes/growth still require affected offsets to refresh. Empty reserved slots survive2→1→2 while other instanced groups remain. The existing16MiB stream admission includes padding; fallback pages remain supported. Reservation can increase buffer capacity and union upload spans; this is measured, not described as free memory or GPU upload reduction.

Partial model removal invalidates exact plans and releases fine groups owning removed generations while retaining unaffected groups/resources. Clear/dispose release all relevant ownership. No worker, cutting topology or XR submission architecture was replaced.

## Measured admission and rejected first candidate

First1024-camera pilot retained~91%memberships but copied~87%instance records because tight offsets rippled after early count changes. Keep that failed design evidence; stable reserved offsets reduced copying in refined2048-camera pilots to~6–8%and retained~88–91%prepared rows. These are short pilots, not the final performance claim.

First fully-moving1024 pilots regressed callback means39.09→42.03ms(WebGPU),39.13→43.39ms(WebGL2). An intermediate candidate used global world-record publication marks and reduced pilot differences to~2.5–3.1%. Reject its coarse admission policy: one large offscreen root could discard unrelated static reuse. Revised admission instead compares globally ordered per-model data revisions against fixed per-view marks, counting only models with nonempty current primitive-selection ranges. Fallback requires >=64contributing models,>=4096eligible items and >=75%changed contributing models. It uses the original scratch builder with published rigid records. A single root cannot trigger it; no image correctness depends on the threshold. It is a conservative measured-regime separator, not claimed optimal.

Singleton-only ordinary-camera pilots had no payloads to save. Fine admission excludes such views and records that decision separately; exact unchanged-input reuse remains. Keep both favorable and adverse small cases.

## Evidence protocol

Baseline: completed batch2 release WASMaf2905cc7d71. Candidate: source529af64503ff/WASMe57c50e85794. Full hashes, source/build configuration and frozen requested-file manifests are retained. The common maintained harness is separate from each immutable runtime package. Baseline-only bounded probes select2048 for static/camera stress after1024 reached60Hz; mixed and fully-moving stress remain1024, small clustered16, ordinary camera/native gameplay, cut64 and Neon controls remain.

Primary:1280×720,DPR1, unchanged effects/content,8s warmup/25s sample,3AB/BA/AB pairs/backend; backend order alternates across cases. Engine/native stages and GL timer queries are asserted off. No owned builds or GPU test runner overlaps measurement. Full frame intervals and RAF callback wall times retain p95/p99/max. Callback wall time includes driver waits and does not include all worker/timer handlers; it is not pure CPU computation. Missing clean-run GPU times remain null. Separate profiled/API diagnostics and actual cut-worker replays are excluded from clean timing. Never add CPU/GPU scopes mechanically.

PhysicalQuest and a fresh Three.js comparison are not part of this batch. Persistent foreign GPU activity remains running and prevents isolated-capacity/small-gain claims. Existing shared8443 bytes were not changed or re-audited.

## Correctness

Maintained motion tests compare cache-on/culling-on against cache-off/culling-off exact pixels; the reference rebuilds independent visibility. First-mutation-frame counters are taken before capture warmups. Tests cover four independent asset cohorts, camera-only movement, one translating root, rotation/nonuniform/mirrored scales,16B↔112B, edge exit/reentry, depth changes, spawn/remove, opaque barriers, ordered transparency, explicit animation/morph seeks and lifecycle.

Real eye attachments verify frozen plans, one moving instance, a small left-only projection change, complete left exclusion without right-eye damage, and head motion. Small projection/head poses also match cache-off/culling-off exact stereo pixels. Initial representation/upload assertions were corrected to permit legitimate shifted/reserved offsets while preserving live record widths, exact changed-record bytes and independent pixel references; those failed attempts are retained. Source review found no material correctness issue; runtime results are separate evidence.

The contributing-model regression additionally updates one4096-node offscreen model beside64static roots×64nodes: all4096world updates must occur, with no fallback or static payload writes, preserved static rows and exact cache-off/culling-off pixels. Intermediate long runs remain preserved under their actual runtime identity; final results use a separate final-candidate series.

## Sustained regression and correction in progress

The contributing-model e57 candidate still regressed the fully-moving1024 callback median of run means39.25→41.25ms(WebGPU) and40.96→44.27ms(WebGL2). Reject it as a final candidate and retain all48 completed long runs. Paused only the owned runner after complete cases; foreign processes and shared servers stayed running. The update path redundantly scanned affine validity and both directed basis comparisons for every changed GPU draw. A reduced equality proof preserves literal legacy semantics, including NaN, signed zero, equal infinite/projective bases and nonfinite translations. Four native tests include20,000 deterministic IEEE cases against the literal old predicate; independent source review found no equivalence gap. Performance remains unproven until a new release and fresh matched pairs.

## Completion

Pending sustained results, separate profiling/worker evidence, final gate, evidence audit and local owned checkpoint. Stop before batch4.
