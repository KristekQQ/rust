import {pixelDifference} from './testkit.js';
import {assertForeground} from '../pixels.js';

// Exercises real rigid glTF instances through the XR per-view render path.
export async function verifyGltfInstanceViews(engine, sim, test, {pixels, shiftLeft} = {}) {
    if (typeof pixels !== 'function') throw new Error('XR glTF instance check requires per-eye pixels');
    engine.scene.clear();
    engine.set_render_effects(false, false);
    engine.set_grid_visible(false);
    engine.set_light_helpers_visible(false);
    engine.postprocessing.disable('ssr');
    engine.postprocessing.disable('bloom');
    engine.setNeonGlow({strength:0});
    engine.scene.createLight({position:[-2,4,0],color:[12,12,12]});
    const frame = (headPosition=[0,1.6,0]) => {
        sim.frame({dt:0, head:{position:headPosition, orientation:[0,0,0,1]}});
        test.assert(!engine.xr.lastError, 'glTF instance stereo frame completes', String(engine.xr.lastError));
    };

    const model = await engine.scene.loadModel(new URL('../../assets/models/damaged-helmet/DamagedHelmet.glb', import.meta.url));
    const instances = [model, model.createInstance(), model.createInstance()];
    const place = x => instances.forEach((instance, index) => instance
        .setPosition([x[index],1.6,-2])
        .setScale([.18,.18,.18]));
    const baseline = [-.6,0,.6];
    place(baseline);
    const before = engine.debugStats().gltf;
    frame();
    const rendered = engine.debugStats().gltf;
    test.assert(rendered.instancedDrawCalls-before.instancedDrawCalls>=2 && rendered.instancesDrawn-before.instancesDrawn>=6,
        'rigid glTF instances use instanced draws in both XR eyes', {before,rendered});

    const readEyes = async () => [await pixels(0), await pixels(1)];
    const first = await readEyes();
    first.forEach((image, eye) => assertForeground(image, `glTF instances in ${eye ? 'right' : 'left'} XR eye`));
    frame();
    const warm = await readEyes();
    test.assert(warm.every((image, eye) => pixelDifference(first[eye], image, 0)===0),
        'identical frozen glTF instance frame reproduces exact stereo pixels');

    // Real eye attachments are the oracle; retaining handles alone cannot prove
    // that a different view has not overwritten their mutable GPU contents.
    frame();frame();
    const planBefore=engine.debugStats().gltf;
    frame();frame();
    const planAfter=engine.debugStats().gltf;
    test.assert(planAfter.preparedPlanCache.hits>=planBefore.preparedPlanCache.hits+4,
        'both frozen XR eye plans hit', {planBefore:planBefore.preparedPlanCache,planAfter:planAfter.preparedPlanCache});
    test.assert(planAfter.prepareOpaqueGroupRebuilds===planBefore.prepareOpaqueGroupRebuilds && planAfter.preparePayloadRebuilds===planBefore.preparePayloadRebuilds,
        'frozen XR eyes skip opaque groups and payload packing');
    engine.setPreparedPlanCacheEnabled(false);engine.set_frustum_culling(false);frame();
    const uncached=await readEyes();
    test.assert(uncached.every((image,eye)=>pixelDifference(warm[eye],image,0)===0),'cache-off culling-off independent oracle preserves exact stereo pixels');
    engine.set_frustum_culling(true);engine.setPreparedPlanCacheEnabled(true);frame();frame();

    instances[2].setPosition([.9,1.6,-2]);
    frame();
    const moved = await readEyes();
    test.assert(moved.every((image, eye) => pixelDifference(warm[eye], image)>0),
        'moving one glTF instance updates both XR eye projections', moved.map((image, eye) => pixelDifference(warm[eye], image)));
    instances[2].setPosition([baseline[2],1.6,-2]);
    frame();
    const restored = await readEyes();
    test.assert(restored.every((image, eye) => pixelDifference(first[eye], image, 0)===0),
        'restoring the glTF instance reproduces exact stereo pixels');

    frame();frame();const headBefore=engine.debugStats().gltf;
    frame([.01,1.6,0]);const headAfter=engine.debugStats().gltf;
    test.assert(headAfter.finePreparedRowsReused>headBefore.finePreparedRowsReused && headAfter.finePayloadRecordsWritten===headBefore.finePayloadRecordsWritten && headAfter.fineWorldRecordRebuilds===headBefore.fineWorldRecordRebuilds,
        'head movement refreshes both views without rebuilding world payloads', {headBefore,headAfter});
    const headMoved=await readEyes();engine.setPreparedPlanCacheEnabled(false);engine.set_frustum_culling(false);frame([.01,1.6,0]);
    const headOracle=await readEyes();test.assert(headOracle.every((image,eye)=>pixelDifference(headMoved[eye],image,0)===0),'moving stereo head matches independent cache-off culling-off oracle');
    engine.set_frustum_culling(true);engine.setPreparedPlanCacheEnabled(true);
    frame();frame();

    if (shiftLeft) {
        const rightBefore = restored[1];
        frame();frame();const fineBefore=engine.debugStats().gltf;
        // Small change retains membership; the original large shift below
        // deliberately removes all geometry from the left view.
        shiftLeft(.015);
        frame();
        const fineAfter=engine.debugStats().gltf;
        test.assert(fineAfter.finePreparedRowsReused>fineBefore.finePreparedRowsReused && fineAfter.finePayloadRecordsWritten===fineBefore.finePayloadRecordsWritten,
            'changing only left projection reuses fine rows without repacking either eye', {fineBefore,fineAfter});
        const finePixels=await readEyes();
        test.assert(pixelDifference(restored[0],finePixels[0])>0 && pixelDifference(rightBefore,finePixels[1],0)===0,
            'fine left-only projection changes left pixels and preserves exact right pixels');
        engine.setPreparedPlanCacheEnabled(false);engine.set_frustum_culling(false);frame();
        const fineOracle=await readEyes();test.assert(fineOracle.every((image,eye)=>pixelDifference(finePixels[eye],image,0)===0),
            'fine left-only projection matches independent cache-off culling-off stereo oracle');
        engine.set_frustum_culling(true);engine.setPreparedPlanCacheEnabled(true);
        shiftLeft(0);frame();shiftLeft(3);frame();
        const shifted = await readEyes();
        test.assert(pixelDifference(restored[0], shifted[0])>0, 'left projection shift changes glTF pixels in the left eye');
        test.assert(pixelDifference(rightBefore, shifted[1], 0)===0, 'left projection shift preserves exact glTF pixels in the right eye');
        shiftLeft(0);
        frame();
    }

    engine.scene.clear();
    frame();
    test.assert(engine.debugStats().gltf.instanceBufferBytes===0, 'scene.clear releases glTF XR instance buffers', engine.debugStats().gltf);
}
