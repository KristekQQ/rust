import json,hashlib,tarfile,io
from pathlib import Path
repo=Path.cwd();root=repo/'output/next-render-cycle-5';dest=repo/'docs/performance/next-render-cycle/batch-5/evidence.tar.gz';selected={}
def add(name,p):
 assert p.is_file() and not p.is_symlink(),str(p)
 selected[name]=p
labels=['baseline','candidate','exploratory-candidate']
for p in root.rglob('*'):
 if p.is_file() and not p.is_symlink() and p.relative_to(root).parts[0] not in labels and p.name not in ['ARCHIVE-AUDIT.json']:
  add('evidence/'+str(p.relative_to(root)),p)
b=json.loads((root/'baseline/render-build.json').read_text());changed=set()
for label in labels:
 m=json.loads((root/label/'render-build.json').read_text());different={p for p in set(b['files'])|set(m['files']) if b['files'].get(p)!=m['files'].get(p)};changed|=different
 assert not any(p.startswith('assets/') for p in different),'Changed assets need explicit inclusion'
 add('frozen/'+label+'/render-build.json',root/label/'render-build.json')
 for name in m['files']:
  if name.startswith('pkg/') or name in different:add('frozen/'+label+'/'+name,root/label/name)
# Baseline sides of every changed input, including candidate-only changes.
for name in changed:
 if name in b['files']:add('frozen/baseline/'+name,root/'baseline'/name)
for p in (repo/'output/verification').rglob('*'):
 if p.is_file() and not p.is_symlink():add('verification/'+str(p.relative_to(repo/'output/verification')),p)
owned=['src/gltf_model.rs','src/render/gltf_gpu.rs','src/render/renderer.rs','src/web.rs','js/engine.js','js/engine.d.ts','scripts/test-browser.mjs','tests/render-performance.js','tests/xr/gltf-instance-checks.js','tests/gltf-white-colors.html','tests/gltf-white-colors.js','tests/gltf-batching.js']
for name in owned:add('final-source/'+name,repo/name)
readme=b'''Batch5 local evidence; parent checkpoint6e80f3270f17621f292790c03867563dbdb9686e.
Reconstruct isolated roots from this tracked base and overlay frozen/{baseline,candidate,exploratory-candidate} changed inputs and generated packages. Verify all files against each full render-build.json. Unchanged assets, dependencies and historical documentation archives are not duplicated. Full frozen roots remain under ignored output/next-render-cycle-5. Primary-driver contains the exact common harness. final-source includes strengthened XR tests added after freezing; runtime Rust/SDK/package content stays equal to final measured candidate.
Final clean24runs and preliminary/adverse/rejected tests, commands/raw/captures/API/module/layout data are retained. The rejected no-varying experiment retains build identity, structured failure and reconstructable source patch; its binary and raw eye buffers were not snapshotted. Failed reports may name screenshot paths subsequently overwritten by later runs; do not treat final screenshots as historical failed captures. Detailed-statistics exploratory release is separately frozen and its six timing runs excluded from final clean pairs.
Geometry probe saved all eight pages, actual API/module/layout data and four exact pixel pairs before browser.close hung after the browser process exited; own idle Node was terminated with no child/GPU overlap. Cleanup records describe this limitation. Maintained primary runs must have successful bounded cleanup.
Memory is requested rigid vertex buffer bytes, not physical driver VRAM. CPU callback wall time is not pure CPU-cycle time; clean GPU timing intentionally unavailable. All distributions recomputed from raw frames. No physical Quest, CI, fresh Three, push, merge, deployment or shared-server restart evidence. Prior B4 moving-stress strict image limit is not resolved by static B5 comparisons.
SHA256SUMS covers every archived payload and exact-content hardlink. Reports/manifests outside the archive are separately versioned.
'''
manifest={};seen={};links=0;total=0
with tarfile.open(dest,'w:gz',compresslevel=6) as tf:
 for name,p in sorted(selected.items()):
  data=p.read_bytes();h=hashlib.sha256(data).hexdigest();manifest[name]={'sha256':h,'bytes':len(data)};total+=len(data);info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;key=(h,len(data))
  if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];tf.addfile(info);links+=1
  else:info.size=len(data);tf.addfile(info,io.BytesIO(data));seen[key]=name
 for name,data in [('README.txt',readme),('SHA256SUMS.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tf.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as tf:
 assert json.load(tf.extractfile('SHA256SUMS.json'))==manifest
 for name,m in manifest.items():
  data=tf.extractfile(name).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256'],name
summary={'path':str(dest.relative_to(repo)),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'payloads':len(manifest),'storedEntries':len(manifest)+2,'uniquePayloads':len(seen),'exactContentHardlinks':links,'recordedUncompressedBytes':total,'everyPayloadAndHardlinkReadBack':True,'frozenChangedInputsIncluded':sorted(changed),'unchangedBaseAssetsExcluded':True}
(root/'ARCHIVE-AUDIT.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
