import fs from 'node:fs/promises';import {spawn} from 'node:child_process';
const root='output/next-render-cycle-5',steps=[],cases=[];
async function probe(family,load,backend){const out=`${root}/cal-${family}-${load}-${backend}`,args=['scripts/render-performance.mjs','calibrate','--baseline-root',root+'/baseline','--backend',backend,'--family',family,'--load',String(load),'--max-load','2048','--width','1280','--height','720','--warmup','1000','--sample','2500','--no-profile','--startup-timeout','60000','--out',out];const s={at:new Date().toISOString(),args};steps.push(s);await fs.writeFile(root+'/calibration-commands.json',JSON.stringify(steps,null,2));const f=await fs.open(out+'.log','w');s.exitCode=await new Promise(r=>spawn(process.execPath,args,{stdio:['ignore',f.fd,f.fd]}).on('exit',r));await f.close();await fs.writeFile(root+'/calibration-commands.json',JSON.stringify(steps,null,2));if(s.exitCode)throw Error(out);const report=JSON.parse(await fs.readFile(out+'/report.json'));const result=report.results[0];console.log(family,load,backend,result.rafInterval.mean,result.rafCallbackCpu.mean);return {family,load,backend,file:out+'/config.json',result};}
for(const backend of ['webgpu','webgl']){
 cases.push(await probe('rim-static',1,backend));
 let c=await probe('rim-stress',1024,backend);
 if(c.result.rafInterval.mean<18)c=await probe('rim-stress',2048,backend);
 cases.push(c);
}
await fs.writeFile(root+'/PRIMARY-CONFIGS.json',JSON.stringify({at:new Date().toISOString(),cases},null,2));
