from pathlib import Path
import hashlib,json
r=Path('output/next-render-cycle-5');frozen=r/'exploratory-candidate';files=sorted([str(p.relative_to(frozen)) for d in ['src','third_party/wgpu'] for p in (frozen/d).rglob('*') if p.is_file() and p.suffix in ['.rs','.wgsl']]+['third_party/wgpu/Cargo.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml'])
# Apply the archived narrow rejection patch in memory from its replacement body.
s=(frozen/'src/render/gltf_gpu.rs').read_text();a=s.index('        // Do this after skin/instance declarations have been injected. Omit the');b=s.index('\n    }\n    if opaque_unclipped',a)
replacement='''        // Do this after skin/instance declarations have been injected. Both the
        // attribute fetch and interpolator disappear; all material factors stay.
        source = source.replace(", @location(8) color:vec4<f32>", "");
        source = source.replace("o.color=v.color;", "");
        source = source.replace("*v.color", "*vec4<f32>(1.0)");'''
rejected=(s[:a]+replacement+s[b:]).encode();h=hashlib.sha256()
for name in files:h.update(name.encode());h.update(b'\0');h.update(rejected if name=='src/render/gltf_gpu.rs' else (frozen/name).read_bytes());h.update(b'\0')
expected=json.loads((r/'targeted-initial-report.json').read_text())['build']['source'];proof={'reconstructedSourceSha256':h.hexdigest(),'failedRuntimeSourceSha256':expected,'sourcePatchExact':h.hexdigest()==expected,'rejectedBinaryRetained':False};assert proof['sourcePatchExact'],proof
(r/'REJECTED-SOURCE-PROOF.json').write_text(json.dumps(proof,indent=2));print(proof)
