/* tslint:disable */
/* eslint-disable */

export function add_colored_triangle_mesh(positions: Float32Array, indices: Uint32Array, colors: Float32Array, smooth: boolean): number;

export function add_cube(x: number, y: number, z: number): number;

export function add_font3d_text(font: number, text: string, options_json: string): number;

/**
 * Create opt-in text geometry in local XY; use ordinary object transforms.
 */
export function add_info_panel(kind: string, width: number, height: number): number;

export function add_light(x: number, y: number, z: number, r: number, g: number, b: number): number;

export function add_mesh_variant(handle: number, variant: number): number;

/**
 * Static numeric tube inscription, sharing cached digit meshes with native HUDs.
 */
export function add_numeric_text(value: string, width: number, height: number): number;

export function add_plane(x: number, y: number, z: number): number;

export function add_sphere(x: number, y: number, z: number): number;

/**
 * Static bitmap inscription with no backing rectangle.
 */
export function add_text_panel(title: string, lines_json: string, width: number, height: number): number;

export function add_triangle_mesh(positions: Float32Array, indices: Uint32Array, r: number, g: number, b: number, smooth: boolean): number;

export function adjust_orbit(dx: number, dy: number, zoom: number): boolean;

export function aim_cutter(id: number, guides: Uint32Array, center: Float32Array, settings: Float32Array): Float32Array;

/**
 * Bind a world object to one of three slots in the currently hit combo row.
 */
export function bind_combo_indicator(id: number, kind: string, slot: number): boolean;

/**
 * Bind an existing native single-value panel; INVALID_ID restores its legacy font.
 */
export function bind_info_panel_font3d(panel: number, font: number, options_json: string): void;

export function builtin_font3d(name: string): number;

export function camera_view_state(): string;

export function character_state(): string;

export function clear_all(): void;

export function clear_combo_display(): void;

export function clear_cut_feedback(): void;

export function clear_environment_cube_map(): boolean;

export function clear_light_orbit(id: number): boolean;

export function clear_lights(): void;

export function clear_scene(): void;

export function combo_display_state(): string;

export function configure_character_physics(hx: number, hy: number, hz: number, gravity: number, jump_speed: number): boolean;

export function configure_combo_display(input: string): boolean;

export function configure_environment(enabled: boolean, x: number, y: number, z: number, hx: number, hy: number, hz: number): boolean;

/**
 * Independent uncached preparation path for correctness/performance controls.
 */
export function configure_gltf_instance_pool(byte_limit?: number | null, resource_limit?: number | null, stream_byte_limit?: number | null): boolean;

export function configure_god_rays(density: number, exposure: number): boolean;

/**
 * Explicit scene-authored melee encounter; simulation remains in Rust.
 */
export function configure_melee(input: string): void;

export function configure_planar_mirror(id: number): boolean;

export function configure_rim(input: string): void;

export function configure_ssr(resolution_scale: number): boolean;

export function configure_ssr_region(bounds: Float32Array): boolean;

/**
 * Configure an explicit table-tennis scene; no automatic object creation.
 */
export function configure_table_tennis(ball: number, player: number, opponent: number, panel: number): void;

/**
 * Attach input and a chase camera to an existing glTF root, never spawn a scene.
 */
export function control_character(id: number, speed: number, run_speed: number, model_yaw: number, idle: number, walk: number, run: number): boolean;

export function cut_with(id: number, x: number, y: number, z: number, separation: number): string;

/**
 * No RefCell borrow survives the asynchronous GPU readback. A scene revision
 * and engine generation guard prevent late results from replacing newer data.
 */
export function cut_with_async(id: number, motion: Float32Array, separation: number, scatter: Float32Array, execution: string): Promise<string>;

export function cut_with_scatter(id: number, motion: Float32Array, separation: number, floor_y: number, distance: number, duration: number): string;

export function debug_stats(): string;

/**
 * Release the frame loop, input listeners, camera and GPU scene resources.
 */
export function dispose(): void;

export function effects_stats(): Float64Array;

export function environment_captures(): number;

export function font3d_info(id: number): string;

export function font3d_text_info(id: number): string;

/**
 * Read-only native frame profiling; GPU data is asynchronous and may be absent.
 */
export function frame_profile_stats(): string;

export function gltf_buffer_uris(bytes: Uint8Array): Array<any>;

export function gltf_resource_uris(bytes: Uint8Array): string;

/**
 * On-demand details; keep regular frame diagnostics compact.
 */
export function gltf_vertex_layouts(): string;

/**
 * New independent pose/root referencing the existing immutable model asset.
 */
export function instantiate_model(id: number): number;

export function light_exists(id: number): boolean;

export function load_gltf(bytes: Uint8Array, buffers: Array<any>): number;

export function load_gltf_model(bytes: Uint8Array, buffers: Array<any>, images: Array<any>): number;

export function melee_state(): string;

export function model_info(id: number): string;

export function object_exists(id: number): boolean;

export function pause_model_animation(id: number, paused: boolean): boolean;

export function play_cut_feedback(pieces: Uint32Array): string;

export function play_cut_feedback_facing(pieces: Uint32Array, mirror_text: boolean, size?: number | null, score_label?: string | null): string;

export function play_model_animation(id: number, clip: number, looping: boolean, speed: number): boolean;

export function postprocess_graph(): string;

export function postprocess_stats(): Float64Array;

export function projectile_contacts(): number;

/**
 * Register a validated closed-mesh glyph library.
 */
export function register_font3d(json: string): number;

export function register_mesh_variants(positions: Float32Array, indices: Uint32Array, colors: Float32Array, smooth: boolean): number;

export function remove_collider(id: number): boolean;

export function remove_font3d(id: number): boolean;

export function remove_light(id: number): boolean;

export function remove_mesh_variants(handle: number): boolean;

export function remove_object(id: number): boolean;

export function renderer_backend(): string;

export function renderer_stats(): Float64Array;

export function resize(width: number, height: number): void;

export function rim_accept_cut(bytes: Uint8Array): void;

export function rim_cut_failed(): void;

export function rim_input(input: string): void;

export function rim_split_geometry(bytes: Uint8Array): Uint8Array;

export function rim_state(): string;

export function rim_take_cut_job(): Uint8Array;

/**
 * Raw platform input; Aurelia owns movement and simulation time.
 */
export function rim_update_xr(head: Float32Array, ray: Float32Array, axes: Float32Array, cancel: boolean, dt: number): void;

export function rim_xr_buttons(aim: boolean, dash: boolean): void;

export function scene_light_count(): number;

export function scene_object_count(): number;

export function schedule_remove_light(id: number, delay: number): boolean;

export function schedule_remove_object(id: number, delay: number): boolean;

export function schedule_rotate(id: number, rx_deg: number, ry_deg: number, rz_deg: number, delay: number, duration: number): boolean;

export function screen_to_plane(u: number, v: number, height: number): Float32Array;

export function seek_model_animation(id: number, time: number): boolean;

export function select_model_scene(id: number, scene: number): boolean;

export function set_background_color(r: number, g: number, b: number): boolean;

export function set_blade_contact_response(id: number, enabled: boolean): void;

/**
 * Opt-in finite blade contact profile; the edge direction is object-local.
 */
export function set_blade_physics(id: number, edge: Float32Array, half_width: number, half_thickness: number): void;

export function set_blade_trail(id: number, enabled: boolean): void;

export function set_box_collider(id: number, hx: number, hy: number, hz: number, ox: number, oy: number, oz: number): boolean;

export function set_box_colliders(id: number, packed: Float32Array): boolean;

export function set_camera_mode(mode: string): void;

export function set_camera_view(px: number, py: number, pz: number, tx: number, ty: number, tz: number): boolean;

/**
 * Explicit original-target scoring metadata; fragments do not inherit it.
 */
export function set_combo_target(id: number, kind: string, points: number, wild: boolean): boolean;

export function set_cube_transform(id: number, x: number, y: number, z: number, rx: number, ry: number, rz: number, sx: number, sy: number, sz: number): boolean;

export function set_cut_assist(id: number, coverage: number): void;

export function set_cuttable(id: number, enabled: boolean, r: number, g: number, b: number): void;

export function set_cutter(id: number, enabled: boolean, endpoints: Float32Array): void;

export function set_debug_overlay(enabled: boolean): void;

export function set_environment_cube_map(size: number, color: Uint8Array, emission: Uint8Array, intensity: number, projection: Float32Array): boolean;

export function set_environment_intensity(intensity: number): boolean;

export function set_frustum_culling(enabled: boolean): void;

/**
 * Lossless rigid-layout reference control; rejects changes while GPU assets are live.
 */
export function set_gltf_white_color_omission_enabled(enabled: boolean): boolean;

export function set_grid_visible(show: boolean): void;

export function set_light(id: number, x: number, y: number, z: number, r: number, g: number, b: number): boolean;

export function set_light_helpers_visible(show: boolean): void;

export function set_light_orbit(id: number, radius: number, height: number, speed: number, phase: number, pulse: number, r: number, g: number, b: number): boolean;

export function set_model_morph_weights(id: number, node: number, weights: Float32Array): boolean;

/**
 * Optional additive geometry glow; zero disables and releases its GPU cache.
 */
export function set_neon_glow(strength: number, radius: number): boolean;

export function set_object_color_cutout(id: number, threshold: number): boolean;

export function set_object_emission(id: number, intensity: number): boolean;

export function set_object_opacity(id: number, opacity: number, opaque_above: number, variation: number, coverage: number): boolean;

export function set_object_position(id: number, x: number, y: number, z: number): boolean;

export function set_object_render_options(id: number, is_static: boolean, casts_shadow: boolean, receives_shadow: boolean, reflectivity: number, opaque_reorderable: boolean): boolean;

export function set_object_rotation(id: number, x: number, y: number, z: number): boolean;

export function set_object_scale(id: number, x: number, y: number, z: number): boolean;

export function set_object_spin(id: number, x: number, y: number, z: number): boolean;

export function set_object_transform(id: number, x: number, y: number, z: number, rx: number, ry: number, rz: number, sx: number, sy: number, sz: number): boolean;

export function set_orbit_view(px: number, py: number, pz: number, tx: number, ty: number, tz: number): boolean;

/**
 * Select browser presentation; scene rendering itself accepts GPU attachments.
 */
export function set_output_mode(mode: string): boolean;

export function set_postprocess(name: string, enabled: boolean, strength: number): boolean;

export function set_prepared_plan_cache_enabled(enabled: boolean): void;

export function set_projectile(id: number, vx: number, vy: number, vz: number, gravity: number, bounce: number): boolean;

export function set_reflection_mask(width: number, height: number, pixels: Uint8Array, x: number, z: number, size_x: number, size_z: number): boolean;

export function set_render_effects(shadows: boolean, reflections: boolean): void;

export function set_scene_appearance(input: string): void;

export function set_simulation_paused(paused: boolean): void;

export function ssr_stats(): Float64Array;

export function ssr_work_stats(): Float64Array;

export function start(): Promise<any>;

export function stop_model_animation(id: number): boolean;

export function table_tennis_command(command: string, x: number, y: number): void;

export function table_tennis_state(): string;

/**
 * Reads actual GPU vertices for explicit verification, never during a normal cut.
 */
export function triangle_mesh_gpu_snapshot(id: number): Promise<string>;

export function triangle_mesh_info(id: number): string;

/**
 * Explicit diagnostic snapshot, never fetched by the render loop.
 */
export function triangle_mesh_snapshot(id: number): string;

export function update_font3d_text(id: number, text: string, options_json: string): void;

export function use_model_camera(id: number, node: number): boolean;

/**
 * Maintained GPU acceptance probe: execute a compiled storage-buffer graph.
 */
export function verify_frame_graph_resources(): Promise<string>;

export function world_to_screen(x: number, y: number, z: number): Float32Array;

export function xr_add_item(id: number): void;

export function xr_bank_chain(index: number): boolean;

/**
 * Advance once per XR frame, never once per eye.
 */
export function xr_begin_frame(dt: number): void;

/**
 * Bind an authored object to a grip pose. UINT32_MAX unbinds it.
 */
export function xr_bind_controller(hand: number, id: number, cutting: boolean): void;

export function xr_bind_head(id: number): void;

export function xr_bind_head_offset(id: number, x: number, y: number, z: number, feet: boolean): void;

export function xr_cancel_locomotion(): void;

export function xr_configure_locomotion(input: string): void;

/**
 * Close CPU/GPU profiling after both eyes, including the final XR presentation.
 */
export function xr_finish_frame(): void;

export function xr_gpu_color_format(): string;

/**
 * Same device used by the Rust renderer; required for XRGPUBinding.
 */
export function xr_gpu_device(): any;

export function xr_gpu_supported(): boolean;

/**
 * Raw grip poses against the registered finite blade and actual panel volume.
 */
export function xr_panel_blade_hit(panel_id: number, cutter_id: number, from: Float32Array, to: Float32Array): Uint8Array;

/**
 * A platform target ray against an actual transformed scene panel.
 */
export function xr_panel_hit(id: number, matrix: Float32Array): Float32Array;

export function xr_player_state(): string;

/**
 * Called after current platform hand/head poses and before either eye is drawn.
 */
export function xr_prepare_gameplay(): void;

/**
 * Present completed stereo effects with one final compositor-facing submission.
 */
export function xr_present_gpu_frame(images: Array<any>): void;

export function xr_remove_item(id: number): void;

/**
 * Matrices come unchanged from XRView; clip conversion and eye position are Rust.
 */
export function xr_render_eye(projection: Float32Array, world: Float32Array, width: number, height: number): void;

/**
 * Render into the browser-owned projection texture. No canvas transfer/readback.
 */
export function xr_render_gpu_eye(projection: Float32Array, world: Float32Array, sub_image: any): void;

export function xr_round_state(): string;

/**
 * WebXR host owns session scheduling; Rust retains scene and view calculations.
 */
export function xr_set_presenting(active: boolean): void;

/**
 * Opt-in round duration; the application chooses its game length.
 */
export function xr_start_round(seconds: number): void;

/**
 * Raw platform grip matrix; all pose/sweep/geometry calculations remain in Rust.
 */
export function xr_update_controller(hand: number, matrix: Float32Array, pressed: boolean): string;

export function xr_update_head(matrix: Float32Array): void;

/**
 * Raw device values only. Rust owns navigation, collision, landing and simulation time.
 */
export function xr_update_locomotion(head: Float32Array, ray: Float32Array, axes: Float32Array, held: boolean, cancel: boolean, dt: number): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly add_colored_triangle_mesh: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly add_cube: (a: number, b: number, c: number) => number;
    readonly add_font3d_text: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly add_info_panel: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly add_light: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly add_mesh_variant: (a: number, b: number) => number;
    readonly add_numeric_text: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly add_plane: (a: number, b: number, c: number) => number;
    readonly add_sphere: (a: number, b: number, c: number) => number;
    readonly add_text_panel: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly add_triangle_mesh: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly adjust_orbit: (a: number, b: number, c: number) => number;
    readonly aim_cutter: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly bind_combo_indicator: (a: number, b: number, c: number, d: number) => number;
    readonly bind_info_panel_font3d: (a: number, b: number, c: number, d: number) => [number, number];
    readonly builtin_font3d: (a: number, b: number) => [number, number, number];
    readonly camera_view_state: () => [number, number, number, number];
    readonly character_state: () => [number, number];
    readonly clear_all: () => void;
    readonly clear_combo_display: () => void;
    readonly clear_cut_feedback: () => [number, number];
    readonly clear_environment_cube_map: () => number;
    readonly clear_light_orbit: (a: number) => number;
    readonly clear_lights: () => void;
    readonly clear_scene: () => void;
    readonly combo_display_state: () => [number, number];
    readonly configure_character_physics: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly configure_combo_display: (a: number, b: number) => number;
    readonly configure_environment: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly configure_gltf_instance_pool: (a: number, b: number, c: number) => number;
    readonly configure_god_rays: (a: number, b: number) => number;
    readonly configure_melee: (a: number, b: number) => [number, number];
    readonly configure_planar_mirror: (a: number) => number;
    readonly configure_rim: (a: number, b: number) => [number, number];
    readonly configure_ssr: (a: number) => number;
    readonly configure_ssr_region: (a: number, b: number) => number;
    readonly configure_table_tennis: (a: number, b: number, c: number, d: number) => [number, number];
    readonly control_character: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly cut_with: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly cut_with_async: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly cut_with_scatter: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly debug_stats: () => [number, number];
    readonly dispose: () => void;
    readonly effects_stats: () => any;
    readonly environment_captures: () => number;
    readonly font3d_info: (a: number) => [number, number, number, number];
    readonly font3d_text_info: (a: number) => [number, number, number, number];
    readonly frame_profile_stats: () => [number, number];
    readonly gltf_buffer_uris: (a: number, b: number) => [number, number, number];
    readonly gltf_resource_uris: (a: number, b: number) => [number, number, number, number];
    readonly gltf_vertex_layouts: () => [number, number];
    readonly instantiate_model: (a: number) => [number, number, number];
    readonly light_exists: (a: number) => number;
    readonly load_gltf: (a: number, b: number, c: any) => [number, number, number];
    readonly load_gltf_model: (a: number, b: number, c: any, d: any) => [number, number, number];
    readonly melee_state: () => [number, number];
    readonly model_info: (a: number) => [number, number, number, number];
    readonly object_exists: (a: number) => number;
    readonly pause_model_animation: (a: number, b: number) => number;
    readonly play_cut_feedback: (a: number, b: number) => [number, number, number, number];
    readonly play_cut_feedback_facing: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly play_model_animation: (a: number, b: number, c: number, d: number) => number;
    readonly postprocess_graph: () => [number, number];
    readonly postprocess_stats: () => [number, number];
    readonly projectile_contacts: () => number;
    readonly register_font3d: (a: number, b: number) => [number, number, number];
    readonly register_mesh_variants: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly remove_collider: (a: number) => number;
    readonly remove_font3d: (a: number) => number;
    readonly remove_light: (a: number) => number;
    readonly remove_mesh_variants: (a: number) => number;
    readonly remove_object: (a: number) => number;
    readonly renderer_backend: () => [number, number];
    readonly renderer_stats: () => any;
    readonly resize: (a: number, b: number) => void;
    readonly rim_accept_cut: (a: number, b: number) => [number, number];
    readonly rim_cut_failed: () => void;
    readonly rim_input: (a: number, b: number) => [number, number];
    readonly rim_split_geometry: (a: number, b: number) => [number, number, number, number];
    readonly rim_state: () => [number, number];
    readonly rim_take_cut_job: () => [number, number, number, number];
    readonly rim_update_xr: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number];
    readonly rim_xr_buttons: (a: number, b: number) => void;
    readonly scene_light_count: () => number;
    readonly scene_object_count: () => number;
    readonly schedule_remove_light: (a: number, b: number) => number;
    readonly schedule_remove_object: (a: number, b: number) => number;
    readonly schedule_rotate: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly screen_to_plane: (a: number, b: number, c: number) => [number, number, number, number];
    readonly seek_model_animation: (a: number, b: number) => number;
    readonly select_model_scene: (a: number, b: number) => number;
    readonly set_background_color: (a: number, b: number, c: number) => number;
    readonly set_blade_contact_response: (a: number, b: number) => [number, number];
    readonly set_blade_physics: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly set_blade_trail: (a: number, b: number) => [number, number];
    readonly set_box_collider: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly set_box_colliders: (a: number, b: number, c: number) => number;
    readonly set_camera_mode: (a: number, b: number) => void;
    readonly set_camera_view: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly set_combo_target: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly set_cube_transform: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => number;
    readonly set_cut_assist: (a: number, b: number) => [number, number];
    readonly set_cuttable: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly set_cutter: (a: number, b: number, c: number, d: number) => [number, number];
    readonly set_debug_overlay: (a: number) => void;
    readonly set_environment_cube_map: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly set_environment_intensity: (a: number) => number;
    readonly set_frustum_culling: (a: number) => void;
    readonly set_gltf_white_color_omission_enabled: (a: number) => number;
    readonly set_grid_visible: (a: number) => void;
    readonly set_light: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly set_light_helpers_visible: (a: number) => void;
    readonly set_light_orbit: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => number;
    readonly set_model_morph_weights: (a: number, b: number, c: number, d: number) => number;
    readonly set_neon_glow: (a: number, b: number) => number;
    readonly set_object_color_cutout: (a: number, b: number) => number;
    readonly set_object_emission: (a: number, b: number) => number;
    readonly set_object_opacity: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly set_object_position: (a: number, b: number, c: number, d: number) => number;
    readonly set_object_render_options: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly set_object_rotation: (a: number, b: number, c: number, d: number) => number;
    readonly set_object_scale: (a: number, b: number, c: number, d: number) => number;
    readonly set_object_spin: (a: number, b: number, c: number, d: number) => number;
    readonly set_object_transform: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => number;
    readonly set_orbit_view: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly set_output_mode: (a: number, b: number) => number;
    readonly set_postprocess: (a: number, b: number, c: number, d: number) => number;
    readonly set_prepared_plan_cache_enabled: (a: number) => void;
    readonly set_projectile: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly set_reflection_mask: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly set_render_effects: (a: number, b: number) => void;
    readonly set_scene_appearance: (a: number, b: number) => [number, number];
    readonly set_simulation_paused: (a: number) => void;
    readonly ssr_stats: () => [number, number];
    readonly ssr_work_stats: () => [number, number];
    readonly start: () => any;
    readonly stop_model_animation: (a: number) => number;
    readonly table_tennis_command: (a: number, b: number, c: number, d: number) => [number, number];
    readonly table_tennis_state: () => [number, number];
    readonly triangle_mesh_gpu_snapshot: (a: number) => any;
    readonly triangle_mesh_info: (a: number) => [number, number, number, number];
    readonly triangle_mesh_snapshot: (a: number) => [number, number, number, number];
    readonly update_font3d_text: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly use_model_camera: (a: number, b: number) => number;
    readonly verify_frame_graph_resources: () => any;
    readonly world_to_screen: (a: number, b: number, c: number) => [number, number, number, number];
    readonly xr_add_item: (a: number) => [number, number];
    readonly xr_bank_chain: (a: number) => number;
    readonly xr_begin_frame: (a: number) => [number, number];
    readonly xr_bind_controller: (a: number, b: number, c: number) => [number, number];
    readonly xr_bind_head: (a: number) => [number, number];
    readonly xr_bind_head_offset: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly xr_cancel_locomotion: () => [number, number];
    readonly xr_configure_locomotion: (a: number, b: number) => [number, number];
    readonly xr_finish_frame: () => void;
    readonly xr_gpu_color_format: () => [number, number, number, number];
    readonly xr_gpu_device: () => [number, number, number];
    readonly xr_gpu_supported: () => number;
    readonly xr_panel_blade_hit: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly xr_panel_hit: (a: number, b: number, c: number) => [number, number];
    readonly xr_player_state: () => [number, number, number, number];
    readonly xr_prepare_gameplay: () => void;
    readonly xr_present_gpu_frame: (a: any) => [number, number];
    readonly xr_remove_item: (a: number) => [number, number];
    readonly xr_render_eye: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly xr_render_gpu_eye: (a: number, b: number, c: number, d: number, e: any) => [number, number];
    readonly xr_round_state: () => [number, number];
    readonly xr_set_presenting: (a: number) => [number, number];
    readonly xr_start_round: (a: number) => [number, number];
    readonly xr_update_controller: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly xr_update_head: (a: number, b: number) => [number, number];
    readonly xr_update_locomotion: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number];
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___js_sys_8adfe12d0820b45e___Function_fn_wasm_bindgen_1193bfb305a91cfc___JsValue_____wasm_bindgen_1193bfb305a91cfc___sys__Undefined___js_sys_8adfe12d0820b45e___Function_fn_wasm_bindgen_1193bfb305a91cfc___JsValue_____wasm_bindgen_1193bfb305a91cfc___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___wasm_bindgen_1193bfb305a91cfc___sys__JsNullable_wgpu_29a1b00d2e54ef20___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_608f92abc48d28da___result__Result_____wasm_bindgen_1193bfb305a91cfc___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___wasm_bindgen_1193bfb305a91cfc___sys__JsNullable_wgpu_29a1b00d2e54ef20___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_608f92abc48d28da___result__Result_____wasm_bindgen_1193bfb305a91cfc___JsError___true__175: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___wasm_bindgen_1193bfb305a91cfc___sys__JsNullable_wgpu_29a1b00d2e54ef20___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_608f92abc48d28da___result__Result_____wasm_bindgen_1193bfb305a91cfc___JsError___true__176: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___wasm_bindgen_1193bfb305a91cfc___sys__JsNullable_wgpu_29a1b00d2e54ef20___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_608f92abc48d28da___result__Result_____wasm_bindgen_1193bfb305a91cfc___JsError___true__177: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke___web_sys_75a2a6fcc1a055f5___features__gen_Event__Event______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_1193bfb305a91cfc___convert__closures_____invoke_______true_: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
