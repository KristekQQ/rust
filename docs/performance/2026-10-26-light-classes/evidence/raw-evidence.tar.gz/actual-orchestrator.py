import json, subprocess, time
from pathlib import Path
root=Path('/Users/Honza/.codex/worktrees/rim-publish/rust');out=root/'output/light-classes/final-matrix';out.mkdir(exist_ok=True)
base='output/light-classes/baseline';candidate='output/light-classes/candidate-v3';stages=[]
def job(name,command,**kwargs):
 args=['node','scripts/render-performance.mjs',command]
 for k,v in kwargs.items():args += ['--'+k.replace('_','-'),str(v)]
 args+=['--no-profile','--out','output/light-classes/final-matrix/'+name];stages.append((name,args))
shared=dict(family='rim-stress',load=512,max_load=2048,width=2880,height=1920)
for backend in ['webgl','webgpu']:
 job('calibrate-'+backend,'calibrate',baseline_root=base,backend=backend,warmup=3000,sample=8000,**shared)
 job('pairs-'+backend,'compare',baseline_root=base,candidate_root=candidate,config='output/light-classes/final-matrix/calibrate-'+backend+'/config.json',backend=backend,pairs=3,warmup=8000,sample=25000,**shared)
job('calibrate-final-gl','calibrate',baseline_root=candidate,backend='webgl',warmup=3000,sample=8000,**shared)
job('three-gl','compare',baseline_root=candidate,three_root='output/rim-stress/three-reference',three_representation='instanced',config='output/light-classes/final-matrix/calibrate-final-gl/config.json',backend='webgl',pairs=3,warmup=8000,sample=25000,**shared)
for backend in ['webgl','webgpu']:
 options=dict(family='rim-static',load=1,max_load=1,width=960,height=640,backend=backend)
 job('calibrate-control-'+backend,'calibrate',baseline_root=base,warmup=2000,sample=5000,**options)
 job('control-'+backend,'compare',baseline_root=base,candidate_root=candidate,config='output/light-classes/final-matrix/calibrate-control-'+backend+'/config.json',pairs=1,warmup=2000,sample=8000,**options)
status={'started':time.time(),'completed':[],'active':None,'failed':None}
for name,args in stages:
 status['active']=name;status['command']=args;(out/'matrix-status.json').write_text(json.dumps(status,indent=2)+'\n');print('START '+name,flush=True)
 with (out/(name+'.log')).open('w') as f:result=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 status['completed'].append({'name':name,'exit':result.returncode,'time':time.time()})
 if result.returncode:
  status['failed']=name;status['active']=None;(out/'matrix-status.json').write_text(json.dumps(status,indent=2)+'\n');print('FAILED '+name,flush=True);raise SystemExit(result.returncode)
 print('PASS '+name,flush=True)
 if (out/'stop-after-stage').exists():
  status['active']=None;status['stoppedBetweenStages']=True;(out/'matrix-status.json').write_text(json.dumps(status,indent=2)+'\n');raise SystemExit(0)
status['active']=None;status['finished']=time.time();(out/'matrix-status.json').write_text(json.dumps(status,indent=2)+'\n')
